
cc.FileUtils:getInstance():setPopupNotify(false)
cc.FileUtils:getInstance():addSearchPath("src/")
cc.FileUtils:getInstance():addSearchPath("res/")
cc.FileUtils:getInstance():addSearchPath("res/Default/")
cc.FileUtils:getInstance():addSearchPath("res/ui/")

require "config"
require "cocos.init"
require "app/manager/recManager"
require('app.algorithm.Algorithm')

local function main()
    collectgarbage("collect")
    -- avoid memory leak
    collectgarbage("setpause", 100)
    collectgarbage("setstepmul", 5000)
   -- print = release_print
     
    if CC_SHOW_FPS then
        cc.Director:getInstance():setDisplayStats(true)
    end     
        
--    loadCSVFiles()
--    loadCsvClient()

    require("game")
    
    --require("app.MyApp"):create():run()
end

local status, msg = xpcall(main, __G__TRACKBACK__)
if not status then
    print(msg)
end
