local pm = cc.load("puremvc")

Proxy = pm.Proxy
Mediator = pm.Mediator
SimpleCommand = pm.SimpleCommand
Notifier = pm.Notifier
Notification = pm.Notification
require("app.manager.SceneManager")
require("app.views.Context")
require("GlobalGame")
require("app.views.BaseViewComponent")
require("app/views/BaseMediator")
require("app/models/localizePS")

local ContextProxy = require("app.models.ContextProxy")
local GameMediator = require("app/views/GameMediator")
local GMMediator = require("app/views/GMMediator")
local TipUI = require("app.views.TipUI")

--require("app.net.simpleclient")
 
local function InitGame()
    game = pm.Facade:getInstance("game")

    game:registerCommand(GAME.LOAD_SCENE, require("app/models/LoadSceneCommand"))
    game:registerCommand(GAME.LOAD_LAYERS, require("app.models.LoadLayersCommand"))
    game:registerCommand(GAME.REMOVE_LAYERS, require("app.models.RemoveLayersCommand"))
    game:registerCommand(GAME.GO_BACK, require("app/models/BackSceneCommand"))
    game:registerProxy(ContextProxy:create(ContextProxy.__cname, { }))
    game:registerMediator(GameMediator:create(GameMediator.__cname))
    game:registerMediator(GMMediator:create(GMMediator.__cname))


    LuaExtend = require("app.models.LuaExtend")

    require("app.models.MapProxy")
    require('app/models/PlayerProxy')
    require('app/models/BuildingProxy')


    if CC_EDIT_MAP then
        game:registerCommand(GAME.LOAD_MAP_DATA, require ("app.mapEdit.LoadMapData"))    
    
        --game:registerCommand(GAME.SAVE_MAP_DATA, require("app/models/SaveGameDataCommand"))
        game:sendNotification(GAME.LOAD_MAP_DATA, { })               
        return 
    end

    game:registerCommand(GAME.LOAD_USER_DATA, require ("app.models.LoadGameDataCommand"))
    game:registerCommand(GAME.SAVE_USER_DATA, require("app/models/SaveGameDataCommand"))

    game:sendNotification(GAME.LOAD_USER_DATA, { })

    --    game:registerCommand(GAME.LOAD_SCENE, LoadSceneCommand)
    --    game:registerCommand(GAME.LOAD_LAYERS, LoadLayersCommand)
    --    game:registerCommand(GAME.REMOVE_LAYERS, RemoveLayersCommand)
    --    game:registerCommand(GAME.GO_BACK, BackSceneCommand)
    --    game:registerCommand(GAME.LOAD_USER_DATA, LoadGameDataCommand)
    --    game:registerCommand(GAME.SAVE_USER_DATA, SaveGameDataCommand)
    -- game:registerCommand(GAME.LOAD_ENEMY_FIGHTER, LoadEnemyFighter)
    -- game:registerMediator(TipUI:create(TipUI.__cname))
    -- game:registerProxy(ContextProxy:create(ContextProxy.__cname, {}))
    -- game:registerMediator(GameMediator:create(GameMediator.__cname))
    -- game:registerMediator(GMMediator:create(GMMediator.__cname))
    -- game:sendNotification(GAME.LOAD_USER_DATA, {})
    -- game:sendNotification(GAME.LOAD_ENEMY_FIGHTER, {})
end


function getProxy(name)
    if game:retrieveProxy(name) then
        return game:retrieveProxy(name)
    end

    local packageName = string.format("%s.%s", "app/models", name)
    local status, view = xpcall( function()
        return require(packageName)
    end , function(msg)
        if not string.find(msg, string.format("'%s' not found:", packageName)) then
            print("load view error: ", msg)
        end
    end )

    local t = type(view)
    if status and(t == "table" or t == "userdata") then
        local proxy = view:create(name, { })
        game:registerProxy(proxy)
        return proxy
    else
        error(string.format("GameMediator:createView() - not found model \"%s\" in search paths \"%s\"",
        name, "app/models"), 0)
    end

end

function  getCSVField(name)
    local csvproxy = getProxy("CsvProxy")
    return csvproxy:getCsv(name)
end


InitGame()