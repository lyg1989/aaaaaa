--热更新

updateLayer = class()


local targetPlatform = cc.Application:getInstance():getTargetPlatform()   --平台


function updateLayer:ctor()
    self.mainLayer = nil
    self.updateScheduleID = 0
end

function updateLayer:dtor()
    if self.updateScheduleID ~= 0 then
	    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.updateScheduleID)
        self.updateScheduleID = 0
	end
    if self.mainLayer ~= nil then
        self.mainLayer:removeFromParent()
        self.mainLayer = nil
    end
end


function updateLayer:initLayer()
    self.mainLayer = cc.LayerColor:create(cc.c4b(40, 0, 0, 255), CC_DESIGN_RESOLUTION.width / 2, CC_DESIGN_RESOLUTION.height / 2)

    local support = false
    if (cc.PLATFORM_OS_IPHONE == targetPlatform) or (cc.PLATFORM_OS_IPAD == targetPlatform) 
        or (cc.PLATFORM_OS_WINDOWS == targetPlatform) or (cc.PLATFORM_OS_ANDROID == targetPlatform) 
        or (cc.PLATFORM_OS_MAC  == targetPlatform) then
        support = true
    end

    if not support then
        print("Platform is not supported!")  --平台不支持
        return nil
    end

    --进度条
    local loadingBar = ccui.LoadingBar:create("res/ui/button/btn07.png")
    loadingBar:setAnchorPoint(cc.p(0.5, 0.5))
    loadingBar:setPosition(self.mainLayer:getContentSize().width / 2, self.mainLayer:getContentSize().height / 3)
    loadingBar:setScaleY(0.5)
    loadingBar:setTag(11)
    self.mainLayer:addChild(loadingBar)
    --进度显示
    local barLabel = cc.Label:createWithSystemFont("", "Arial", 40)
    barLabel:setAnchorPoint(cc.p(0.5, 0.5))
    barLabel:setPosition(self.mainLayer:getContentSize().width / 2, self.mainLayer:getContentSize().height / 3 - loadingBar:getContentSize().height * 2)
    barLabel:setTag(12)
    self.mainLayer:addChild(barLabel)


    local assetsManager = nil
    local pathToSave = createDownloadDir()   --创建tmpdir，当作本地保存路径
    print("pathToSave =   " .. pathToSave)

    addSearchPath(pathToSave .. "/package", true)



    local function onError(errorCode)
        if self.updateScheduleID ~= 0 then
	        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.updateScheduleID)
            self.updateScheduleID = 0
	    end
        if errorCode == cc.ASSETSMANAGER_NO_NEW_VERSION then
            barLabel:setString("当前为最新版本")
            self:changeGame()

        elseif errorCode == cc.ASSETSMANAGER_NETWORK then
            barLabel:setString("网络地址有误")
            self:changeGame()
        end
    end

    local function onProgress(percent)
        loadingBar:setPercent(percent)
        barLabel:setString("updating " .. tostring(percent) .. "%")
    end

    local function onSuccess()
        loadingBar:setPercent(100)
        barLabel:setString("更新成功!")
        if self.updateScheduleID ~= 0 then
	        cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.updateScheduleID)
            self.updateScheduleID = 0
	    end

        self:changeGame()
    end

    local function getAssetsManager()
        if nil == assetsManager then
            assetsManager = cc.AssetsManager:new(
                "https://raw.github.com/samuele3hu/AssetsManagerTest/master/package.zip",   --源代码上写的地址
                "https://raw.github.com/samuele3hu/AssetsManagerTest/master/version",
                pathToSave
            )
            assetsManager:retain()
            assetsManager:setDelegate(onError, cc.ASSETSMANAGER_PROTOCOL_ERROR)
            assetsManager:setDelegate(onProgress, cc.ASSETSMANAGER_PROTOCOL_PROGRESS)
            assetsManager:setDelegate(onSuccess, cc.ASSETSMANAGER_PROTOCOL_SUCCESS)
            assetsManager:setConnectionTimeout(3)   --连接超时
        end

        return assetsManager
    end

    local function update()
        loadingBar:setPercent(0)
        barLabel:setString("开始检查更新")
        getAssetsManager():checkUpdate()  --检查更新
        self:updateing()
    end

    local function reset()
        barLabel:setString("删除旧版本")
        deleteDownloadDir(pathToSave)
        getAssetsManager():deleteVersion()   --删除版本
        createDownloadDir()
    end



    update()

    return self.mainLayer
end

--倒计时用
function updateLayer:updateing()
    local countdownTime = 0
    local function doUpdate()
        if self.mainLayer:getChildByTag(12) then
            countdownTime = countdownTime + 1
            self.mainLayer:getChildByTag(12):setString("开始检查更新  " .. tostring(countdownTime) .. "s")
            print(string.format("检查更新  %d s", countdownTime))
        end
    end


    if self.updateScheduleID ~= 0 then
	    cc.Director:getInstance():getScheduler():unscheduleScriptEntry(self.updateScheduleID)
        self.updateScheduleID = 0
	end
    self.updateScheduleID = cc.Director:getInstance():getScheduler():scheduleScriptFunc(doUpdate, 1, false)
end


--切换到游戏界面
function updateLayer:changeGame()
    performWithDelay(
        self.mainLayer, 
        function()
            self.mainLayer:getChildByTag(12):setString("网络地址有误")
            self:dtor()
           -- loadCSVFiles()
            --loadCsvClient()
            require("game")
        end,
        0.3   --0.3秒钟后关闭该界面，进入游戏
    )
end