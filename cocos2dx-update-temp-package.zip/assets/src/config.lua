
-- 0 - disable debug info, 1 - less debug info, 2 - verbose debug info
DEBUG = 1--2

-- use framework, will disable all deprecated API, false - use legacy API
CC_USE_FRAMEWORK = true

-- show FPS on screen
CC_SHOW_FPS = true

-- disable create unexpected global variable
CC_DISABLE_GLOBAL = false

-- for module display
CC_DESIGN_RESOLUTION = {
    width = 1920,
    height = 1080,
    autoscale = "FIXED_HEIGHT",
    callback = function(framesize)
        local width = CC_DESIGN_RESOLUTION.width
        local height = CC_DESIGN_RESOLUTION.height
        local widthratio = framesize.width / width
        local heightratio = framesize.height/height
        if widthratio > heightratio then
            -- iPad 768*1024(1536*2048) is 4:3 screen            
            return {autoscale = "FIXED_WIDTH", resolutionRate = heightratio/widthratio}
        else        
           return {autoscale = "FIXED_HEIGHT", resolutionRate = widthratio/heightratio}           
        end
    end
}


--edit by lina
CC_EDIT_MAP = false

