MsgCode =
{
    --- 主命令
    LOAD_SCENE = 0,
    LOAD_LAYERS = 1,
    REMOVE_LAYERS = 2,
    GO_BACK = 3,
    GO_TO_SCENE = 4,
    -- 存储数据命令
    LOAD_USER_DATA = 100,
    SAVE_USER_DATA = 101,

    -- 登陆系统
    USER_LOGIN_SUCCESS = 200,
    HEATH_BAR_PLANE = 201,
    USER_LOGIN_FAILED = 202,
    LOGIN = 203,
    GM_DATA_SORCE = 204,


    -- 打开地图编辑器
    LOAD_MAP_DATA = 300,
    SAVE_MAP_DATA = 301,


    ---主界面
    GET_LAB_POS = 1000,
    GMS_BTN_BACK2TOWN = 1001,
    GMS_BTN_WJ = 1002,
    GMS_BTN_NZ = 1003,
    GMS_BTN_GT = 1004,
    GMS_BTN_FL = 1005,
    GMS_BTN_JJ = 1006,
    GMS_BTN_KJ = 1007,
    GMS_DIALOG_TH = 1008,
    GMS_DIALOG_ATTACK = 1009,
    GMS_DIALOG_ZY = 1010,
    GMS_DIALOG_CH = 1011,
    GMS_DIALOG_SD = 1012,
    GMS_DIALOG_JS = 1013,
    GMS_DIALOG_HC = 1014,
    GMS_DIALOG_ATTACK_CAMP = 1015,
    --主地图
    MAP_CHANGE_GRID = 2000,
    MAP_OBJECT_MOVE = 2001,
    MAP_GRID_BURNING = 2002,
    MAP_ARMY_MOVE = 2003,
    MAP_ROLE_REACH_DEST = 2004,
    MAP_ROLE_DEAD = 2005,
    MAP_OCCUPY = 2006,
    
    MAP_ENCAMP_FINISH = 2010,

    MAINSCENE_DLG_LAYER_CHANGES = 3001,
    MAINSCENE_DLG_LAYER_REMOVE = 3002,


    MAINSCENE_OTHER_PRINT_OUTPUT = 3004,  --输出output
    MAINSCENE_OTHER_SLIDER = 3005,       --滑动条
    MAINSCENE_OTHER_CHECKBOX = 3006,     --复选框
    MAINSCENE_OTHER_LISTVIEW = 3007,    --listview
}

GAME = {}

for k, v in pairs(MsgCode) do
    GAME[k] = k
end

SCENE =
{
    MAIN = { s = "MainScene", m = "MainMediator" },
    MAPEDIT = { s = "MapEditScene", m = "MapEditMediator" },
    LAYERMAP = {s = "GameMapScene", m = "GameMapMediator"},
    TOOLPANEL = {s = "GameToolPanel", m = "GameToolMediator"},
    MIANDLGLAYER = {s = "MainSceneDialogLayer", m = "MainSceneDialogMediator"},

    OTHERLAYER = {s = "OtherDialogLayer", m = "OtherDialogMediator"},   --other UI
}

MapType = 
{
    FirstLayer = 1,
    SecondLayer = 2,
}

EnumStateType =
{
    "IDLE",
    "WALKING",
    "ATTACKING",
    "DYING",
    "DEAD"
}
EnumStateType = CreateEnumTable(EnumStateType)


