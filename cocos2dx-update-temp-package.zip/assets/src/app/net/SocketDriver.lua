local socket = require "socket"

local SocketDriver = class("SocketDriver")
local scheduler = require("cocos.framework.scheduler")

SocketDriver.EVENT_DATA = "SOCKETDRIVER:EVENT_DATA"
SocketDriver.EVENT_CLOSE = "SOCKETDRIVER:EVENT_CLOSE"
SocketDriver.EVENT_ERROR = "SOCKETDRIVER:EVENT_ERROR"
SocketDriver.EVENT_CONNECTED = "SOCKETDRIVER:EVENT_CONNECTED"

local STATUS_ALREADY_CONNECTED = "already connected"
local STATUS_CLOSED = "closed"
local STATUS_NOT_CONNECTED = "Socket is not connected"

local SOCKET_TICK_TIME = 0.1 			-- check socket data interval
local SOCKET_CONNECT_FAIL_TIMEOUT = 3	-- socket failure timeout

function SocketDriver:ctor()
    cc.bind(self, "event")
end

function SocketDriver:connect(ip, port)
    self.host = ip or self.host
    self.port = port or self.port
    self.tcp = socket.tcp()
    self.tcp:settimeout(0)
    self:checkConnect()
end

function SocketDriver:conncetStatus()
    if self.isconnect then
        return true
    end

    return false
end

function SocketDriver:checkConnect()
    print(" SocketDriver:checkConnect")
    local succ, status = self.tcp:connect(self.host, self.port)

    -- print("SocketDriver._connect:", __succ, __status)
    if succ == 1 or status == STATUS_ALREADY_CONNECTED then
        self.isconnect = true
        self:dispatchEvent( { name = SocketDriver.EVENT_CONNECTED })
        if self.connectTick then
            scheduler.unscheduleGlobal(self.connectTick)
            self.connectTick = nil
            return true
        end
        return 
    end

    if self.connectTick == nil then
        self.connectTick = scheduler.scheduleGlobal(handler(self, self.checkConnect), SOCKET_TICK_TIME)
        return 
    end

    self.waitConnect = self.waitConnect or 0
    self.waitConnect = self.waitConnect + SOCKET_TICK_TIME
    if self.waitConnect < SOCKET_CONNECT_FAIL_TIMEOUT then
        return false
    end

    self.waitConnect = nil

    self:close()
    self:dispatchEvent( { name = SocketDriver.EVENT_ERROR })
    if self.connectTick then
        scheduler.unscheduleGlobal(self.connectTick)
        self.connectTick= nil
    end

    return false
end

function SocketDriver:recv()
    local msg = ""
    while true do
        local body, status, partial = self.tcp:receive("*a")
        if status == STATUS_CLOSED or status == STATUS_NOT_CONNECTED then

            self:close()  
            self:dispatchEvent( { name = SocketDriver.EVENT_ERROR })      
            return
        end
        if (body and string.len(body) == 0) or
            (partial and string.len(partial) == 0)
        then
            return msg
        end

        if body then msg = msg .. body end
        if partial then msg = msg .. partial end
    end
end

function SocketDriver:send(data)
    self.tcp:send(data)
end

function SocketDriver:reconnect()
    self:connect()
end

function SocketDriver:close()
    self.tcp:close()
    if self.connectTick then scheduler.unscheduleGlobal(self.connectTick) end
    self:dispatchEvent( { name = SocketDriver.EVENT_CLOSE })
end

return SocketDriver