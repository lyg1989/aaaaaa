--其他地方没用但仍有借用价值的代码
function GameMapScene:initScrollView()
    local function listViewEvent(sender, eventType)
        if eventType == ccui.ListViewEventType.ONSELECTEDITEM_START then
            --            print("select child index = ",sender:getCurSelectedIndex())
        end
    end

    local function scrollViewEvent(sender, evenType)
        if evenType == ccui.ScrollviewEventType.scrollToBottom then
            --            print("SCROLL_TO_BOTTOM")
        elseif evenType ==  ccui.ScrollviewEventType.scrollToTop then
            --            print("SCROLL_TO_TOP")
        end
    end

    local listView = ccui.ListView:create()
    -- set list view ex direction
    listView:setDirection(ccui.ScrollViewDir.vertical)
    listView:setTouchEnabled(true)
    listView:setBounceEnabled(true)
    listView:setBackGroundImage("cocosui/green_edit.png")
    listView:setBackGroundImageScale9Enabled(true)
    listView:setContentSize(cc.size(300, cc.Director:getInstance():getWinSize().height))
    --    listView:setAnchorPoint(cc.p(0.5, 0))
    listView:setPosition(cc.p(800, 0))
    --    listView:setItemsMargin(0)
    listView:addEventListener(listViewEvent)
    listView:addScrollViewEventListener(scrollViewEvent)
    -- create model
    --    local default_button = ccui.Button:create("backtotoppressed.png", "backtotopnormal.png")
    --    default_button:setName("Title Button")
    --
    --    local default_item = ccui.Layout:create()
    --    default_item:setTouchEnabled(true)
    --    default_item:setContentSize(default_button:getContentSize())
    --    default_button:setPosition(cc.p(default_item:getContentSize().width / 2.0, default_item:getContentSize().height / 2.0))
    --    default_item:addChild(default_button)
    --
    --    --set model
    --    listView:setItemModel(default_item)

    self.layer:addChild(listView)
    local innerWidth = listView:getContentSize().width

    local szConf = io.readfile('res/config/tmx_file.txt')
    local tbConf = string.split(szConf, '|')
    local szTmxFile = tbConf[1]
    if szTmxFile == '' then
        return
    end

    local szLayerInfo = tbConf[2]
    local tbLayerInfo_conf = string.split(szLayerInfo, '&')

    local tbLayerInfo = { }
    for nIndex, szInfo in ipairs(tbLayerInfo_conf) do
        if nIndex % 2 ~= 0 then
            local szLayerName = tbLayerInfo_conf[nIndex]
            local nTotalGrid = tonumber(tbLayerInfo_conf[nIndex + 1])
            tbLayerInfo[szLayerName] = nTotalGrid
        end
    end
    local map = ccexp.TMXTiledMap:create(szTmxFile)
    local tbSprTile = { }
    local testY = 100
    for szLayerName, nTotalGrid in pairs(tbLayerInfo) do
        local layer = map:getLayer(szLayerName)
        local sizeLayer = layer:getLayerSize()
        local nTileCount = 1
        for x = 0, sizeLayer.width - 1 do
            for y = 0, sizeLayer.height - 1 do

                --                local sprNewTile = cc.Sprite:create('res/map/cell1.png')
                local sprExist = layer:getTileAt(cc.p(x, y))
                local nGid = layer:getTileGIDAt(cc.p(x, y));
                local tileSet = layer:getTileSet()
                local rect = tileSet:getRectForGID(nGid);
                if sprExist then
                    local sprNewTile = cc.Sprite:createWithTexture(sprExist:getTexture(), rect)
                    --                    sprNewTile:setScale(0.5)
                    sprNewTile:setPosition(cc.p(innerWidth / 2, sprNewTile:getContentSize().height / 2))
                    --                    table.insert(tbSprTile, sprNewTile)

                    local custom_item = ccui.Layout:create()
                    custom_item:setTouchEnabled(true)
                    custom_item:setContentSize(sprNewTile:getContentSize())
                    custom_item:addChild(sprNewTile)
                    listView:pushBackCustomItem(custom_item)
                    --                    listView:addChild(sprNewTile)

                    --                    local custom_button = ccui.Button:create("button.png", "buttonHighlighted.png")
                    --                    custom_button:setName("Title Button")
                    --                    custom_button:setScale9Enabled(true)
                    ----                    custom_button:setContentSize(default_button:getContentSize())
                    --                    custom_button:setContentSize(cc.size(100, 50))
                    --
                    --                    local custom_item = ccui.Layout:create()
                    --                    custom_item:setContentSize(custom_button:getContentSize())
                    --                    custom_button:setPosition(cc.p(custom_item:getContentSize().width / 2.0, custom_item:getContentSize().height / 2.0))
                    --                    custom_item:addChild(custom_button)
                    --                    listView:pushBackCustomItem(custom_item)

                    testY = testY + 200

                    nTileCount = nTileCount + 1
                    if nTileCount > nTotalGrid then
                        break
                    end
                end
            end
            if nTileCount > nTotalGrid then
                break
            end
        end
    end

    --    m_tamara = layer:getTileAt( cc.p(29,29) )
end