recManager = {}

function recManager.getInstance()
       recManager = recManager or {}
       return recManager
end

function recManager.clear()
    recManager:removeMyPlaneAnimation()
end

function recManager.getSprite(id)
    print("recManager.getSprite", id)
    local img=getCSVField("imgpath")
    local bgPath=img[id]
    return bgPath.path
end


	
