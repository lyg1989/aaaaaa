local BaseViewComponent = require("app/views/BaseViewComponent")

SceneManager = {}

function SceneManager.transCross(from, to, onFinishCallback)
    -- TO load()
    -- TO loading
    -- TO loaded
    -- FROM exit()
    -- FROM didExit
    -- TO enter()
    -- TO didEnter
    -- callback()

    local function didEnter(e)
        onFinishCallback(to)
    end

    local function didExit(e)
        if to ~= nil then
            to:addEventListener(BaseViewComponent.DID_ENTER, didEnter)
            to:enter()
        else
            didEnter()
        end
    end

    local function onLoaded(e)
        if from ~= nil then
            from:addEventListener(BaseViewComponent.DID_EXIT, didExit)
            from:exit()
        else
            didExit()
        end
    end

    if to == nil or to:isLoaded() then
        onLoaded()
    else
        to:addEventListener(BaseViewComponent.LOADED, onLoaded)
        to:load()
    end
end

function SceneManager.transOneByOne(from, to, onFinishCallback)
    -- FROM exit()
    -- FROM didExit
    -- TO load()
    -- TO loading
    -- TO loaded
    -- TO enter()
    -- TO didEnter
    -- callback()

    local function didEnter(e)
        onFinishCallback(to)
    end

    local function onLoaded(e)
        if to ~= nil then
            to:addEventListener(BaseViewComponent.DID_ENTER, didEnter)
            to:enter()
        else
            didEnter()
        end
    end

    local function didExit(e)
        if to == nil or to:isLoaded() then
            onLoaded()
        else
            to:addEventListener(BaseViewComponent.LOADED, onLoaded)
            to:load()
        end
    end

    if from ~= nil then
        from:addEventListener(BaseViewComponent.DID_EXIT, didExit)
        from:exit()
    else
        didExit()
    end
end

function SceneManager.overlay(parent, child, onFinish)

    -- CHILD load()
    -- CHILD loading
    -- CHILD loaded
    -- CHILD attach()
    -- CHILD enter()
    -- CHILD didEnter
    -- callback()
--    dump(parent)
--    dump(child)
    local function didEnter(e)
        onFinish(child)
    end

    local function onLoaded(e)
        if child ~= nil then
            child:attach(parent)
            child:addEventListener(BaseViewComponent.DID_ENTER, didEnter)
            child:enter()
        else
            didEnter()
        end
    end

    if child == nil or child:isLoaded() then
        onLoaded()
    else
        child:addEventListener(BaseViewComponent.LOADED, onLoaded)
        child:load()
    end
end

function SceneManager.remove(viewComponent, onFinishCallback)

    -- CHILD exit()
    -- CHILD didExit
    -- callback()

    if viewComponent ~= nil then
        if onFinishCallback then
            viewComponent:addEventListener(BaseViewComponent.DID_EXIT, onFinishCallback)
        end

        viewComponent:exit()
    end
end