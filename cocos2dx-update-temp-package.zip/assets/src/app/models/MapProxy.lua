local MapProxy = class('MapProxy', Proxy)



MapProxy.w = 150
-- 小地图的格子数
MapProxy.cellWidth = 20
MapProxy.cellHeight = 20

-- 小地图个数
MapProxy.gridW = 100
MapProxy.gridH = 100

MapProxy.map = { }

MapProxy.MinMap = 10

MapProxy.mapLineCheck = { }
MapProxy.CityLine = { }
MapProxy.cellProperty = {}

--省份所属势力范围
MapProxy.tbBlock2Force = {}
MapProxy.tbForce2Block = {}

MapLineStaus =
{
    NonConnect = 0,
    Connect = 1,
    DrawSplit = 2,
}

function MapProxy:onRegister()
    --    local data = self:getData()
    --    self.heros = {}
    --    local heroConfig = getCSVField("heros")
    --    for k, v in pairs(heroConfig) do
    --        --self.heros[k] = HeroObject:create(k, v)
    --        self:AddHero(k, v)
    --    end
    --    self:setData({})
    for i = 1, 4 do
        cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/block/map" .. i .. ".plist")
    end

    for i = 1, 10 do
        cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/block/map22" .. i .. ".plist")
    end
    local info = getCSVField("mapInfo")
--    dump(csv, 'csv2')
    self.mapInfo = { }
    for k, v in pairs(info) do
        --print("map info...........", k, v)
        if self.mapInfo[v.row] == nil then

            self.mapInfo[v.row] = { }
        end

        self.mapInfo[v.row][v.col] = v
    end
    self:getMapSize()
    self.mapLineCheck = { }
    self.CityLine = { }
    self.cellProperty = { }
end

function MapProxy:getMapInfo(row, col)
  
    if self.mapInfo[row] then
        return self.mapInfo[row][col]
    end

    return nil
end

function MapProxy:getMapSize()
    --    local h = self.cellHeight * self.h
    --    local w = self.cellWidth * self.h * math.sqrt(3) / 2

    local w = self.cellWidth * self.w
    local h = self.cellHeight * self.w * math.sqrt(3) / 2

    self.mapSize = cc.size(w, h)
    self.r = self.w / math.sqrt(3)
end

function MapProxy:clear()
    self.map = { }
    if self.mapSize == nil then
        self:getMapSize()
    end

    self.count = 0
end





function MapProxy:getWholeMapSize()
    return cc.size(self.mapSize.width * self.gridW, self.mapSize.height * self.gridH)
end

function MapProxy:getLoadMap(pos)
    if pos.x < 0 then
        pos.x = 0
    end

    if pos.y < 0 then
        pos.y = 0
    end

    if pos.x > self.mapSize.width * self.gridW then
        pos.x = self.mapSize.width * self.gridW - 1
    end

    if pos.y > self.mapSize.height * self.gridH then
        pos.y = self.mapSize.height * self.gridH - 1
    end

    local x = math.floor(pos.x / self.mapSize.width)
    local y = math.floor(pos.y / self.mapSize.height)

    return cc.p(x, y)

end 

function MapProxy:releaseMap(pos)
    -- self.center = pos

    local x = pos.x % self.mapSize.width
    local y = pos.y % self.mapSize.height

    for k, v in pairs(MapProxy.map) do
        for k1, v1 in pairs(v) do
            if math.abs(x - k) > 3 and math.abs(y - k1) > 3 then

                v1:removeSelf()
                MapProxy.count = self.count - 1
            end

            if MapProxy.count < self.MinMap then
                return
            end
        end
    end
end 



function MapProxy:checkCellTouch(pos)
    -----xiazhou jixu kan  8.5
    --- 8.25修改
    -- local cell = cc.p(self.r * 3, self.h)
    local cell = cc.p(self.w, self.r * 3)
    local grid = cc.p(0, 0)
    local pos4 = cc.p(0, 0)
    grid.y = math.floor(pos.y / cell.y) * 2
    if pos.y - cell.y * grid.y / 2 < self.r * 2 then
        if pos.x < cell.x / 2 then
            print("not  a  grid, posx < ", cell.x / 2)
            return
        end

        grid.x = math.floor((pos.x - cell.x / 2) / cell.x)
        pos4.y = cell.y * grid.y / 2 + self.r
        pos4.x = grid.x * cell.x + cell.x

        local h = math.abs(pos.y - pos4.y)
        local w = math.abs(pos.x - pos4.x)

        local heng = math.abs(self.r - h)
        local shu = w / math.sqrt(3)
        --print("heng ....shu....", self.r, h, w, heng, shu)
        if heng < shu then
            if pos.y > pos4.y then
                grid.y = grid.y + 1
                pos4.y = pos4.y + cell.y / 2
            else
                grid.y = grid.y - 1
                pos4.y = pos4.y - cell.y / 2
            end

            if pos.x > pos4.x then
                grid.x = grid.x + 1
                pos.x = pos4.x + cell.x / 2
            else
                -- grid.x = grid.x - 1
                pos.x = pos4.x - cell.x / 2
            end
        end

    else
        grid.y = grid.y + 1
        grid.x = math.floor(pos.x / cell.x)

        --        if pos.x - grid.x * cell.x > self.w / 2 then
        --            grid.x = grid.x + 1
        --        end

        pos4.y = cell.y * grid.y / 2 + self.r * 5 / 2
        pos4.x = grid.x * self.w + self.w / 2

        local h = math.abs(pos.y - pos4.y)
        local w = math.abs(pos.x - pos4.x)

        local heng = math.abs(self.r - h)
        local shu = w / math.sqrt(3)
       -- print("heng ....shu....1", self.r, h, w, heng, shu)
        if heng < shu then
            if pos.y > pos4.y then
                grid.y = grid.y + 1
                pos4.y = pos4.y + cell.y / 2
            else
                pos4.y = pos4.y - cell.y / 2
                grid.y = grid.y - 1
            end

            if pos.x > pos4.x then
                grid.x = grid.x + 1
                pos4.x = pos4.x + cell.x / 2
            else
                grid.x = grid.x - 1
                pos4.x = pos4.x - cell.x / 2
            end
        end
    end


--   print("select pos..............pos, center, grid ", pos.x, pos.y, pos4.x, pos4.y, grid.x, grid.y)
    return grid

end


function MapProxy:checkPointLine(proper, version)

    if proper.lu and proper.lu < version then
        return true
    end

    if proper.ru and proper.ru < version then
        return true
    end

    if proper.l and proper.l < version then
        return true
    end

    if proper.r and proper.r < version then
        return true
    end

    if proper.ld and proper.ld < version then
        return true
    end

    if proper.rd and proper.rd < version then

        return true
    end

    return false

end

function MapProxy:getCellPos(x, y)
    local pos = cc.p(0, 0)
    if y % 2 == 0 then
        pos.x = self.w *(x + 1)
    else

        pos.x = self.w *(x + 1) - self.w / 2
    end

    pos.y = y * self.r * 3 / 2 + self.r

    return pos

end

--给某个未占领的格子标色
function MapProxy:addNewGrid(xpos, ypos, grid)
    local proper = { }
    proper.gid = grid

    if not self.cellProperty[ypos] then
        self.cellProperty[ypos] = { }
    end
    self.cellProperty[ypos][xpos] = proper
    proper.pos = cc.p(xpos, ypos)
    proper.mapPos = cc.p(math.floor((xpos - 1) / self.cellWidth), math.floor((ypos - 1) / self.cellHeight))

    self:checkForLine(xpos, ypos, proper)
end

function MapProxy:ChangeGrid(x, y, nNewGrid)
    if nNewGrid ~= 0 and not self.cellProperty[y][x] then
        self:addNewGrid(x, y, 0)
    end
    local mapPos = self.cellProperty[y][x].mapPos
    for k, v in pairs (self.cellProperty) do
        if k == y then
            for k1, v1 in pairs (v) do
                if k1 == x and v1.gid ~= nNewGrid then
                    v1.gid = nNewGrid
                    self:checkForLine(k1, k, v1)
                    local map = self.map[mapPos.x][mapPos.y]
                    local block = map:getLayer("block")
                    local x_tiled = x % self.cellWidth
                    local y_tiled = self.cellHeight - 1 - y

--                    removeTileAt
--                    local nGid = block:getTileGIDAt(cc.p(x_tiled, y_tiled))
                    if nNewGrid == 0 then
                        block:removeTileAt(cc.p(x_tiled, y_tiled))
                    else
                        block:setTileGID(nNewGrid, cc.p(x_tiled, y_tiled))
                    end
                    game:sendNotification(GAME.MAP_CHANGE_GRID, {})     

                    break
                end
            end
        end
    end
end


function MapProxy:checkForLine(xpos, ypos, proper)
    local index = -1
    if ypos % 2 == 0 then
        index = 1
    end
    proper.ld = MapLineStaus.Connect
    proper.rd = MapLineStaus.Connect
    proper.l = MapLineStaus.Connect
    proper.r = MapLineStaus.Connect
    proper.lu = MapLineStaus.Connect
    proper.ru = MapLineStaus.Connect
    if self.cellProperty[ypos - 1] then
        -- print("gid........................", proper.gid, self.cellProperty[ypos - 1][xpos].gid)
        if self.cellProperty[ypos - 1][xpos] and self.cellProperty[ypos - 1][xpos].gid == proper.gid then

            if index == 1 then
                proper.ld = nil
                self.cellProperty[ypos - 1][xpos].ru = nil
                -- checkUnLine(self.cellProperty[ypos - 1][xpos])
            else
                proper.rd = nil
                self.cellProperty[ypos - 1][xpos].lu = nil

            end

        end

        if self.cellProperty[ypos-1][xpos + index] and self.cellProperty[ypos-1][xpos+index].gid == proper.gid then
            if index == 1 then
                proper.rd = nil
                self.cellProperty[ypos-1][xpos + index].lu = nil
            else
                proper.ld = nil
                self.cellProperty[ypos-1][xpos + index].ru = nil
                -- checkUnLine(self.cellProperty[ypos - 1][xpos+index])
            end

        end
    end

    if self.cellProperty[ypos][xpos-1] and self.cellProperty[ypos][xpos-1].gid == proper.gid then
        proper.l = nil
        self.cellProperty[ypos][xpos-1].r = nil
    end

    if self.cellProperty[ypos][xpos+1] and self.cellProperty[ypos][xpos+1].gid == proper.gid then
        proper.r = nil
        self.cellProperty[ypos][xpos+1].l = nil
    end

    if self.cellProperty[ypos + 1] then
        -- print("gid........................", proper.gid, self.cellProperty[ypos - 1][xpos].gid)
        if self.cellProperty[ypos + 1][xpos] and self.cellProperty[ypos + 1][xpos].gid == proper.gid then

            if index == 1 then
                proper.lu = nil
                self.cellProperty[ypos + 1][xpos].rd = nil
                -- checkUnLine(self.cellProperty[ypos - 1][xpos])
            else
                proper.ru = nil
                self.cellProperty[ypos + 1][xpos].ld = nil

            end

        end

        if self.cellProperty[ypos + 1][xpos + index] and self.cellProperty[ypos + 1][xpos + index].gid == proper.gid then
            if index == 1 then
                proper.ru = nil
                self.cellProperty[ypos + 1][xpos + index].ld = nil
            else
                proper.lu = nil
                self.cellProperty[ypos + 1][xpos + index].rd = nil
                -- checkUnLine(self.cellProperty[ypos - 1][xpos+index])
            end

        end
    end



end

function MapProxy:createCityLine(nMapX, nMapY, map)
--    print('createCityLine')
    if self.mapLineCheck[nMapX] == nil then
        self.mapLineCheck[nMapX] = { }
    end

    if self.mapLineCheck[nMapX][nMapY] then
        return
    end

    self.mapLineCheck[nMapX][nMapY] = true

    local startX = nMapX * self.cellWidth
    local startY = nMapX * self.cellHeight + self.cellHeight - 1

--格子属性，改为从grid.csv读取
--    local block = map:getLayer("block")
--    for i = self.cellHeight - 1, 0, -1 do
--        for j = 0, self.cellWidth - 1 do
--            local xpos = startX + j
--            local ypos = startY - i
--            local gid = block:getTileGIDAt(cc.p(j, i))
--
--            if gid > 0 then
--
--                local proper = { }
--                proper.gid = gid
--
--                if not self.cellProperty[ypos] then
--                    self.cellProperty[ypos] = { }
--                end
--                self.cellProperty[ypos][xpos] = proper
--                proper.pos = cc.p(xpos, ypos)
--                proper.mapPos = cc.p(x, y)
--
--                self:checkForLine(xpos, ypos, proper)
--
--            end
--        end
--    end
--    dump(self.cellProperty, 'self.cellProperty')
end

function MapProxy:LoadCellProperty(nMapX, nMapY)
    self.cellProperty = areaConfig
end

function MapProxy:Tmp_InitForceBlock()
    for i = 1, 103 do
        local nForce = 0
        if i >= 1 and i <= 10 then
            nForce = 1
        elseif i >= 11 and i <= 19 then
            nForce = 2
        elseif i >= 20 and i <= 30 then
            nForce = 3
        elseif i >= 31 and i <= 39 then
            nForce = 4
        elseif i >= 40 and i <= 64 then
            nForce = 5
        elseif i >= 65 and i <= 71 then
            nForce = 6
        elseif i >= 72 and i <= 83 then
            nForce = 7
        elseif i >= 84 and i <= 90 then
            nForce = 8
        elseif i >= 91 and i <= 96 then
            nForce = 9
        elseif i >= 97 and i <= 103 then
            nForce = 10
        end
        local szName = LocalizePS.GetStr("FORCE_NAME", nForce.tostring())
        self.tbBlock2Force[i] = nForce
        self.tbForce2Block[nForce] = self.tbForce2Block[nForce] or {
            tbBlockList = {},
            szName = szName,
            nBottom = 10000,
            nTop = -10000,
            nLeft = 10000,
            nRight = -10000
        }
        self.tbForce2Block[nForce].tbBlockList[i] = {}
    end
end

function MapProxy:GetLongestLine(param)
    local posBottomLeft = param.posBottomLeft
    local posBottomRight = param.posBottomRight
    local posTopLeft = param.posTopLeft
    local posTopRight = param.posTopRight
    local posLeftTop = param.posLeftTop
    local posLeftBottom = param.posLeftBottom
    local posRightTop = param.posRightTop
    local posRightBottom = param.posRightBottom

    local tbSortList = {}
    table.insert(tbSortList, {
        posSrc = posBottomLeft,
        posDest = posTopLeft,
        nLong = GetDis(posBottomLeft, posTopLeft)
    })
    table.insert(tbSortList, {
        posSrc = posBottomLeft,
        posDest = posTopRight,
        nLong = GetDis(posBottomLeft, posTopRight)
    })
    table.insert(tbSortList, {
        posSrc = posBottomRight,
        posDest = posTopLeft,
        nLong = GetDis(posBottomRight, posTopLeft)
    })
    table.insert(tbSortList, {
        posSrc = posBottomRight,
        posDest = posTopRight,
        nLong = GetDis(posBottomRight, posTopRight)
    })
    table.insert(tbSortList, {
        posSrc = posLeftTop,
        posDest = posRightTop,
        nLong = GetDis(posLeftTop, posRightTop)
    })
    table.insert(tbSortList, {
        posSrc = posLeftTop,
        posDest = posRightBottom,
        nLong = GetDis(posLeftTop, posRightBottom)
    })
    table.insert(tbSortList, {
        posSrc = posLeftBottom,
        posDest = posRightTop,
        nLong = GetDis(posLeftBottom, posRightTop)
    })
    table.insert(tbSortList, {
        posSrc = posLeftBottom,
        posDest = posRightBottom,
        nLong = GetDis(posLeftBottom, posRightBottom)
    })
--    dump(tbSortList, 'tbSortList----111')
    table.sort(tbSortList, function(a, b)
        return a.nLong > b.nLong
    end)
--    dump(tbSortList[1], 'tbSortList----222')
    return tbSortList[1]
end

function MapProxy:IsMyDomain(tbTouchPos)
    local tbCheck = {}
    table.insert(tbCheck, {x = tbTouchPos.x - 1, y = tbTouchPos.y})
    table.insert(tbCheck, {x = tbTouchPos.x + 1, y = tbTouchPos.y})
    table.insert(tbCheck, {x = tbTouchPos.x, y = tbTouchPos.y - 1})
    table.insert(tbCheck, {x = tbTouchPos.x, y = tbTouchPos.y + 1})
    if (tbTouchPos.y % 2 == 0) then
        table.insert(tbCheck, {x = tbTouchPos.x + 1, y = tbTouchPos.y + 1})
        table.insert(tbCheck, {x = tbTouchPos.x + 1, y = tbTouchPos.y - 1})
    else
        table.insert(tbCheck, {x = tbTouchPos.x - 1, y = tbTouchPos.y + 1})
        table.insert(tbCheck, {x = tbTouchPos.x - 1, y = tbTouchPos.y - 1})
    end
    for _, tbPos in ipairs(tbCheck) do
        if tbPos.x > 0 and tbPos.x <= self.cellWidth and
                tbPos.y > 0 and tbPos.y <= self.cellHeight and
                self.cellProperty[tbPos.y][tbPos.x] and
                self.cellProperty[tbPos.y][tbPos.x].gid == 3 then
            return true
        end
    end
    return false
end

return MapProxy