local SaveGameDataCommand = class('SaveGameDataCommand', SimpleCommand)

require("src.init.tablesave")
--local HeroProxy = require("app/models/HeroProxy")
--local PlayerProxy = require("app/models/PlayerProxy")
--local ItemProxy = require("app/models/ItemProxy")

function SaveGameDataCommand:execute(note)
    local data = note:getBody()

    --jia zai youxi  shuju
--    local info = {}
--    local proxy = getProxy("PlayerProxy")     
--    proxy:Save(info)
--    local proxy = getProxy("ItemProxy")     
--    proxy:Save(info)
--    local proxy = getProxy("HeroProxy")     
--    proxy:Save(info) 

--    local userinfo = table.save(info)

--    cc.UserDefault:getInstance():setStringForKey("user", userinfo)        
   -- game:sendNotification(GAME.GO_TO_SCENE, {transType = Context.TRANS_TYPE.ONE_BY_ONE}, SCENE.MAIN)  
   
 cc.Director:getInstance():endToLua()            
end

return SaveGameDataCommand