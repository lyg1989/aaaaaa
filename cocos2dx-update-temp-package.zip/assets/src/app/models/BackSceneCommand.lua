local BackSceneCommand = class('BackSceneCommand', SimpleCommand)

function BackSceneCommand:execute(note)
    local data = note:getBody()

    local contextProxy = game:retrieveProxy("ContextProxy")
    if contextProxy:getContextCount() > 1 then
        local currentContext = contextProxy:popContext()
        local prevContext = contextProxy:popContext()
       prevContext:extendData(data)

        self:sendNotification(GAME.LOAD_SCENE, {
            prevContext = currentContext,
            context = prevContext
        })
    end
end

return BackSceneCommand