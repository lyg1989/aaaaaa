local SocketDriver = require "app.net.SocketDriver"
local sproto = require "app.net.sproto"

local Message = class("Message", Proxy)
require("pack")

function Message:onRegister()
    self.var = {
        session_id = 0,
        session = { },
        object = { },
    }

    self.socket = nil
    self.data = nil
    self.schedulerID = nil
    local PATH = "src/app"
    self:loadProto(string.format("%s/proto/%s", PATH, "proto"))
end

function Message:loadProto(name)
    local var = self.var
    local filePath = CCFileUtils:getInstance():fullPathForFilename(name .. ".s2c.sproto")
    var.host = sproto.parse(CCFileUtils:getInstance():getStringFromFile(filePath)):host "package"
    local filePath = CCFileUtils:getInstance():fullPathForFilename(name .. ".c2s.sproto")
    var.request = var.host:attach(sproto.parse(CCFileUtils:getInstance():getStringFromFile(filePath)))
end


function Message:initNet()

    self.socket = SocketDriver:create()
    local socket = self.socket
    self.data = ""

    function onNetStatus(event)
        local scheduler = cc.Director:getInstance():getScheduler()
        if event.name == SocketDriver.EVENT_CONNECTED then
            self:request("signin", { userid = "alice" })
            data = nil

            schedulerID = scheduler:scheduleScriptFunc( function()
                self:update()
            end , 0, false)
        end

        if event.name == SocketDriver.EVENT_CLOSED then
            print("SOCKET closed .........")
            if schedulerID then
                scheduler:unscheduleScriptEntry(schedulerID)
            end
        end
    end

    socket:addEventListener(SocketDriver.EVENT_CLOSE, onNetStatus)
    socket:addEventListener(SocketDriver.EVENT_ERROR, onNetStatus)
    socket:addEventListener(SocketDriver.EVENT_CONNECTED, onNetStatus)

end

function Message:peer(addr, port)
    self.var.addr = addr
    self.var.port = port
end

function Message:connect()
    self.socket:connect(self.var.addr, self.var.port)
end

function Message:bind(obj, handler)
    self.var.object[obj] = handler
end

function Message:request(name, args)
    local var = self.var
    var.session_id = var.session_id + 1
    var.session[var.session_id] = { name = name, req = args }
    local msg = var.request(name, args, var.session_id)
    local s = string.lpack(">P",msg)
    self.socket:send(s)
    return var.session_id
end




function Message:update(ti)
    local var = self.var
    local str = self.socket:recv()
    if not str or str == "" then
        return false
    end

    self.data = self.data .. str
    local ok, n, msg = pcall(string.lunpack, self.data, ">P")

    if not msg then
        return
    end

    self.data = self.data:sub(n)

    local t, session_id, resp, err = var.host:dispatch(msg)
    if t == "REQUEST" then
        for obj, handler in pairs(var.object) do
            local f = handler[session_id]
            -- session_id is request type
            if f then
                local ok, err_msg = pcall(f, obj, resp)
                -- resp is content of push
                if not ok then
                    print(string.format("push %s for [%s] error : %s", session_id, tostring(obj), err_msg))
                end
            end
        end
    else
        local session = var.session[session_id]
        var.session[session_id] = nil

        for obj, handler in pairs(var.object) do
            if err then
                local f = handler.__error
                if f then
                    local ok, err_msg = pcall(f, obj, session.name, err, session.req, session_id)
                    if not ok then
                        print(string.format("session %s[%d] error(%s) for [%s] error : %s", session.name, session_id, err, tostring(obj), err_msg))
                    end
                end
            else
                local f = handler[session.name]
                if f then
                    local ok, err_msg = pcall(f, obj, session.req, resp, session_id)
                    if not ok then
                        print(string.format("session %s[%d] for [%s] error : %s", session.name, session_id, tostring(obj), err_msg))
                    end
                end
            end
        end
    end

    return true
end

return Message
