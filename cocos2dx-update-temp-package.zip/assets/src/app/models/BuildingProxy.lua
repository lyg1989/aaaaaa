local BuildingProxy = class('BuildingProxy', Proxy)
local MapProxy = getProxy("MapProxy")
IMG2TYPE = {
    town = 1,
    camp = 2,
}
function BuildingProxy:onRegister()
    self.tbBuildingConfig = getCSVField('buildingConfig')
    self.tbBuildingBornConfig = getCSVField('buildingBornInfo')

    self:initBuildingData()

end

function BuildingProxy:GetBuildingConfig()
    return self.tbBuildingConfig
end

function BuildingProxy:initBuildingData()
    self.tbBuildingData = clone(self.tbBuildingBornConfig)
    for _, value in pairs(self.tbBuildingData) do
        value.nDur = value.nDefaultDur
        value.nGridPosX_Real = value.nMapPosX * MapProxy.cellWidth + value.nGridPosX
        value.nGridPosY_Real = value.nMapPosY * MapProxy.cellHeight + value.nGridPosY
    end
    self:UpdateCampData()
end
--
function BuildingProxy:GetBuildingData()
    return self.tbBuildingData
end

function BuildingProxy:UpdateCampData()
    self.tbCampData = {}
    for _, value in pairs(self.tbBuildingData) do
        if value.nType == 2 then
            local nCampKey = value.nGridPosX_Real * 1000 + value.nGridPosY_Real
            self.tbCampData[nCampKey] = {
                nBuildingId = value.nBuildingId
            }
        end
    end
end

function BuildingProxy:DeleteCamp(nCampKey)
    self.tbCampData[nCampKey] = nil
    local nGridPosX_Real = math.floor(nCampKey / 1000)
    local nGridPosY_Real = nCampKey % 1000
    for key, value in pairs(self.tbBuildingData) do
        if value.nType == 2 and
                nGridPosX_Real == value.nGridPosX_Real and
                nGridPosY_Real == value.nGridPosY_Real then
            self.tbBuildingData[key] = nil
        end
    end
end

function BuildingProxy:GetCampData()
    return self.tbCampData
end

function BuildingProxy:Save(pNode)

end



return BuildingProxy