

local LoadSceneCommand = class('LoadSceneCommand', SimpleCommand)

function LoadSceneCommand:execute(note)
    local data = note:getBody()
    local context = data.context
    --assert(isa(context, Context), "should be an instance of Context")

    local viewComponent = context.viewComponentClass.new()
    --assert(isa(viewComponent, BaseView), "should be an instance of BaseView: " .. viewComponent.__cname)

    local function onTransFinish(viewComponent)
        local mediator = context.mediatorClass.new(viewComponent)
        mediator:setContextData(context.data)
        game:registerMediator(mediator)
    end

    local contextProxy = self.facade:retrieveProxy("ContextProxy")
    local fromViewComponent

    local function nextScene()
        if context.transType == context.TRANS_TYPE.ONE_BY_ONE then
            SceneManager.transOneByOne(fromViewComponent, viewComponent, onTransFinish)
        else
            SceneManager.transCross(fromViewComponent, viewComponent, onTransFinish)
        end

        if context.cleanStack then
            contextProxy:cleanContext()
        end
        local children = {}
        table.merge(children, context.children)

        context:clearChildren()
        contextProxy:pushContext(context)
        
--        self:sendNotification(GAME.LOAD_LAYERS, {
--            context = children,
--            sceneContext = context
--        })
        self:sendNotification(GAME.LOAD_LAYERS, {
            contexts = children,
            parentContext = context
        })
    end
    local prevContext = data.prevContext or contextProxy:getCurrentContext()
    
    local function onRemoved()
       -- function()

        local prevMediator = game:removeMediator(prevContext.mediatorClass.__cname)

        fromViewComponent = prevMediator:getViewComponent()
        nextScene()
       -- end
    end


    if prevContext ~= nil then
        --assert(isa(prevContext, Context), "should be an instance of Context")

        self:sendNotification(GAME.REMOVE_LAYERS, {
            context = prevContext,
            callback = onRemoved
        })
    else
        nextScene()
    end
end

return LoadSceneCommand