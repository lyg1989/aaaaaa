local RoleAttr = class('RoleAttr')

function RoleAttr:ctor()
    self.szName = ''
    self.nHeadIcon = 0
    self.nPower = 0--实力
    self.nStatus = ''--地位
    self.nReputation = ''--名声
    self.nGold = 0
    self.nGroup = 0
end

return RoleAttr
