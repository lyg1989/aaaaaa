local NpcProxy = class('NpcProxy', Proxy)


function NpcProxy:onRegister()

    self.tbNpcBornConfig = getCSVField('roles_npc')

    self:initNpcData()

end



function NpcProxy:initNpcData()
    self.tbNpcData = clone(self.tbNpcBornConfig)
    for _, value in pairs(self.tbNpcData) do
        value.nGridPosX_Now = value.nGridPosX
        value.nGridPosY_Now = value.nGridPosY
    end
end

function NpcProxy:GetNpcData()
    return self.tbNpcData
end






return NpcProxy