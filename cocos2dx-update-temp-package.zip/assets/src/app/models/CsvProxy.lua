local CsvProxy = class('CsvProxy', Proxy)

function CsvProxy:onRegister()

    self.path = "app/config"
    self.loadlistName = "csvlist"
    self.csvLoadInfo = self:loadCsv(self.loadlistName)
    self.csv = {}
end

function CsvProxy:loadCsv(name)
    local packageName = string.format("%s.%s", self.path, name)
    local status, tb = xpcall( function()
        return require(packageName)
    end , function(msg)
        if not string.find(msg, string.format("'%s' not found:", packageName)) then
            print("load csv error: ", msg)
        end
    end )

    local t = type(tb)
    if status and(t == "table" or t == "userdata") then
        return tb
    else
        error(string.format(" not found csv \"%s\" in search paths \"%s\"",
        name, self.path), 0)
    end
end

function CsvProxy:getCsv(name)
    if self.csv[name] then
        return self.csv[name]
    elseif self.csvLoadInfo[name] then
       self.csv[name] = self:loadCsv(self.csvLoadInfo[name])
       return self.csv[name]
    end

    return nil
end

return CsvProxy