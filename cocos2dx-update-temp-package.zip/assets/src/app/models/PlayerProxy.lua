local PlayerProxy = class('PlayerProxy', Proxy)


function PlayerProxy:onRegister()
    self.tbPlayerConfig = getCSVField('playerConfig')
    self.tbNpcBornConfig = getCSVField('roles_npc')

    self:initNpcData()

    local data = self:getData()
	self.level = data.level or 1
	self.money = data.money or 0
	self.exp = data.exp or 0
	self:setData({})
end

function PlayerProxy:GetPlayerConfig()
    return self.tbPlayerConfig
end

function PlayerProxy:initNpcData()
    self.tbNpcData = self.tbNpcBornConfig
    for _, value in pairs(self.tbNpcData) do
        value.nGridPosX_Now = value.nGridPosX
        value.nGridPosY_Now = value.nGridPosY
    end
end

function PlayerProxy:GetNpcData()
    return self.tbNpcData
end

function PlayerProxy:initMyRoleData()
    self.tbMyInfo = {
        nNpcId = 1,
        nMoney = 88.999,
        szName = '琅琊王氏',
        nDiplo = 1,
        nCamp = 55521,
        nPower = 1888888888,
        nStatus = 1,
        nPrestige = 100,
        tbTowns = {

        }
    }
end

function PlayerProxy:Save(pNode)

    local data = {}
    data.level = self.level 
    data.money = self.money 
    data.exp = self.exp 


    pNode["PlayerProxy"] = data
end

function PlayerProxy:upgradeLevel()
	self.level = self.level + 1
	
	self:sendNotification(GAME.PLAYER_UPGRADE, {level = self.level})
end



return PlayerProxy