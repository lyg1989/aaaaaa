local LoadGameDataCommand = class('LoadGameDataCommand', SimpleCommand)

require("src.init.tablesave")
require("src.app.models.Message")
require("src.app.net.LoginHander")
--local HeroProxy = require("app/models/HeroProxy")
--local PlayerProxy = require("app/models/PlayerProxy")
--local ItemProxy = require("app/models/ItemProxy")

function LoadGameDataCommand:execute(note)
    local data = note:getBody()

    --jia zai youxi  shuju

    -- local   str = cc.UserDefault:getInstance():getStringForKey("user")
    -- print(str)
    -- local info = {}

    -- if str == "" or string.len(str) == 0 then
    --     info = {}
    -- else
    --     info = table.load(str)
    -- end


    -- local proxy = HeroProxy:create(HeroProxy.__cname, info.HeroProxy or {})
    -- game:registerProxy(proxy)
    -- proxy = PlayerProxy:create(PlayerProxy.__cname, info.PlayerProxy or {})
    -- game:registerProxy(proxy)
    -- proxy = ItemProxy:create(ItemProxy.__cname, info.ItemProxy or {})
    -- game:registerProxy(proxy)

    
--    local IP = IP or "192.168.100.80"
--    local message = getProxy("Message")
--    message:initNet()
--    message:peer(IP, 5678)
--    message:connect()

    --    local IP = IP or "192.168.100.80"
    --    local message = getProxy("Message")
    --    message:onInitNet()
    --    message:peer(IP, 5678)
    --    message:connect()


----    进入第一层地图
--       local context = Context:buildContext({transType = Context.TRANS_TYPE.ONE_BY_ONE, mtype= MapType.FirstLayer, pos=cc.p(0, 0)}, SCENE.MAIN)
--    进入第三层地图
   local context = Context:buildContext({transType = Context.TRANS_TYPE.ONE_BY_ONE, center=cc.p(200, 200)}, SCENE.LAYERMAP)

    local context = Context:buildContext({
        transType = Context.TRANS_TYPE.ONE_BY_ONE,
        center = cc.p(200, 200),
    },SCENE.LAYERMAP)

    --预存子界面的context
    local sublayerContext = Context:buildContext({}, SCENE.TOOLPANEL)
    context:pushContext(sublayerContext)--或者context:addChild(sublayerContext)

    game:sendNotification(GAME.GO_TO_SCENE, context)
end

return LoadGameDataCommand