--
MyFonts =
{
    [1] = "res/ui/fonts/FZDHTJW.ttf",
    [2] = "黑体",
    [3] = "Thonburi",
    [3] = "微软雅黑",
}


LocalizePS =
{
    ["Common"] =
    {
        ["Version"] = "v%d.%d.%d",
        ["Time1"] = "%02d日%02d时",
        ["Time2"] = "%02d时%02d分",
        ["Time3"] = "%02d分%02d秒",
        ["Time4"] = "%02d秒",
        ["Date"] = "%Y.%m.%d",
        ["Day"] = "%d天",

    },

    ["Login"] =
    {

    },
    ["FORCE_NAME"] =
    {
        [1] = '凉州',
        [2] = '并州',
        [3] = '冀州',
        [4] = '幽州',
        [5] = '青州',
        [6] = '杨州',
        [7] = '荆州',
        [8] = '益州',
        [9] = '交州',
        [10] = '司隶',
    },
    ["MAP_EDIT_HELP"] =
    {
        ["cancel"] = '取消',
        ["introduction1"] = '方向键：偏移1像素',
        ["introduction2"] = 'R / E: 顺/逆时针旋转?',
        ["introduction3"] = 'A / W:水平/垂直镜像',
        ["introduction4"] = 'ESC:取消选择图块',
        ["introduction5"] = 'X：还原到初始状态',
        ["introduction6"] = 'S：保存修改',
    }
}


local szDefault = "未定义"
function LocalizePS.GetStr(section, key)

    if LocalizePS[section] and LocalizePS[section][key] then
        return LocalizePS[section][key]
    end
    return szDefault .. "[" .. section .. "][" .. key .. "]"
end

function LocalizePS.GetTable(section)

    if LocalizePS[section] then
        return LocalizePS[section]
    end
    return szDefault .. "[" .. section .. "]"
end
