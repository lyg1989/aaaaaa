local HeroProxy = class('HeroProxy', Proxy)

local HeroObject = require("app.object.HeroObject")

function HeroProxy:onRegister()
    local data = self:getData()
    self.heros = {}
    local heroConfig = getCSVField("heros")    
    for k, v in pairs(heroConfig) do              
        --self.heros[k] = HeroObject:create(k, v) 
        self:AddHero(k, v)      
    end    
    self:setData({})
end

function HeroProxy:getInBattleHero()
	return self.heros
end

function HeroProxy:Save(pNode)
   local node = {}  
    for k, v in pairs(self.heros) do
        self.heros:Save(node)      
    end
    pNode["HeroProxy"] = node
end



function HeroProxy:getItemTmp(id)
    local heroConfig = getCSVField("heros")
    if heroConfig and heroConfig[id] then 
       return heroConfig[id]
    end
    return nil
end

function HeroProxy:getIcon(id)
    local heroConfig = getCSVField("heros")
    if heroConfig and heroConfig[id] then 
        return heroConfig[id].icon
    end
    return nil
end


function HeroProxy:buildTip(id,typename)


end
function HeroProxy:setBoss(id)
    if self.heros[id] then
        if self.curBoss and self.heros[self.curBoss] then
            self.heros[self.curBoss]:setBoss(0)
        end
        self.heros[id]:setBoss(1)    
        self.curBoss = id
        
        self:sendNotification(GAME.VIEW_SET_BOSS, {id = id})
    end
end



function HeroProxy:DelHero(id)

    self.heros[id] = nil
    self:sendNotification(GAME.HEROS_DELETE, {id = id})
end

function HeroProxy:AddHero(entryId, data)
     
    if self.heros[entryId]  then
        return
    end
    --local info = self:getItemTmp(entryId)
    if data and data.isBoss == 1 then    
        self.curBoss = entryId  
    end
    self.heros[entryId] = HeroObject:create(entryId, data)
  
    self:sendNotification(GAME.HEROS_ADD, {heros = self.heros[entryId]})
end

return HeroProxy