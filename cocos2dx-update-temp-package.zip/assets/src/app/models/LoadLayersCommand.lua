
local LoadLayersCommand = class('LoadLayersCommand', SimpleCommand)

function LoadLayersCommand:execute(note)
    local data = note:getBody()
    local contexts = data.contexts
    local open = {}

    local restoreLayers, status, iter
    restoreLayers = coroutine.create(function()
        -- restore context tree

        while #open > 0 do
            local context = table.remove(open, 1)
            for _, v in ipairs(context.children) do
                table.insert(open, v)
            end
            
            
            local parentContext = context.parent
            local parentMediator = game:retrieveMediator(parentContext.mediatorClass.__cname)            
            local parentViewComponent = parentMediator:getViewComponent()
            
            local viewComponent = context.viewComponentClass.new()
            local finish = false
            
            local function onFinish()
               -- dump(context)
                local mediator = context.mediatorClass.new(viewComponent)
                mediator:setContextData(context.data)
                game:registerMediator(mediator)
                coroutine.resume(restoreLayers)
                finish = true
            end

            SceneManager.overlay(parentViewComponent, viewComponent, onFinish)
            if not finish then coroutine.yield() end
        end

        if data.callback then data.callback() end
    end)

    local parentContext = data.parentContext
--    if parentContext then
--        --assert(isa(parentContext, Context), "should be an instance of Context")
--        if parentContext:getContextByMediator(context.mediatorClass) then
--            print("Mediator already exist: " .. context.mediatorClass.__cname)
--            return
--        end
--
--        table.insert(open, context)
--        parentContext:addChild(context)
--    else
--        for _, v in ipairs(context) do
--            table.insert(open, v)
--            data.sceneContext:addChild(v)
--        end
--    end
    if parentContext then
--        if parentContext:getContextByMediator(context.mediatorClass) then
--            print("Mediator already exist: " .. context.mediatorClass.__cname)
--            return
--        end

        for _, v in ipairs(contexts) do
            table.insert(open, v)
            parentContext:addChild(v)
        end
    end

    -- start restore
    coroutine.resume(restoreLayers)    
end

return LoadLayersCommand