

local RemoveLayersCommand = class('RemoveLayersCommand', SimpleCommand)

function RemoveLayersCommand:execute(note)
    local data = note:getBody()
    local context = data.context
    --assert(isa(context, Context), "should be an instance of Context")

    -- Breadth-First-Search
    local open = { context }
    local close = {}

    local function removeList( list, parent)
        table.insert(list, parent)

        for _, v in ipairs(parent.children) do
            removeList(list, v)
        end 

    end

    while #open > 0 do


        local context = table.remove(open, 1) -- FIFO
        removeList(close, context)
        --        table.insert(close, context)
        --
        --        for _, v in ipairs(context.children) do
        --            
        --            removeList(close, v)
        --        end
    end

    if context.parent == nil then
        -- do not remove root context
        table.remove(close, 1)
    else

        context.parent:removeChild(context)
      
    end

    -- remove context tree
    local removeState, status, iter
    removeState = coroutine.create(function()
        while #close > 0 do
            local context = table.remove(close) -- LIFO
            
            local subMediator = self.facade:removeMediator(context.mediatorClass.__cname)

            local removed = false
            local function onRemoved()
                coroutine.resume(removeState)
                removed = true
            end

            SceneManager.remove(subMediator:getViewComponent(), onRemoved)
            if not removed then coroutine.yield() end
        end

        -- do the callback
        if data.callback then data.callback() end
    end)

    -- start remove
    coroutine.resume(removeState)    
end

return RemoveLayersCommand