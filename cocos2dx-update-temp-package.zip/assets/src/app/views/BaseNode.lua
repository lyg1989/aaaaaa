BaseNode = class("BaseNode", cc.Node)


function BaseNode:createResoueceNode(resourceFilename)
    if self.resourceNode_ then
        self.resourceNode_:removeSelf()
        self.resourceNode_ = nil
    end
       
    self.resourceNode_ = cc.CSLoader:createNode(resourceFilename)
    assert(self.resourceNode_, string.format("ViewBase:createResoueceNode() - load resouce node from file \"%s\" failed", resourceFilename))
    self:addChild(self.resourceNode_)
end

function BaseNode:createResoueceBinding(binding)
    assert(self.resourceNode_, "ViewBase:createResoueceBinding() - not load resource node")
    --    for nodeName, nodeBinding in pairs(binding) do
    --        local node = self.resourceNode_:getChildByName(nodeName)
    --        if nodeBinding.varname then
    --            self[nodeBinding.varname] = node
    --        end
    --        for _, event in ipairs(nodeBinding.events or {}) do
    --            if event.event == "touch" then
    --                node:onTouch(handler(self, self[event.method]))
    --            end
    --        end
    --    end

    for nodeName, nodeBinding in pairs(binding) do
        if self.controls[nodeName] then
            if nodeBinding[1] == "addTouchEventListener" then
                self.controls[nodeName]:addTouchEventListener(handler(self, self[nodeBinding[2]]))
            end            
        end
    end
end

function BaseNode:seekNodeByName(root, names, controls)
	if root == nil then
	   return	
	end
	
	for k, v in pairs(names) do	
--        print("widget name", root:getName())
	   if root:getName() == k then
           
	       controls[k] = root
	       break
	   end	
	end
	
	local children = root:getChildren()
	
	for k, v in pairs(children) do
	   if v then	   
            self:seekNodeByName(v, names, controls)
	   end
	
	end
	
end

-- 开始加载
function BaseNode:load()
    -- 获取 UI 名称
    self.controls = {}
    local res = rawget(self.class, "RESOURCE_FILENAME")
    if res then
        self:createResoueceNode(res)
    end
    
    local binding = rawget(self.class, "RESOURCE_BINDING")
    if res and binding then
        self:seekNodeByName(self.resourceNode_,binding,self.controls)
        self:createResoueceBinding(binding)
    end
    

     self:OnUILoaded()
    
end


return BaseNode