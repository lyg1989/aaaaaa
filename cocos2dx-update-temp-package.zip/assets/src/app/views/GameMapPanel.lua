local GameMapPanel = class('GameMapPanel', BaseViewComponent)

function GameMapPanel:ctor(parent)
    self.parent = parent

    self:bindEventInit()

    self.RESOURCE_FILENAME = 'res/csb/layer_MainSceneUI.csb'
    self.RESOURCE_BINDING = {
        btnSelRole_my = { "addTouchEventListener", "onSelRole_my" },
        btnSelRole_1 = { "addTouchEventListener", "onSelRole_1" },
        btnBack2Town = { "addTouchEventListener", "onBack2Town" },
        btnWJ = { "addTouchEventListener", "onWJ" },
        btnNZ = { "addTouchEventListener", "onNZ" },
        btnGT = { "addTouchEventListener", "onGT" },
        btnFL = { "addTouchEventListener", "onFL" },
        btnJJ = { "addTouchEventListener", "onJJ" },
        btnKJ = { "addTouchEventListener", "onKJ" },
        labPos = {}
    }
    self:load()

    self:adjustUi()
end

function GameMapPanel:SetLabPos(pos)
    local szPos = 'x='..pos.x..' ,y='..pos.y
    self.controls.labPos:setString(szPos)
end

function GameMapPanel:adjustUi()
    local winSzie = cc.Director:getInstance():getWinSize()
    local Panel_Top = self:seekByName(self.resourceNode_, 'Panel_Top')
    local Panel_Bottom = self:seekByName(self.resourceNode_, 'Panel_Bottom')
    local Panel_Left = self:seekByName(self.resourceNode_, 'Panel_Left')
    local Panel_Right = self:seekByName(self.resourceNode_, 'Panel_Right')
    Panel_Top:setScale(display.scaleX / display.scaleY)
    Panel_Bottom:setScale(display.scaleX / display.scaleY)

    Panel_Left:setScale(display.scaleX / display.scaleY)
    Panel_Left:setPositionX(Panel_Left:getPositionX() + winSzie.width / 2 * (1 - display.scaleX / display.scaleY))
    Panel_Left:setPositionY(Panel_Left:getPositionY() + winSzie.height / 2 * (1 - display.scaleX / display.scaleY))

    Panel_Right:setScale(display.scaleX / display.scaleY)
    Panel_Right:setPositionX(Panel_Right:getPositionX() - winSzie.width / 2 * (1 - display.scaleX / display.scaleY))
    Panel_Right:setPositionY(Panel_Right:getPositionY() + winSzie.height / 2 * (1 - display.scaleX / display.scaleY))
end

function GameMapPanel:onSelRole_my(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnSelRole_my:setScale(1.05)
        self.parent:onSelRole_my(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnSelRole_my:setScale(1)
        self.parent:onSelRole_my(false)
    end
end
function GameMapPanel:onSelRole_1(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnSelRole_1:setScale(1.05)
        self.parent:onSelRole_1(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.parent:onSelRole_1(false)
        self.controls.btnSelRole_1:setScale(1)
    end
end
function GameMapPanel:onBack2Town(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnBack2Town:setScale(1.05)
        self.parent:onBack2Town(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnBack2Town:setScale(1)
        self.parent:onBack2Town(false)
    end
end
function GameMapPanel:onWJ(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnWJ:setScale(1.05)
        self.parent:onWJ(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnWJ:setScale(1)
        self.parent:onWJ(false)
    end
end
function GameMapPanel:onNZ(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnNZ:setScale(1.05)
        self.parent:onNZ(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnNZ:setScale(1)
        self.parent:onNZ(false)
    end
end
function GameMapPanel:onGT(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnGT:setScale(1.05)
        self.parent:onGT(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnGT:setScale(1)
        self.parent:onGT(false)
    end
end
function GameMapPanel:onFL(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnFL:setScale(1.05)
        self.parent:onFL(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnFL:setScale(1)
        self.parent:onFL(false)
    end
end
function GameMapPanel:onJJ(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnJJ:setScale(1.05)
        self.parent:onJJ(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnJJ:setScale(1)
        self.parent:onJJ(false)
    end
end
function GameMapPanel:onKJ(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnKJ:setScale(1.05)
        self.parent:onKJ(true)
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnKJ:setScale(1)
        self.parent:onKJ(false)
    end
end

function GameMapPanel:bindEventInit()
    cc.bind(self, "event")
end

return GameMapPanel