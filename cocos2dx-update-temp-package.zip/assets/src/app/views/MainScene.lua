local MainScene = class("MainScene", BaseViewComponent)

MainScene.RESOURCE_FILENAME  ="res/csb/MainScene.csb"

MainScene.RESOURCE_BINDING = 
    {
        btnSave = { "addTouchEventListener", "onBig" },
        btnSmall = {"addTouchEventListener", "onSmall"},
        background = {}
    }

local mapBase = require("app.mapEdit.mapBase")

function MainScene:onAdd(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent({name=MainScene.ONADD})
    end    
end

function MainScene:onSmall(sender, eventType)
--    if eventType == cc.EventCode.ENDED then
--        if self.scale < 2 then
--            self.scale = self.scale + 1
--            -- self.controls["innerMap"]:setScale(self.scale)
--            self.map:onScale(self.scale)
--            --self.map:scrollView1DidZoom()
--        else
--            self.map:onScale(0.9)
--            --self.map:scrollView1DidZoom()
--        end
--    end  
    if eventType == cc.EventCode.ENDED then
           -- self.map:hecheng()
    -- self.map:setZoomScale(self.map:getMapScale()+1)
          self.map:touchScaleEnd(0.5)
        --game:sendNotification(GAME.SAVE_USER_DATA)   
    end
end


function MainScene:onBig(sender, eventType)
--    if eventType == cc.EventCode.ENDED then
--        if self.scale < 2 then
--            self.scale = self.scale + 1
--            -- self.controls["innerMap"]:setScale(self.scale)
--            self.map:onScale(self.scale)
--            --self.map:scrollView1DidZoom()
--        else
--            self.map:onScale(0.9)
--            --self.map:scrollView1DidZoom()
--        end
--    end  
    if eventType == cc.EventCode.ENDED then
           -- self.map:hecheng()
    -- self.map:setZoomScale(self.map:getMapScale()+1)
     self.map:touchScaleEnd(1.1)
        --game:sendNotification(GAME.SAVE_USER_DATA)   
    end
end

function MainScene:initMap(mtype, id, scale)

    local background = self.controls["background"]
   -- background:setScale(display.scaleX/display.scaleY)
   --ackground:setScale(display.scaleX/display.scaleY)
   self.controls["background"]:setPosition(0, 0)
    background:setContentSize(cc.size(display.width, display.height))
  
    self.map = mapBase:create(self, mtype, cc.size(display.width, display.height), id, scale)   
   self.controls["background"]:addChild(self.map, 100)

   self.controls["background"]:setLocalZOrder(-1)
   --self.map:onScale(0.6)
--   self.scale = 3
end

function MainScene:onEnter()

    -- test login


--   self.resourceNode_:setZOrder(1000)
--   self.resourceNode_:setPosition(display.width-50, display.height-50)
--   self.resourceNode_:setVisible(false)
end

function MainScene:init()   
    local scene = cc.Scene:create()
    scene:addChild(self, 0)
    display.runScene(scene)   
end

function MainScene:updateLevel(level)
    
end



function MainScene:onEnter()

end

function MainScene:onExit()

end

--function MainScene:onHero(sender, eventType)
--    print("MainScene:onTask")

--    if eventType == cc.EventCode.ENDED then
--        self:dispatchEvent({name=MainScene.CHARACHTER})
--    end    
--end



return MainScene
