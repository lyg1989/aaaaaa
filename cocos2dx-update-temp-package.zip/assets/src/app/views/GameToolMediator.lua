local GameToolMediator = class("GameToolMediator", BaseMediator)



function GameToolMediator:didRegister()
    GameToolMediator.tbBindList = {
        GMS_BTN_BACK2TOWN = {
            szMsg = 'GMS_BTN_BACK2TOWN',
            func = GameToolMediator.dispatchBtnBack2Town
        },
        GMS_BTN_WJ = {
            szMsg = 'GMS_BTN_WJ',
            func = GameToolMediator.dispatchBtnWJ
        },
        GMS_BTN_NZ = {
            szMsg = 'GMS_BTN_NZ',
            func = GameToolMediator.dispatchBtnNZ
        },
        GMS_BTN_GT = {
            szMsg = 'GMS_BTN_GT',
            func = GameToolMediator.dispatchBtnGT
        },
        GMS_BTN_FL = {
            szMsg = 'GMS_BTN_FL',
            func = GameToolMediator.dispatchBtnFL
        },
        GMS_BTN_JJ = {
            szMsg = 'GMS_BTN_JJ',
            func = GameToolMediator.dispatchBtnJJ
        },
        GMS_BTN_KJ = {
            szMsg = 'GMS_BTN_KJ',
            func = GameToolMediator.dispatchBtnKJ
        },
    }

    for key, value in pairs(GameToolMediator.tbBindList) do
        self:bind(value.szMsg, function(e)
            value.func(self)
        end)
    end
end

function GameToolMediator:GetMsg(szMsg)
    return GameToolMediator.tbBindList[szMsg].szMsg
end

function GameToolMediator:listNotificationInterests()
    return {
        GAME.GET_LAB_POS
    }
end

function GameToolMediator:handleNotification(note)
    local name = note:getName()
    local body = note:getBody()

    if name == GAME.GET_LAB_POS then
        self.viewComponent:SetLabPos(body.pos)
    end
end

function GameToolMediator:dispatchBtnBack2Town()
    self:sendNotification(GAME.GMS_BTN_BACK2TOWN, {})
end
function GameToolMediator:dispatchBtnWJ()
    self:sendNotification(GAME.GMS_BTN_WJ, {})
end
function GameToolMediator:dispatchBtnNZ()
    self:sendNotification(GAME.GMS_BTN_NZ, {})
end
function GameToolMediator:dispatchBtnGT()
    self:sendNotification(GAME.GMS_BTN_GT, {})
end
function GameToolMediator:dispatchBtnFL()
    self:sendNotification(GAME.GMS_BTN_FL, {})
end
function GameToolMediator:dispatchBtnJJ()
    self:sendNotification(GAME.GMS_BTN_JJ, {})
end
function GameToolMediator:dispatchBtnKJ()
    self:sendNotification(GAME.GMS_BTN_KJ, {})
end

return GameToolMediator