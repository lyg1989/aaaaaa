BaseMediator = class('BaseMediator', Mediator)

function BaseMediator:ctor(viewComponent)
    BaseMediator.super.ctor(self, self.__cname, viewComponent)
end

-- 注册 Mediator
function BaseMediator:onRegister()
    -- 事件队列
 
    -- 事件队列
    self.event = {}
    self:bind(BaseViewComponent.ON_BACK, function(e)
        self:sendNotification(GAME.GO_BACK)
    end)

    self:bind(BaseViewComponent.ON_CLOSE, function(e)
        
        local contextProxy = self.facade:retrieveProxy("ContextProxy")
        local currentContext = contextProxy:getCurrentContext()
            local parentContext = currentContext:getContextByMediator(self.class)
      
        self:sendNotification(GAME.REMOVE_LAYERS, {
            context = parentContext
        })
    end)

    -- 注册时要执行的
    self:didRegister()
end

-- 由子类实现注册时要执行的
function BaseMediator:didRegister() end

function BaseMediator:init() end

-- 设置上下文参数，通过 context.data 获得的参数
function BaseMediator:setContextData(data)
    self.contextData = data 
    if self.viewComponent and self.viewComponent.onDataInit then
        self.viewComponent:onDataInit(data)
    end  
end


-- 订阅来自 UI 的消息
-- @param event 事件名
-- @param callback 回调函数
function BaseMediator:bind(event, callback)
    -- 绑定 UI 事件回调
    local target,  handle = self.viewComponent:addEventListener(event, callback)

    -- 将事件记录到队列，注销 mediator 时称除
    table.insert(self.event, {
        event = event,
        handle = handle
    })
end

function BaseMediator:onRemove()
    -- 注销时要执行的
    self:willRemove()

    -- 移除关联的 UI 事件
    for _, v in ipairs(self.event) do
        self.viewComponent:removeEventListener(v.handle)
    end
end




-- 由子类实现注销时要执行的
function BaseMediator:willRemove() end

function BaseMediator:getParent()
    local contextProxy = self.facade:retrieveProxy("ContextProxy")
    local currentContext = contextProxy:getCurrentContext()
    local parentContext = currentContext:getContextByMediator(self.class)

     if parentContext.parent then
        local parentMediator = game:retrieveMediator(parentContext.parent.mediatorClass.__cname)            
        --local parentViewComponent = parentMediator:getViewComponent()        
        return parentMediator
     end
     
     return nil
end

function BaseMediator:retrieveSubLayer(name)
    local contextProxy = self.facade:retrieveProxy("ContextProxy")
    local currentContext = contextProxy:getCurrentContext()
    local parentContext = currentContext:getContextByMediator(self.class)

    if parentContext then
        return parentContext:getContextByMediatorName(name)
    end

    return nil

end

function BaseMediator:addSubLayers(context)

    local contextProxy = self.facade:retrieveProxy("ContextProxy")
    local currentContext = contextProxy:getCurrentContext()
    local parentContext = currentContext:getContextByMediator(self.class)

    self:sendNotification(GAME.LOAD_LAYERS, {
        parentContext = parentContext,
        contexts = {context}
    })
end

return BaseMediator