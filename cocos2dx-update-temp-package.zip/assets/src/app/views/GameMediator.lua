
local GameMediator = class('GameMediator', Mediator)

function GameMediator:listNotificationInterests()
    return {
        GAME.GO_TO_SCENE,
    }
end

function GameMediator:handleNotification(note)
    local name = note:getName()
    local data = note:getBody()
    local type = note:getType()
    
    if name == GAME.GO_TO_SCENE then
        self:sendNotification(GAME.LOAD_SCENE, {context = data})
    end
end

return GameMediator