local MainSceneDialogMediator = class('MainSceneDialogMediator', BaseMediator)

function MainSceneDialogMediator:didRegister()
    MainSceneDialogMediator.tbBindList = {
        GMS_DIALOG_ATTACK = {
            szMsg = 'GMS_DIALOG_ATTACK',
            func = MainSceneDialogMediator.dispatchBtnAttack
        },
        GMS_DIALOG_ATTACK_CAMP = {
            szMsg = 'GMS_DIALOG_ATTACK_CAMP',
            func = MainSceneDialogMediator.dispatchBtnAttackCamp
        },
        GMS_DIALOG_ZY = {
            szMsg = 'GMS_DIALOG_ZY',
            func = MainSceneDialogMediator.dispatchBtnZY
        },
        GMS_DIALOG_CH = {
            szMsg = 'GMS_DIALOG_CH',
            func = MainSceneDialogMediator.dispatchBtnCH
        },
        GMS_DIALOG_SD = {
            szMsg = 'GMS_DIALOG_SD',
            func = MainSceneDialogMediator.dispatchBtnSD
        },
        GMS_DIALOG_JS = {
            szMsg = 'GMS_DIALOG_JS',
            func = MainSceneDialogMediator.dispatchBtnJS
        },
        GMS_DIALOG_HC = {
            szMsg = 'GMS_DIALOG_HC',
            func = MainSceneDialogMediator.dispatchBtnHC
        },
        GMS_DIALOG_TH = {
            szMsg = 'GMS_DIALOG_TH',
            func = MainSceneDialogMediator.dispatchBtnTH
        },
        GMS_DIALOG_REMOVE = {
            szMsg = 'GMS_DIALOG_REMOVE',
            func = MainSceneDialogMediator.dispatchRemoveDlg
        },

    }

    for key, value in pairs(MainSceneDialogMediator.tbBindList) do
        self:bind(value.szMsg, function(e)
            value.func(self)
        end)
    end
end

function MainSceneDialogMediator:listNotificationInterests()
    return {
        GAME.MAINSCENE_DLG_LAYER_CHANGES,
    }
end

function MainSceneDialogMediator:handleNotification(note)
    local name = note:getName()
    local data = note:getBody()
    local type = note:getType()
    
    if name == GAME.MAINSCENE_DLG_LAYER_CHANGES then
        self.viewComponent:ChangeImg(data.info.szType)
    end
end

function MainSceneDialogMediator:GetMsg(szMsg)
    return MainSceneDialogMediator.tbBindList[szMsg].szMsg
end

function MainSceneDialogMediator:dispatchBtnAttack()
    game:sendNotification(GAME.GMS_DIALOG_ATTACK, {})
end

function MainSceneDialogMediator:dispatchBtnAttackCamp()
    game:sendNotification(GAME.GMS_DIALOG_ATTACK_CAMP, {})
end

function MainSceneDialogMediator:dispatchBtnZY()
    game:sendNotification(GAME.GMS_DIALOG_ZY, {})
end

function MainSceneDialogMediator:dispatchBtnCH()
    game:sendNotification(GAME.GMS_DIALOG_CH, {})
end

function MainSceneDialogMediator:dispatchBtnSD()
    game:sendNotification(GAME.GMS_DIALOG_SD, {})
end

function MainSceneDialogMediator:dispatchBtnJS()
    game:sendNotification(GAME.GMS_DIALOG_JS, {})
end

function MainSceneDialogMediator:dispatchBtnHC()
    game:sendNotification(GAME.GMS_DIALOG_HC, {})
end

function MainSceneDialogMediator:dispatchBtnTH()
    game:sendNotification(GAME.GMS_DIALOG_TH, {})
end

function MainSceneDialogMediator:dispatchRemoveDlg()
    game:sendNotification(GAME.MAINSCENE_DLG_LAYER_REMOVE, {})
end
return MainSceneDialogMediator