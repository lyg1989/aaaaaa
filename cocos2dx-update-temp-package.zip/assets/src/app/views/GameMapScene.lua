local GameMapScene = class("GameMapScene", BaseViewComponent)
-- local scheduler = require(cc.PACKAGE_NAME .. ".scheduler")
-- local scheduler = require("framework.scheduler")


local GameMapMediator = require("app.views.GameMapMediator")
local RoleObject = require('app.object.RoleObject')
local BuildingObject = require('app.object.BuildingObject')

local MapProxy = getProxy("MapProxy")
local PlayerProxy = getProxy('PlayerProxy')
local BuildingProxy = getProxy('BuildingProxy')


local Plist_TestWork = require('app.views.Plist_TestWork')

ZODER_MIAN_LAYER = {
    MAP = 1,
    UI = 7
}
ZODER_UI_LAYER = {
    PANEL = 1,
    DIALOG = 2
}
ZODER_MAP_LAYER = {
    TILEDMAP = 1,
    BUILDING = 10,
    REACH_TAG = 25,
    ROLE = 30,
    ROLE_TAG_FIGHT = 31,
    RANGE = 50,
    DRAWNODE = 20,
}

POWER_GRID = {
    UNDEVELOPED = 0,

    MINE = 3,
    ENEMY = 4,
    OCCUPY = 5,
}
--function GameMapScene:ctor()
--end
--GameMapScene.posCenter = {
--    x = display.cx,
--    y = display.cy
--}
--GameMapScene.posCenter.x = math.floor(GameMapScene.posCenter.x)
--GameMapScene.posCenter.y = math.floor(GameMapScene.posCenter.y)

function GameMapScene:onBig(sender, eventType)
    --    if eventType == cc.EventCode.ENDED then
    --        if self.scale < 2 then
    --            self.scale = self.scale + 1
    --            -- self.controls["innerMap"]:setScale(self.scale)
    --            self.map:onScale(self.scale)
    --            --self.map:scrollView1DidZoom()
    --        else
    --            self.map:onScale(0.9)
    --            --self.map:scrollView1DidZoom()
    --        end
    --    end
    if eventType == cc.EventCode.ENDED then
        -- self.map:hecheng()
        -- game:sendNotification(GAME.SAVE_USER_DATA)
        self.map:setZoomScale(self.map:getScale() -0.1)
        -- self:setZoomScale(self.map:getScale() -0.1)
    end
end

function GameMapScene:onEnter()
    -- self:onDataInit()

end

function GameMapScene:onExit()
    -- self:onDataInit()

end

function GameMapScene:disableTouch()
    if self._listener then
        local eventDispatcher = self:getEventDispatcher()
        eventDispatcher:removeEventListener(self._listener)
        self._dragging = false
        self._touchMoved = false
        self._touches = { }
        self._listener = nil
    end
end

function GameMapScene:onBack2Town(bStart)
    local node = Plist_TestWork.create()
    node.root:setPosition(cc.p(500, 500))
    self.map:addChild(node.root, 1000)
    node.root:runAction(node.animation)
    node.animation:gotoFrameAndPlay(0)
    --    node.root:runAction(node.animation)
    --    dump(Plist_TestWork, 'Plist_TestWork')
    print('返回城内')
    self.bSelectGrid = not bStart
end
function GameMapScene:onWJ(bStart)
    print('外交')
    self.bSelectGrid = not bStart
end
function GameMapScene:onNZ(bStart)
    print('内政')
    self.bSelectGrid = not bStart
end
function GameMapScene:onGT(bStart)
    print('宫廷')
    self.bSelectGrid = not bStart
end
function GameMapScene:onFL(bStart)
    print('法律')
    self.bSelectGrid = not bStart
end
function GameMapScene:onJJ(bStart)
    print('竞技')
    self.bSelectGrid = not bStart
end
function GameMapScene:onKJ(bStart)
    print('科技')
    self.bSelectGrid = not bStart
end

--拓荒
function GameMapScene:onTH()
    MapProxy:ChangeGrid(self.tbPos_TH.x, self.tbPos_TH.y, 3)
    self:drawCityLine()
end

--攻击
function GameMapScene:onAttack()
    self:objectMove(self.tbAttackPos)
    self:showReachTag(self.tbAttackPos)
end

--扎营
function GameMapScene:onZY()
    self.tbPos_ZY = self.tbPos_want_ZY
    self:Tmp_PlayAni_ZY(self.tbPos_ZY)
end

--撤回
function GameMapScene:onRetract()
    if self.tbPos_ZY then
        self:objectMove(self.tbPos_ZY)
    else
        local pos = MapProxy:getCellPos(self.tbTownPos.x, self.tbTownPos.y)
        self.tbStayPos = self.tbTownPos
        self.objMyself:setPosition(pos)
        self:checkMyArmyVisible()
    end
end

--烧地
function GameMapScene:onBurning()
    MapProxy:ChangeGrid(self.tbStayPos.x, self.tbStayPos.y, 0)
end

--检视
function GameMapScene:onJS()

end

--回城
function GameMapScene:onHC()
    --        self:objectMove(self.tbTownPos)
    local pos = MapProxy:getCellPos(self.tbTownPos.x, self.tbTownPos.y)
    self.tbStayPos = self.tbTownPos
    self.objMyself:setPosition(pos)
    self.tbPos_ZY = nil
    self.sprCamp:Destroy()
    self.sprCamp = nil

    self:checkMyArmyVisible()
end

function GameMapScene:onMainSceneDlgRemove()
    self.bExistDlg = false
end

function GameMapScene:onMainArmyMove()
    self.bArmyMove = true
end

function GameMapScene:onRoleReachDest(tbDest)
    local nDestNpcId = self.tbNpcPos[tbDest.x * 1000 .. tbDest.y]
    if nDestNpcId then
        self.tbNPC[nDestNpcId].sprObject:Action_BeFight(1)--暂时写死NPC的攻击方向
        self.objMyself:Action_Fight(tbDest)
    else
        self.tbStayPos = tbDest
        self.objMyself:SetStateType(EnumStateType.IDLE)
        if MapProxy.cellProperty[tbDest.y][tbDest.x].gid == 4 then
            MapProxy:ChangeGrid(self.tbStayPos.x, self.tbStayPos.y, 5)
            self.tbStayPos = self.tbAttackPos
            self:drawCityLine()
        end
        self:checkMyArmyVisible()
    end
end

function GameMapScene:onRoleDead(nRoleId)
    self:NpcDead(nRoleId)
end

function GameMapScene:onOccupy(tbDest)
    local posOccupy = MapProxy:getCellPos(tbDest.x, tbDest.y)
    if MapProxy.cellProperty[tbDest.y][tbDest.x].gid == 4 then
        MapProxy:ChangeGrid(tbDest.x, tbDest.y, 5)
        self.tbStayPos = self.tbAttackPos
        self:drawCityLine()
    end
    self.objMyself:setPosition(posOccupy)
end

function GameMapScene:onEncampFinish(tbPos)
    local posEncamp = MapProxy:getCellPos(tbPos.x, tbPos.y)
    self.tbStayPos = tbPos
    self.objMyself:setPosition(posEncamp)
    self:checkMyArmyVisible()
end

function GameMapScene:checkMyArmyVisible()
    if self:isOnTown() or self:isOnCamp() then
        self.objMyself:SetVisible(false)
    else
        self.objMyself:SetVisible(true)
    end
end

function GameMapScene:isOnTown()
    if self.tbTownPos and (self.tbStayPos.x == self.tbTownPos.x and self.tbStayPos.y == self.tbTownPos.y) then
        return true
    end
    return false
end

function GameMapScene:isOnCamp()
    if self.tbPos_ZY and (self.tbStayPos.x == self.tbPos_ZY.x and self.tbStayPos.y == self.tbPos_ZY.y) then
        return true
    end
    return false
end

function GameMapScene:Tmp_PlayAni_ZY(tbPos)
    local tbBuildingConfig = BuildingProxy:GetBuildingConfig()
    local szImg = tbBuildingConfig[IMG2TYPE.camp].szImg
    local pos = MapProxy:getCellPos(tbPos.x, tbPos.y)
    if not self.sprCamp then
        self.sprCamp = BuildingObject:create(100000, 2)
        self.sprCamp:setPosition(pos)
        self.layerBuilding:addChild(self.sprCamp)
        self.sprCamp:TmpPlayBuildAni(tbPos)
    else
        self.sprCamp:TmpPlayRebuildAni(tbPos)
    end
end

function GameMapScene:maxMapPos()
    return cc.p(0, 0)
end

function GameMapScene:minMapPos()
    local size = MapProxy:getWholeMapSize()
    return cc.p(- size.width * self.map:getScale() + display.width, - size.height * self.map:getScale() + display.height)
end

function GameMapScene:moveOffset(offset, animation)
    -- local x, y = self.map:getPosition()

    -- local pos = cc.p(x+offset.x, y+offset.y)
    self.posMapOffset = offset

    local minPos = self:minMapPos()
    local maxPos = self:maxMapPos()

    if self.posMapOffset.x > maxPos.x then
        self.posMapOffset.x = maxPos.x
    end

    if self.posMapOffset.x < minPos.x then
        self.posMapOffset.x = minPos.x
    end

    if self.posMapOffset.y > maxPos.y then
        self.posMapOffset.y = maxPos.y
    end

    if self.posMapOffset.y < minPos.y then
        self.posMapOffset.y = minPos.y
    end
    -- print("GameMapScene:moveOffset...........", offset.x, offset.y, pos.x, pos.y, MapProxy.map[0][0]:getPositionX(),  MapProxy.map[0][0]:getPositionY() )
    self.map:stopAllActions()
    self.map:setPosition(self.posMapOffset)
    --    end
    if not animation then
        self:drawCityLine()
    end
end

function GameMapScene:LoadMapByRect(rect)
    -- print("GameMapScene:LoadMapByRect", rect.x, rect.y, rect.width, rect.height)
    -- local rect = self:getFrameRect()
    self:LoadMapByPos(cc.p(rect.x, rect.y))
    self:LoadMapByPos(cc.p(rect.x, rect.height))
    self:LoadMapByPos(cc.p(rect.width, rect.y))
    self:LoadMapByPos(cc.p(rect.width, rect.height))
end

function GameMapScene:LoadMapByPos(center)
    local pos = MapProxy:getLoadMap(center)
    --     print("GameMapScene:LoadMapByPos", center.x, center.y)
    if pos == nil then
        return
    end

    if MapProxy.map[pos.x] and MapProxy.map[pos.x][pos.y] then
        return
    end
--    dump(pos, 'GameMapScene:LoadMapByPos')
    self:LoadMap(pos.x, pos.y)
end

function GameMapScene:getFrameRect(data)
    local pos = data
    local scale = self.map:getScale()
    local size = cc.size(display.width / self.minScale, display.height / self.minScale)
    local rect = cc.rect(0, 0, size.width, size.height)
    if not data then
        rect.x = math.abs(self.map:getPositionX())
        rect.y = math.abs(self.map:getPositionY())

    else
        rect.x = math.max(0, data.x - size.width / 2)
        rect.y = math.max(0, data.y - size.height / 2)
    end

    rect.width = rect.x + size.width
    rect.height = rect.y + size.height
    return rect
end

function GameMapScene:initMap(data)
    MapProxy:clear()

    -- self:LoadMapByPos(data.center)
    self.minScale = 0.5
    self.maxScale = 1.2

    local rect = self:getFrameRect(data)

    self:LoadMapByRect(rect)
    self:moveOffset(cc.p(- rect.x, - rect.y))
    self:enableTouch()

    ---youwenti
    self.posCenter = cc.p( math.floor(display.cx), math.floor(display.cy))
    --
    self:initNpc()
    self:initBuilding()
end

function GameMapScene:initNpc()
    self.tbNPC = { }
    self.tbNpcPos = {}

    local tbNpcData = PlayerProxy:GetNpcData()
    for key, value in pairs(tbNpcData) do
        local nGridPosX_Now = value.nMapPosX * MapProxy.cellWidth + value.nGridPosX_Now
        local nGridPosY_Now = value.nMapPosY * MapProxy.cellHeight + value.nGridPosY_Now
        local nId = tonumber(key)
        if value.nCamp ~= 0 then
            nId = nId + 1000
        end

        local sprObject = RoleObject:create(nId, 2, 3)
        sprObject:SetStateType(EnumStateType.IDLE)
        sprObject:setAnchorPoint(cc.p(0.5, 0.5))
        sprObject:setPosition(MapProxy:getCellPos(nGridPosX_Now, nGridPosY_Now))
        self.layerRole:addChild(sprObject)

        if value.nCamp == 0 then
            self.objMyself = sprObject
            self.objMyself:SetVisible(false)
            self.tbStayPos = cc.p(nGridPosX_Now, nGridPosY_Now)
        else
            self.tbNpcPos[nGridPosX_Now * 1000 .. nGridPosY_Now] = nId
            self.tbNPC[nId] = {
                sprObject = sprObject,
                x = nGridPosX_Now,
                y = nGridPosY_Now
            }
        end
    end
end

function GameMapScene:LoadMap(nMapX, nMapY)
    if nMapX < 0 or nMapX >= MapProxy.gridW then
        return
    end

    if nMapY < 0 or nMapY >= MapProxy.gridH then
        return
    end

    self.nLoadingMapX = nMapX
    self.nLoadingMapY = nMapY

    local info = MapProxy:getMapInfo(nMapX, nMapY)

    if info == nil then
        return
    end
    --     print("GameMapScene:LoadMap", x,y, info.res)
    local tiledMap = ccexp.TMXTiledMap:create(info.res)
    local size = MapProxy.mapSize


    tiledMap:setPosition(MapProxy.mapSize.width * nMapX, MapProxy.mapSize.height * nMapY)

    self.map:addChild(tiledMap, ZODER_MAP_LAYER.TILEDMAP)

    if MapProxy.map[nMapX] == nil then
        MapProxy.map[nMapX] = { }
    end

    MapProxy.map[nMapX][nMapY] = tiledMap
    MapProxy.count = MapProxy.count + 1

    MapProxy:createCityLine(nMapX, nMapY, tiledMap)
    MapProxy:LoadCellProperty(nMapX, nMapY)

    --    self:initBuilding(map:getObjectGroup("object_build"))
end

function GameMapScene:initBuilding()
    self.tbSprBuilding = {}
    local tbBuildingConfig = BuildingProxy:GetBuildingConfig()
    local tbBuildingData = BuildingProxy:GetBuildingData()
    for key, value in ipairs(tbBuildingData) do
        local nGridPosX = value.nMapPosX * MapProxy.cellWidth + value.nGridPosX
        local nGridPosY = value.nMapPosY * MapProxy.cellHeight + value.nGridPosY

        local nType = value.nType
        local szImg = tbBuildingConfig[nType].szImg
        local sprBuilding = BuildingObject:create(200000, 1)
        sprBuilding:setPosition(MapProxy:getCellPos(nGridPosX, nGridPosY))
        self.layerBuilding:addChild(sprBuilding)

        self.tbSprBuilding[key] = sprBuilding

        if value.nCamp == 0 then
            self.tbTownPos = cc.p(nGridPosX, nGridPosY)
        end
    end
end

function GameMapScene:getCellInfo(x, y)
    local w =(MapProxy.w - 6) / 2

    local r = w * 2 / math.sqrt(3)
    local h = r / 2
    local deltar = MapProxy.r - r
    local deltaw = deltar * math.sqrt(0.75)
    local deltah = deltar / 2

    self.keys = { "l", "ld", "rd", "r", "ru", "lu" }
    self.w = w
    self.h = h
    self.r = r

    self.preArray =
    {
        cc.p(0,deltar),
        cc.p(- deltaw,deltah),
        cc.p(- deltaw,- deltah),
        cc.p(0,- deltar),
        cc.p(deltaw,- deltah),
        cc.p(deltaw,deltah),
    }

    self.backArray = {
        cc.p(- deltaw,- deltah),
        cc.p(0,- deltar),
        cc.p(deltaw,- deltah),
        cc.p(deltaw,deltah),
        cc.p(0,deltar),
        cc.p(- deltaw,deltah),
    }
end

function GameMapScene:drawCellLine(cell, version)
    local pos = MapProxy:getCellPos(cell.pos.x, cell.pos.y)

    local cellpos = cell.pos

    if self.keys == nil then
        self:getCellInfo()
    end


    local array = { }
    local keys = self.keys
    local posArr = {
        cc.p(pos.x - self.w,pos.y + self.h),
        cc.p(pos.x - self.w,pos.y - self.h),
        cc.p(pos.x,pos.y - self.r),
        cc.p(pos.x + self.w,pos.y - self.h),
        cc.p(pos.x + self.w,pos.y + self.h),
        cc.p(pos.x,pos.y + self.r)
    }

    local preArray = self.preArray
    local backArray = self.backArray

    local isstart = false
    local lastid = 1
    for i = 1, 6 do

        if cell[keys[i]] then
            local j = i + 1

            if i == 6 then
                j = 1
            end


            if isstart == false then
                isstart = true

                local pre = i - 1
                if pre <= 0 then
                    pre = 6
                end
                if cell[keys[pre]] then
                    table.insert(array, posArr[i])
                else
                    table.insert(array, cc.pAdd(posArr[i], preArray[i]))
                end
                table.insert(array, posArr[j])

            else
                table.insert(array, posArr[j])
            end
            lastid = j
            -- cell[keys[i]] = MapLineStaus.DrawSplit
        else
            if isstart == true then

                if lastid ~= 1 or(lastid == 1 and not cell[keys[lastid]]) then
                    array[#array] = cc.pAdd(array[#array], backArray[lastid])
                end

                self.drawNode:drawCatmullRom(array, #array, cc.c4f(0, 0, 1, 1))
                array = { }
                isstart = false
            end
        end

    end

    if isstart == true then
        if lastid ~= 1 or(lastid == 1 and not cell[keys[lastid]]) then
            array[#array] = cc.pAdd(array[#array], backArray[lastid])
        end
        --        print('ttt2222')
        --        if cell.pos.x > 2 and cell.pos.x < 8 and cell.pos.y > 10 and cell.pos.y < 18 then
        --            dump(array,'array2')
        --        end

        self.drawNode:drawCatmullRom(array, #array, cc.c4f(0, 0, 1, 1))
        isstart = false
    end


end

function GameMapScene:drawCityLine()
    local w = MapProxy.w / 2
    local h = MapProxy.r / 2
    local r = MapProxy.r

    local rect = self:getFrameRect()

    local miny = rect.y * 2 /(3 * r) -1
    local maxy =(rect.height) * 2 /(3 * r) + 1
    local minx = rect.x / MapProxy.w - 1
    local maxx =(rect.width) / MapProxy.w + 1
    minx = math.max(math.floor(minx), 0)
    maxx = math.ceil(maxx)
    miny = math.max(math.floor(miny), 0)
    maxy = math.ceil(maxy)

    local route = { }
    self.drawNode:clear()
    for i = miny, maxy do
        if MapProxy.cellProperty[i] then
            for j = minx, maxx do
                local cell = MapProxy.cellProperty[i][j]
                if cell and MapProxy:checkPointLine(cell, 2) then
                    self:drawCellLine(cell)
                end
            end
        end
    end
end

function GameMapScene:init()
    --    print('GameMapScene:init--------')
    local scene = cc.Scene:create()

    scene:addChild(self)
    display.runScene(scene)

    self.maps = { }

    --主层
    local layer = cc.Layer:create()
    self:addChild(layer, -1)
    self.layer = layer
    --地图层
    self.map = cc.Layer:create()
    local size = MapProxy:getWholeMapSize()
    -- self.map:setContentSize(size)
    -- self.map:setAnchorPoint(cc.p(0, 0))
    self.map:ignoreAnchorPointForPosition(false)
    self.map:setAnchorPoint(cc.p(0, 0))
    layer:addChild(self.map, ZODER_MIAN_LAYER.MAP)

    --建筑层
    self.layerBuilding = cc.Layer:create()
    self.map:addChild(self.layerBuilding, ZODER_MAP_LAYER.BUILDING)

    --人物层
    self.layerRole = cc.Layer:create()
    self.map:addChild(self.layerRole, ZODER_MAP_LAYER.ROLE)

    --UI层
    self.ui = cc.Layer:create()
    layer:addChild(self.ui, ZODER_MIAN_LAYER.UI)



    self.drawNode = cc.DrawNode:create()
    self.map:addChild(self.drawNode, ZODER_MAP_LAYER.DRAWNODE)
    -- self:onDrawRange()
    --self:initPanelUI()
    self:initUiDialog()

    self:initHotKey()
    self:showHotKey()
    --    self:initButtons()
    --    self:initScrollView()
    self:initSelectInfo()
    self:initKeyboardListen()

    self.bArmyMove = true
end

function GameMapScene:initUiDialog()
    self.tbDialog = {}
end

function GameMapScene:showDialog(szType, tbDisableList)
    self.bExistDlg = true
    self:dispatchEvent({name = GameMapMediator:GetMsg('OPEN_DLG'), data = {
        szType = szType,
        tbDisableList = tbDisableList
    }})
end

--function GameMapScene:initPanelUI()
--    self.panelUi = GameToolPanel.new(self)
--    self.panelUi:SetLabPos(self.posCenter)
--    self.ui:addChild(self.panelUi, ZODER_UI_LAYER.PANEL)
--end

function GameMapScene:initTiledPos()
    self.tbLoadedTiledInfo = {}
    local layer1 = self.loadMap:getLayer(self.tbTmxInfo[1].tbLayerName[1])
    for x = 0, self.mmmapSize.width - 1 do
        local nColumn = x
        self.tbLoadedTiledInfo[nColumn] = {}
        for y = 0, self.mmmapSize.height - 1 do
            local nRow = self.mmmapSize.height - 1 - y
            local spr = layer1:getTileAt(cc.p(x, y))
            if spr then
                self.tbLoadedTiledInfo[nColumn][nRow] = {
                    nOffsetX = 0,
                    nOffsetY = 0,
                    nRotation = 0,
                    bMirror_H = false,
                    bMirror_V = false,
                }
                spr:setAnchorPoint(cc.p(0.5, 0.5))
            end
        end
    end
    --    dump(self.tbLoadedTiledInfo, 'self.tbLoadedTiledInfo')
    self:readMapTiledInfo()
end

function GameMapScene:initKeyboardListen()
    local function onKeyReleased(keyCode, event)
        if keyCode == cc.KeyCode.KEY_UP_ARROW then
            if self.bEditTiled and self.sprSelect then
                self.tbSelectInfo.nOffsetY = self.tbSelectInfo.nOffsetY + 1
                self.sprSelect:setPositionY(self.sprSelect:getPositionY() + 1)
                self.labSaveTip:setVisible(true)
            end
        elseif keyCode == cc.KeyCode.KEY_DOWN_ARROW then
            if self.bEditTiled and self.sprSelect then
                self.tbSelectInfo.nOffsetY = self.tbSelectInfo.nOffsetY - 1
                self.sprSelect:setPositionY(self.sprSelect:getPositionY() - 1)
                self.labSaveTip:setVisible(true)
            end
        elseif keyCode == cc.KeyCode.KEY_LEFT_ARROW then
            if self.bEditTiled and self.sprSelect then
                self.tbSelectInfo.nOffsetX = self.tbSelectInfo.nOffsetX - 1
                self.sprSelect:setPositionX(self.sprSelect:getPositionX() - 1)
                self.labSaveTip:setVisible(true)
            end
        elseif keyCode == cc.KeyCode.KEY_RIGHT_ARROW then
            if self.bEditTiled and self.sprSelect then
                self.tbSelectInfo.nOffsetX = self.tbSelectInfo.nOffsetX + 1
                self.sprSelect:setPositionX(self.sprSelect:getPositionX() + 1)
                self.labSaveTip:setVisible(true)
            end
        elseif keyCode == cc.KeyCode.KEY_R then --顺时针旋�?
        if self.bEditTiled and self.sprSelect then
            self.tbSelectInfo.nRotation = self.tbSelectInfo.nRotation + 1
            self.sprSelect:setRotation(self.tbSelectInfo.nRotation)
            self.labSaveTip:setVisible(true)
        end
        elseif keyCode == cc.KeyCode.KEY_E then --逆时针旋�?
        if self.bEditTiled and self.sprSelect then
            self.tbSelectInfo.nRotation = self.tbSelectInfo.nRotation - 1
            self.sprSelect:setRotation(self.tbSelectInfo.nRotation)
            self.labSaveTip:setVisible(true)
        end
        elseif keyCode == cc.KeyCode.KEY_A then --左右镜像
        if self.bEditTiled and self.sprSelect then
            self.tbSelectInfo.bMirror_H = not self.tbSelectInfo.bMirror_H
            self.sprSelect:setFlippedX(self.tbSelectInfo.bMirror_H)
            self.labSaveTip:setVisible(true)
        end
        elseif keyCode == cc.KeyCode.KEY_W then --上下镜像
        if self.bEditTiled and self.sprSelect then
            self.tbSelectInfo.bMirror_V = not self.tbSelectInfo.bMirror_V
            self.sprSelect:setFlippedY(self.tbSelectInfo.bMirror_V)
            self.labSaveTip:setVisible(true)
        end
        elseif keyCode == cc.KeyCode.KEY_ESCAPE then
            if self.bEditTiled and self.sprSelect then
                self.sprSelect:setColor(cc.c3b(255, 255, 255))
                self.sprSelect = nil
                self.tbSelectInfo = nil
                self.labSaveTip:setVisible(true)
            end
        elseif keyCode == cc.KeyCode.KEY_X then
            if self.bEditTiled and self.sprSelect then
                self.sprSelect:setPositionX(self.sprSelect:getPositionX() - self.tbSelectInfo.nOffsetX)
                self.sprSelect:setPositionY(self.sprSelect:getPositionY() - self.tbSelectInfo.nOffsetY)
                self.sprSelect:setRotation(0)
                self.sprSelect:setFlippedX(false)
                self.sprSelect:setFlippedY(false)
                self.tbSelectInfo.nOffsetX = 0
                self.tbSelectInfo.nOffsetY = 0
                self.tbSelectInfo.nRotation = 0
                self.tbSelectInfo.bMirror_H = false
                self.tbSelectInfo.bMirror_V = false
                self.labSaveTip:setVisible(true)
            end
        elseif keyCode == cc.KeyCode.KEY_S then --保存修改的地�?
        if self.bEditTiled then
            self.labSaveTip:setVisible(false)
            self:saveMapTiledInfo()
        end
        elseif keyCode == cc.KeyCode.KEY_F1 then --快捷键说�?
        self:showHotKey()
        elseif keyCode == cc.KeyCode.KEY_F2 then --开/关图块编辑器
        self.bEditTiled = not self.bEditTiled
        if not self.bEditTiled and self.sprSelect then
            self.sprSelect:setColor(cc.c3b(255, 255, 255))
        end
        --        elseif keyCode == cc.KeyCode.KEY_F3 then --部队行走，移动地图
        --            self.nSelectArmy = not self.nSelectArmy
        end
    end

    local listener = cc.EventListenerKeyboard:create()
    listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED)

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
end

function GameMapScene:showHotKey()
    self.bShowHotKey = not  self.bShowHotKey
    for _, label in ipairs(self.tbLabelHotKey) do
        label:setVisible(self.bShowHotKey)
    end
end

function GameMapScene:initHotKey()
    self.bEditTiled = false
    self.bShowHotKey = true
    self.tbLabelHotKey = {}

    self.tbLabelHotKey[1] = cc.Label:createWithSystemFont( LocalizePS.GetStr("MAP_EDIT_HELP", "introduction1"), "Arial", 25)
    self.layer:addChild(self.tbLabelHotKey[1], 100)
    self.tbLabelHotKey[1]:setPosition(300, 600)

    self.tbLabelHotKey[2] = cc.Label:createWithSystemFont(LocalizePS.GetStr("MAP_EDIT_HELP", "introduction2"), "Arial", 25)
    self.layer:addChild(self.tbLabelHotKey[2], 100)
    self.tbLabelHotKey[2]:setPosition(800, 600)

    self.tbLabelHotKey[3] = cc.Label:createWithSystemFont(LocalizePS.GetStr("MAP_EDIT_HELP", "introduction3"), "Arial", 25)
    self.layer:addChild(self.tbLabelHotKey[3], 100)
    self.tbLabelHotKey[3]:setPosition(300, 500)

    self.tbLabelHotKey[4] = cc.Label:createWithSystemFont(LocalizePS.GetStr("MAP_EDIT_HELP", "introduction4"), "Arial", 25)
    self.layer:addChild(self.tbLabelHotKey[4], 100)
    self.tbLabelHotKey[4]:setPosition(800, 500)

    self.tbLabelHotKey[5] = cc.Label:createWithSystemFont(LocalizePS.GetStr("MAP_EDIT_HELP", "introduction5"), "Arial", 25)
    self.layer:addChild(self.tbLabelHotKey[5], 100)
    self.tbLabelHotKey[5]:setPosition(300, 400)

    self.tbLabelHotKey[6] = cc.Label:createWithSystemFont(LocalizePS.GetStr("MAP_EDIT_HELP", "introduction6"), "Arial", 25)
    self.layer:addChild(self.tbLabelHotKey[6], 100)
    self.tbLabelHotKey[6]:setPosition(800, 400)

    self.labSaveTip = cc.Label:createWithSystemFont('**', "Arial", 100)
    self.layer:addChild(self.labSaveTip, 100)
    self.labSaveTip:setPosition(600, 700)
    self.labSaveTip:setVisible(false)
end

function GameMapScene:saveMapTiledInfo()
    table.save(self.tbLoadedTiledInfo, "res/map/map_tiled_info.edit")
end

function GameMapScene:readMapTiledInfo()
    local info, errorinfo = table.loadEx("res/map/map_tiled_info.edit")
    --    dump(info, 'info')
    --    dump(errorinfo, 'errorinfo')
    if errorinfo or not info then
        --        print('not readMapTiledInfo')
        return
    end
    local layer1 = self.loadMap:getLayer(self.tbTmxInfo[1].tbLayerName[1])

    self.tbLoadedTiledInfo = info
    for nColumn = 0, self.mmmapSize.width - 1 do
        for nRow = 0, self.mmmapSize.height - 1 do
            local tbInfo = self.tbLoadedTiledInfo[nColumn][nRow]
            if tbInfo then
                local nOffsetX = tbInfo.nOffsetX
                local nOffsetY = tbInfo.nOffsetY
                local nRotation = tbInfo.nRotation
                local bMirror_H = tbInfo.bMirror_H
                local bMirror_V = tbInfo.bMirror_V

                local spr = self:getSprTiled(cc.p(nColumn, nRow))
                spr:setPositionX(spr:getPositionX() + nOffsetX)
                spr:setPositionY(spr:getPositionY() + nOffsetY)
                spr:setRotation(nRotation)
                spr:setFlippedX(bMirror_H)
                spr:setFlippedY(bMirror_V)
            end
        end
    end
end

function GameMapScene:initSelectInfo()
    self.sprSelect = nil
    self.tbSelectInfo = {
        nOffsetX = 0,
        nOffsetY = 0,
        nRotation = 0,
        bMirror_H = false,
        bMirror_V = false,
    }
end

function GameMapScene:addFightIcon(pos)
    self.sprFightIcon = display.newSprite('res/ui/button/button2.png')
    self.sprFightIcon:setPosition(pos)
    self.map:addChild(self.sprFightIcon, ZODER_MAP_LAYER.ROLE_TAG_FIGHT)
end

function GameMapScene:removeFightIcon()
    if self.sprFightIcon then
        self.map:removeChild(self.sprFightIcon)
        self.sprFightIcon = nil
    end
end

function GameMapScene:initButtons()
    self.btnCancle = ccui.Button:create("Default/Button_Normal.png","Default/Button_Press.png")
    self.btnCancle:setPosition(cc.p(100,600))
    self.btnCancle:setTitleText(LocalizePS.GetStr("MAP_EDIT_HELP", "cancel"))
    self.btnCancle:setTitleColor(cc.c3b(0,0,0))
    self.btnCancle:setTitleFontSize(20)
    self.btnCancle:addTouchEventListener(handler(self, function()

    end))
    self.resourceNode_:addChild(self.btnCancle)
end

function GameMapScene:getSprTiled(tbPos)
    local layer1 = self.loadMap:getLayer(self.tbTmxInfo[1].tbLayerName[1])
    local sprTest = layer1:getTileAt(cc.p(tbPos.x, self.mmmapSize.height - 1 - tbPos.y))
    return sprTest
end


function GameMapScene:onDrawRange()
    local w = MapProxy.w / 2 - 20
    local h = MapProxy.r / 2
    local r = MapProxy.r
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/third/line.plist")

    local lines = cc.Sprite:create()
    local center = cc.p(150, 86.5)

    local pos = {
        cc.p(center.x - w,center.y),
        cc.p(center.x - w / 2 + 12.5,center.y - r * 3 / 4 + 20),
        cc.p(center.x + w / 2 - 12.5,center.y - r * 3 / 4 + 20),
        cc.p(center.x + w,center.y),
        cc.p(center.x + w / 2 - 12.5,center.y + r * 3 / 4 - 20),
        cc.p(center.x - w / 2 + 12.5,center.y + r * 3 / 4 - 20),
    }

    for i = 1, 6 do
        local sprite = cc.Sprite:createWithSpriteFrameName(i .. ".png")
        sprite:setPosition(pos[i])
        lines:addChild(sprite)
    end

    --    local array3 = {
    --        cc.p(center.x - w,center.y + h),
    --        cc.p(center.x - w,center.y - h),
    --        cc.p(center.x,center.y - r),
    --        cc.p(center.x + w,center.y - h),
    --        cc.p(center.x + w,center.y + h),
    --        cc.p(center.x + 75 + w,center.y + r * 3 / 2 - h),
    --        cc.p(center.x + 75 + w,center.y + r * 3 / 2 + h),
    --        cc.p(center.x + 75,center.y + r * 3 / 2 + r),
    --        cc.p(center.x + 75 - w,center.y + r * 3 / 2 + h),
    --        cc.p(center.x - 75,center.y + r * 3 / 2 + r),
    --        cc.p(center.x - 75 - w,center.y + r * 3 / 2 + h),
    --        cc.p(center.x - 75 - w,center.y + r * 3 / 2 - h),
    --        cc.p(center.x - w,center.y + h),
    --    }


    -- local drawNode2 = cc.DrawNode:create()
    -- drawNode2:setPosition(size.width/2, 50)
    -- drawNode2:drawCatmullRom(array3, 13, cc.c4f(0, 0, 1, 1))
    self.map:addChild(lines, ZODER_MAP_LAYER.RANGE)
end

function GameMapScene:onTouchBegan(touch, event)
    --    print("GameMapScene:onTouchBegan", touch)
    --    print('self.resourceNode_',self.resourceNode_)


    if table.nums(self._touches) > 2 or self._touchMoved == true then
        return false
    end

    local needadd = true
    for k, v in pairs(self._touches) do
        if v == touch then
            needadd = false
        end
    end
    if needadd then
        table.insert(self._touches, touch)
        --        print("GameMapScene:onTouchBegan   add", touch)
    end

    if table.nums(self._touches) == 1 then
        self.posTouchBegan = self:convertTouchToNodeSpace(touch)
        self.bSelectGrid = true

        self._touchPoint = self:convertTouchToNodeSpace(touch)
        self._touchMoved = false
        self._dragging = true
        self._touchLength = 0.0
        --        print("touch began .....", touch:getLocation().x, touch:getLocation().y, self._touchPoint.x, self._touchPoint.y)
    elseif table.nums(self._touches) == 2 then
        local pos1 = self.map:convertTouchToNodeSpace(self._touches[1])
        local pos2 = self.map:convertTouchToNodeSpace(self._touches[2])

        local pos3 = self:convertTouchToNodeSpace(self._touches[1])
        local pos4 = self:convertTouchToNodeSpace(self._touches[2])
        self._touchPoint = cc.pMidpoint(pos3, pos4)
        self._touchLength = cc.pGetDistance(pos1, pos2)
        self._dragging = false
        --        print("multi touch began  .....", self._touchPoint.x, self._touchPoint.y)
    end

    return true
end



function GameMapScene:NpcDead(nId)
    local x = self.tbNPC[nId].x
    local y = self.tbNPC[nId].y
    self.tbNpcPos[x * 1000 .. y] = nil
    self.tbNPC[nId].sprObject:Dead()
    self.tbNPC[nId] = nil
end

function GameMapScene:getDis(posSrc, posDest)
    return math.sqrt(math.pow(math.abs(posSrc.x - posDest.x), 2) + math.pow(math.abs(posSrc.y - posDest.y), 2))
end


function GameMapScene:getMinScroll()
    return cc.p(- display.width / self.map:getScale(), - display.height / self.map:getScale())
end

function GameMapScene:getMaxScroll()
    return cc.p(display.width / self.map:getScale(), display.height / self.map:getScale())
end



function GameMapScene:onTouchMoved(touch, event)
    if table.nums(self._touches) == 1 then
        local newPoint = self:convertTouchToNodeSpace(touch)

        -- print("touch moved 1.....", self._touchPoint.x, self._touchPoint.y, newPoint.x, newPoint.y, touch:getLocation().x, touch:getLocation().y)
        local moveDistance = cc.pSub(newPoint, self._touchPoint)
        local dis = cc.pGetLength(moveDistance)
        --        print(newPoint.x - self._touchPoint.x, newPoint.y - self._touchPoint.y)

        self.posCenter.x = self.posCenter.x - (newPoint.x - self._touchPoint.x)
        self.posCenter.x = math.floor(self.posCenter.x)
        self.posCenter.y = self.posCenter.y - (newPoint.y - self._touchPoint.y)
        self.posCenter.y = math.floor(self.posCenter.y)
        --self.panelUi:SetLabPos(self.posCenter)
        -- edit by lina
        self:dispatchEvent({name = GameMapMediator:GetMsg('TAB_POSCHANGE')})

        local nMoveDis = cc.pSub(newPoint, self.posTouchBegan)
        local nMoveDis2 = cc.pGetLength(nMoveDis)
        if nMoveDis2 > 20 then
            self.bSelectGrid = false
        end

        --        print("touch moved .....", touch:getLocation().x, touch:getLocation().y, newPoint.x, newPoint.y, moveDistance.x, moveDistance.y)
        self._touchPoint = newPoint
        self._touchMoved = true

        if self._dragging and not self.nSelectArmy and not self.bExistDlg then
            local minlen = self:getMinScroll()
            local maxlen = self:getMaxScroll()

            --            if moveDistance.x < minlen.x then
            --                moveDistance.x = minlen.x
            --            end

            --            if moveDistance.y < minlen.y then
            --                moveDistance.y = minlen.y
            --            end

            --            if moveDistance.x > maxlen.x then
            --                moveDistance.x = maxlen.x
            --            end

            --            if moveDistance.y > maxlen.y then
            --                moveDistance.y = maxlen.y
            --            end

            local newx = self.map:getPositionX() + moveDistance.x
            local newy = self.map:getPositionY() + moveDistance.y
            -- Ҫ��Ҫ����scale
            -- print("touch moved .....", newx, newy, moveDistance.x, moveDistance.y)
            -- if newx > maxpos.x or   newx < minpos.x or newy > maxpos.y or newy < minpos.y then
            self:LoadMapByRect(cc.rect(- newx / self.map:getScale(), - newy / self.map:getScale(),(- newx + display.width) / self.map:getScale(),(- newy + display.height) / self.map:getScale()))
            -- end

            self._scrollDistance = moveDistance
            self:moveOffset(cc.p(newx, newy), true)
            -- self:moveOffset(moveDistance)
        end
    elseif table.nums(self._touches) == 2 and self._dragging == false then
        --        local pos1 = self.map:convertTouchToNodeSpace(self._touches[1])
        --        local pos2 = self.map:convertTouchToNodeSpace(self._touches[2])

        --        local len = cc.pGetDistance(pos1, pos2)
        --         self:setZoomScale(self.map:getScale() * len / self._touchLength)
        --        print("multi touch moved  .....", len)
    end

end

function GameMapScene:onTouchEnded(touch, event)
    if table.nums(self._touches) == 1 and self.bSelectGrid and not self.bExistDlg then
        local nodepos = self.map:convertTouchToNodeSpace(self._touches[1])

        local scale = self.map:getScale()
        local grid, info = MapProxy:checkCellTouch(cc.pMul(nodepos, 1 / scale))
        if self.bEditTiled then
            self:editTiled(touch:getLocation())
        else
            if self.bArmyMove and self.objMyself then
                local posTouch = touch:getLocation()
                posTouch.x = posTouch.x - self.posMapOffset.x
                posTouch.y = posTouch.y - self.posMapOffset.y

                --根据此格子的属性，弹出相应的操作
                self:onSelectGrid(posTouch)
            end

        end
    elseif table.nums(self._touches) == 2 then
        local pos1 = self.map:convertTouchToNodeSpace(self._touches[1])
        local pos2 = self.map:convertTouchToNodeSpace(self._touches[2])

        local len = cc.pGetDistance(pos1, pos2)
        self:setZoomScale(len / self._touchLength)
        --        print("multi touch moved  .....", len)
    else
        --        self:drawCityLine()
    end

    table.removebyvalue(self._touches, touch, true)

    if table.nums(self._touches) == 0 then
        self._dragging = false
        self._touchMoved = false

    end
end

function GameMapScene:onSelectGrid_Stay(tbTouchPos)
    if nSelectGid == POWER_GRID.OCCUPY then
        self:showDialog('CH')
        return
    end
    if self.tbPos_ZY then
        if self.tbPos_ZY.x == self.tbStayPos.x and self.tbPos_ZY.y == self.tbStayPos.y then
            self:showDialog('JS')
            return
        else
            self:showDialog('CH', {btnSD = true})
            return
        end
    end
end

function GameMapScene:onSelectGrid_Outside(tbTouchPos)
    local tbGridInfo = MapProxy.cellProperty[tbTouchPos.y][tbTouchPos.x]
    --我自己的地盘，可扎营
    if nSelectGid == POWER_GRID.MINE then
        if not self.tbPos_ZY or ((self.tbPos_ZY.x ~= tbTouchPos.x or self.tbPos_ZY.y ~= tbTouchPos.y) and
                (tbTouchPos.x ~= self.tbTownPos.x or tbTouchPos.y ~= self.tbTownPos.y))then
            self:showDialog('ZY')
            self.tbPos_want_ZY = tbTouchPos
            self:checkMyArmyVisible()
        end
    --未开荒，可开荒
    elseif nSelectGid == POWER_GRID.UNDEVELOPED then
        if MapProxy:IsMyDomain(tbTouchPos) then
            self:showDialog('TH')
            self.tbPos_TH = tbTouchPos
        end
    --敌人地盘，可抢夺
    elseif nSelectGid == POWER_GRID.ENEMY then
        self:showDialog('GJ')
        self.tbAttackPos = tbTouchPos
    end
end

function GameMapScene:onSelectGrid(posTouch)
    local tbTouchPos = MapProxy:checkCellTouch(posTouch)

    if (self.tbStayPos.x == tbTouchPos.x and self.tbStayPos.y == tbTouchPos.y) then
        self:onSelectGrid_Stay(tbTouchPos)
    else
        self:onSelectGrid_Outside(tbTouchPos)
    end
end

function GameMapScene:showReachTag(pos)
    local sprReachTag = display.newSprite('ui/icon/icon_reach.png')
    sprReachTag:setPosition(pos)
    sprReachTag:runAction(cc.Sequence:create(
        cc.FadeOut:create(2),
        cc.CallFunc:create(function()
            sprReachTag:removeFromParent()
        end)))
    self.map:addChild(sprReachTag, ZODER_MAP_LAYER.REACH_TAG)
end

function GameMapScene:enableTouch()
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(handler(self, self.onTouchBegan), cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(handler(self, self.onTouchEnded), cc.Handler.EVENT_TOUCH_ENDED)
    listener:registerScriptHandler(handler(self, self.onTouchMoved), cc.Handler.EVENT_TOUCH_MOVED)
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
    self._listener = listener
    self._dragging = false
    self._touchMoved = false
    self._touches = { }
end

-- function GameMapScene:setContentOffset(offset)

--    self:moveOffset(offset, true)
-- end

function GameMapScene:setZoomScale(s)

    --    if self.map:getScale() == s then
    --        return
    --    end
    local scalebig = true
    if s - 1.0 < 0.00001 then
        scalebig = false
    end
    local scale = self.map:getScale()
    if scalebig then
        if math.min(self.map:getScale(), self.maxScale) == self.maxScale then
            return
        end
        scale = scale + 0.1
    else
        if math.max(self.map:getScale(), self.minScale) == self.minScale then
            self:disableTouch()
            self:dispatchEvent({name = GameMapMediator:GetMsg('ON_CHANGEMAP'), id = "2", scale = 3, mtype = MapType.FirstLayer})
            return
        end
        scale = scale - 0.1
    end

    local center = cc.p(display.cx, display.cy)
    if self._touchLength and self._touchLength == 0 then
        center = cc.p(display.cx, display.cy)
        center = self:convertToWorldSpace(center)
    elseif self._touchPoint then
        center = self._touchPoint

    end

    local oldcenter = self.map:convertToNodeSpace(center)
    self.map:setScale(scale)

    local newcenter = self.map:convertToWorldSpace(oldcenter)

    --    print("GameMapScene:setZoomScale", s, self.map:getScale(), newcenter.x, newcenter.y, self.map:getContentSize().width)
    local offset = cc.pSub(center, newcenter)
    -- self:setContentOffset(cc.p(self.map:getPositionX() + offset.x, self.map:getPositionY() + offset.y))
    self:moveOffset(cc.p(self.map:getPositionX() + offset.x, self.map:getPositionY() + offset.y))

    -- self:moveOffset(cc.p(self.map:getPositionX() - newcenter1.x, self.map:getPositionY() - newcenter1.y), true)
end

function GameMapScene:editTiled(pos)
    if self.sprSelect then
        self.sprSelect:setColor(cc.c3b(255, 255, 255))
    end
    local tbSelectPos  = MapProxy:checkCellTouch(pos)
    self.sprSelect = self:getSprTiled(tbSelectPos)
    if self.sprSelect then
        self.tbSelectInfo = self.tbLoadedTiledInfo[tbSelectPos.x][tbSelectPos.y]
        self.sprSelect:setColor(cc.c3b(110, 255, 255))
    end
end

function GameMapScene:objectMoveTouch(posTouch)
    local tbDest = MapProxy:checkCellTouch(posTouch)
    self:objectMove(tbDest)
end

function GameMapScene:objectMove(tbDest)
    local tbSrc = MapProxy:checkCellTouch(cc.p(self.objMyself:getPosition()))
    print(tbSrc.x, tbSrc.y, '-->', tbDest.x, tbDest.y)
    local pos = MapProxy:getCellPos(tbDest.x, tbDest.y)

    self.bArmyMove = false
    self.tbTestRoad = {}
    self.tbTestEmpty = {}
    for i = 0, 19 do
        self.tbTestRoad[i] = {}
        self.tbTestEmpty[i] = {}
        for j = 0, 19 do
            self.tbTestRoad[i][j] = true
        end
    end
    local _, tbList = Astar(
        {nColumn = tbSrc.x, nHeight = tbSrc.y},
        {nColumn = tbDest.x, nHeight = tbDest.y},
        self.tbTestRoad,
        self.tbTestEmpty)
    if #tbList > 0 then
        local nDirect = 0
        local nDisX = pos.x - cc.p(self.objMyself:getPosition()).x
        local nDisY = pos.y - cc.p(self.objMyself:getPosition()).y
        local k = nDisY / nDisX
        self.objMyself:SetVisible(true)
        self.objMyself:Move2Dest(tbList, 1, self.tbNpcPos, tbDest)
    else
        self.bArmyMove = true
    end
end


return GameMapScene