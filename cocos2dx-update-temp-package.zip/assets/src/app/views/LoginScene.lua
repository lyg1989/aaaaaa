local LoginScene = class("LoginScene", BaseViewComponent)

LoginScene.RESOURCE_FILENAME = "login.csb"

local LoginMediator = require("app.views.LoginMediator")
function LoginScene:onEnter()

    -- test login
    self:dispatchEvent(LoginMediator.ON_LOGIN, User.New({
        username = "test",
        password = "test"
    }))
end

function LoginScene:updateServerList(servers)

    -- test on server
    self:dispatchEvent(LoginMediator.ON_SERVER, servers[1])
end

function LoginScene:displayLoginError()
    print("can not login to server")
end

return LoginScene