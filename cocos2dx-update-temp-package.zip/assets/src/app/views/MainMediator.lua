local  MainMediator = class("MainMediator", BaseMediator)
local MainScene = require("app.views.MainScene")

function MainMediator:didRegister()

--    self:bind(MainScene.ITEAM, handler(self, self.onIteam))
    --self.viewComponent:initMap(MapType.FirstLayer)
    self.viewComponent:initMap(self.contextData.mtype, self.contextData.id, self.contextData.scale)
end

--function MainMediator:onAdd()
--    local str=self.viewComponent.controls["text_Instruction"]:getString()
--    game:sendNotification(GAME.GM_OPCODE, {str = str})

--end

function MainMediator:listNotificationInterests()
    return {
       --GAME.USER_LOGIN_SUCCESS,  
    }
end

function MainMediator:onBattle()
	
end

function MainMediator:CHARACHTER()
--    print("MainMediator:CHARACHTER") 
--    local context = Context:buildContext({}, SCENE.BUTTON)
--    local subcontext = Context:buildContext({},SCENE.HEROLIST)
--    context:pushContext(subcontext)
--    local context1 = Context:buildContext({}, SCENE.CHARACTER)
--    subcontext:pushContext(context1)

--    self:addSubLayers(context)
end



function MainMediator:handleNotification(note)
    local name = note:getName()
    local data = note:getBody()

    if name == GAME.PLAYER_UPGRADE then
        self.viewComponent:updateLevel(data.level)
    end  
end



return MainMediator