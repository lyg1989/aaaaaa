local LoginMediator = class("LoginMediator", BaseMediator)

LoginMediator.ON_LOGIN = "LoginMediator:ON_LOGIN"
LoginMediator.ON_SERVER = "LoginMediator:ON_SERVER"

function LoginMediator:onRegister()
    self:bind(LoginMediator.ON_LOGIN, function(e, user)
        self:sendNotification(GAME.LOGIN, user)
    end)

    self:bind(LoginMediator.ON_SERVER, function(e, user)
        self:sendNotification(GAME.LOGIN, user)
    end)
end



function LoginMediator:listNotificationInterests()
    return {
        GAME.USER_LOGIN_SUCCESS,
        GAME.USER_LOGIN_FAILED
    }
end

function LoginMediator:handleNotification(note)
    local name = note:getName()
    local body = note:getBody()

    if name == GAME.USER_LOGIN_SUCCESS then

        self.viewComponent:updateServerList()

    elseif name == GAME.USER_LOGIN_FAILED then
        self.viewComponent:displayLoginError()

    end
end