local ItemMediator = class("ItemMediator", BaseMediator)
local ItemLayer=require("app/views/ItemLayer")

function ItemMediator:didRegister()
    --self:bind(ItemLayer.ADDITEM, handler(self, self.add))
   -- self:bind(ItemLayer.DROP, handler(self, self.drop))
    --self:bind(ItemLayer.CHARACTER, handler(self, self.character))    
end

function ItemMediator:listNotificationInterests()
    return {
        GAME.ITEM_ADD_ITEM,
        GAME.ITEM_UPDATE_ITEMDATA,
        GAME.ITEM_DROP_ITEM,
    }
end

function ItemMediator:handleNotification(note)
    local name = note:getName()
    local data = note:getBody()


    self.viewComponent:loadItem(data)     
    
end










return ItemMediator