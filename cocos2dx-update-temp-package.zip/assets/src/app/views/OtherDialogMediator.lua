
local OtherDialogMediator = class("OtherDialogMediator", BaseMediator)

function OtherDialogMediator:didRegister()
    --�Ѷ�Ӧ������͵��÷�����
    OtherDialogMediator.tbBindList = {
        MAINSCENE_OTHER_PRINT_OUTPUT = {
            szMsg = 'MAINSCENE_OTHER_PRINT_OUTPUT',
            func = OtherDialogMediator.dispatchOutput
        },

        MAINSCENE_OTHER_LISTVIEW = {
            szMsg = 'MAINSCENE_OTHER_LISTVIEW',
            func = OtherDialogMediator.dispatchListview
        }
    }

    for key, value in pairs(OtherDialogMediator.tbBindList) do
        self:bind(value.szMsg, 
            function(e)
                value.func(self)
            end
        )
    end

    self:bind('MAINSCENE_OTHER_SLIDER', 
        function(e)
            self:dispatchSlider(e.data)
        end
    )

    self:bind('MAINSCENE_OTHER_CHECKBOX',
        function(e)
            self:dispatchCheckbox(e.data)
        end
    )
end



function OtherDialogMediator:GetMsg(szMsg)
    return OtherDialogMediator.tbBindList[szMsg].szMsg
end



function OtherDialogMediator:listNotificationInterests()
    return {
        GAME.MAINSCENE_OTHER_PRINT_OUTPUT,
        GAME.MAINSCENE_OTHER_SLIDER,
        GAME.MAINSCENE_OTHER_CHECKBOX,
        GAME.MAINSCENE_OTHER_LISTVIEW,
    }
end


function OtherDialogMediator:handleNotification(note)
    local name = note:getName()
    local data = note:getBody()

    if name == GAME.MAINSCENE_OTHER_PRINT_OUTPUT then
        print("output!!!   output!!!   output!!!   output!!!")
    elseif name == GAME.MAINSCENE_OTHER_SLIDER then
        data.info.bar:setPercent(data.info.percent)
    elseif name == GAME.MAINSCENE_OTHER_CHECKBOX then
        if data.info.isTrue == true then
            print("checkbox set true")
        else
            print("checkbox set false")
        end
    elseif name == GAME.MAINSCENE_OTHER_LISTVIEW then
        print("listview!!")
    end
end




--���ʹ�ӡoutput��֪ͨ
function OtherDialogMediator:dispatchOutput()
    game:sendNotification(GAME.MAINSCENE_OTHER_PRINT_OUTPUT, {})
end


function OtherDialogMediator:dispatchSlider(data)
    game:sendNotification(GAME.MAINSCENE_OTHER_SLIDER, {info = data})
end


function OtherDialogMediator:dispatchCheckbox(data)
    game:sendNotification(GAME.MAINSCENE_OTHER_CHECKBOX, {info = data})
end


function OtherDialogMediator:dispatchListview()
    game:sendNotification(GAME.MAINSCENE_OTHER_LISTVIEW, {})
end


return OtherDialogMediator