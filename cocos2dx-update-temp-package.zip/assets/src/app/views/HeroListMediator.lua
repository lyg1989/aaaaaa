local HeroListMediator = class('HeroListMediator', BaseMediator)
local HeroListLayer=require("app/views/HeroListLayer")

function HeroListMediator:didRegister()
    self:bind(HeroListLayer.HeroEquip, handler(self,self.equipToHero))
    self:bind(HeroListLayer.heroIno,handler(self,self.heroInfo))
end

function HeroListMediator:heroUpdataLv()
    
end

function HeroListMediator:sendMessage(title,info)
    local function okClick()


    end
    local function canlClick()

        self.viewComponent:onClose()
    end
    local  callbc = {}
    callbc.OK = okClick

    callbc.msg =info
    callbc.cancel=canlClick
    callbc.title=title
    local context = Context:buildContext(callbc ,SCENE.POPUP)
    self:addSubLayers(context)
end


function HeroListMediator:equipToHero(event)
    local heroId = self.viewComponent.id
    local heroName = self.viewComponent.name
    local itemUid = self.contextData.uid
    local itemEntryId = self.contextData.entryId  

    local itemProxy = getProxy("ItemProxy")

    itemProxy:useItem(itemUid,itemEntryId)
    itemProxy:sendItemToHero(heroId,itemEntryId)
    self:sendMessage("cmd",heroName)
end

function HeroListMediator:init()
   
    
end

function HeroListMediator:heroInfo(event)
    dump(event)
 
    game:sendNotification(GAME.VIEW_HERO_DATA,{id=event.id})
end

function HeroListMediator:listNotificationInterests()

    return {
        GAME.HEROS_DELETE,
        GAME.HEROS_ADD,
    }
end

function HeroListMediator:handleNotification(note)
    local name = note:getName()
    local data = note:getBody()
   
    if name==GAME.HEROS_DELETE then

        self.viewComponent:DelHero(data)
    end
    if name==GAME.HEROS_ADD then

        self.viewComponent:AddHero(data)
    end
end

return HeroListMediator