local HeroListLayer = class("HeroListLayer",BaseViewComponent)
local imageListBox = require("init.ImageListBox")

HeroListLayer.RESOURCE_FILENAME = "HeroList.csb"
HeroListLayer.RESOURCE_BINDING =
{
    bg = {},
}

HeroListLayer.heroIno = "HeroListLayer:heroIno"
HeroListLayer.heroUpdataLv = "HeroListLayer.heroUpdataLv"
HeroListLayer.HeroEquip = "HeroListLayer.HeroEquip"

function HeroListLayer:onExit()
   
end

function HeroListLayer:onClose()
    self:dispatchEvent({name=BaseViewComponent.ON_CLOSE})    
end 

function HeroListLayer:onEnter()

    local size = self.controls["bg"]:getContentSize()
    self.scroll = imageListBox:create(size)
    self.scroll:InitInfo(180,26,0,5)
    self.scroll:SetSelImgId(101)
    --self.scroll:setPosition(size.width/2, size.height/2)
    self.controls["bg"]:addChild(self.scroll)
    self.scroll:setScrollX(true)
    self:freshItem()
end

function HeroListLayer:freshItem()
    self.scroll:Clear()
    local heroInfo=getProxy("HeroProxy")

    for k, v in pairs(heroInfo.heros) do
        if not self.selId then
            self.selId = v:getId()
        end
        local btn=ccui.Button:create("imgs/btn_1_m.png","imgs/btn_1_m.png")
        btn:setTitleText(v.name)
        btn.id = v:getId()
        btn:addTouchEventListener(handler(self, self.ViewInfo))
        self.scroll:addItem(btn, btn.id)        
    end

    self.scroll:resetItem() 
    self.scroll:SetCurSelById(self.selId)	
end

function HeroListLayer:ViewInfo(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self.selId = sender.id      
        --self:dispatchEvent({name = HeroListLayer.HeroEquip, data = {id = sender.id}})
        self:dispatchEvent({name = HeroListLayer.heroIno, id = sender.id})
        self.scroll:SetCurSelById(sender.id)
    end
end

function HeroListLayer:DelHero(id)

    if not id then return end
    self.scroll:Remove(id)
end

function HeroListLayer:AddHero(id)
    if not id then return end
    local hero = self.controls["heroList"]:getChildByTag(id)

    if hero then
        return    
    end
    
    local heroInfo=getProxy("HeroProxy")
    local info = heroInfo.heros[id]
    local temp = heroInfo:getItemTmp(id)
    
    if not info or not temp then
        print("add error hero ,id =", id)
        return    
    end
    
    local btn=ccui.Button:create("imgs/btn_1_m.png","imgs/btn_1_m.png")
    btn:setTitleText(temp.name)
    btn.id = id
    btn:addTouchEventListener(handler(self, self.ViewInfo))
    self.scroll:addItem(btn, btn.id) 
end

return HeroListLayer