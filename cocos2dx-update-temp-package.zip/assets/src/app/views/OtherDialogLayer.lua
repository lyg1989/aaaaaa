--other

local OtherDialogLayer = class("OtherDialogLayer", BaseViewComponent)
local OtherDialogMediator = require("app.views.OtherDialogMediator")
OtherDialogLayer.RESOURCE_FILENAME = "res/layerWJ.csb"     --other����Դcsb·��

--��csb���ڵĵ���ص�
OtherDialogLayer.RESOURCE_BINDING = {
    closeBtn = {"addTouchEventListener", "onClose"},              --close��ť
    outputBtn = {"addTouchEventListener", "onOutput"},            --output��ť
    slider = {"addTouchEventListener", "onSlider"},                    --������
    checkbox = {"addTouchEventListener", "onCheckbox"},        --��ѡ��
    listview = {"addTouchEventListener", "onListview"},        --��������
}
 



--��ʼ��
function OtherDialogLayer:onDataInit()
    self:onLoadCSB()
    self:initTouch()
end



function OtherDialogLayer:onEnter()
end



--���Ӹ�csb���󶨵��
function OtherDialogLayer:onLoadCSB()
    local res = self.RESOURCE_FILENAME
    if res then
        self:createResoueceNode(res)
    end
    
    local binding = self.RESOURCE_BINDING
    if res and binding then
        self:seekNodeByName(self.resourceNode_, binding, self.controls)
        self:createResoueceBinding(binding)
    end

end



--���Ӵ�����Ӧ
function OtherDialogLayer:initTouch()
    local function onEventTouchBegan(touch, event)
		return true
	end
	local function onEventTouchMoved(touch, event)
	end
	local function onEventTouchEnded(touch, event)
    end
	local listener = cc.EventListenerTouchOneByOne:create()
	listener:setSwallowTouches(true)
    listener:registerScriptHandler(onEventTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onEventTouchMoved, cc.Handler.EVENT_TOUCH_MOVED)
    listener:registerScriptHandler(onEventTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
    cc.Director:getInstance():getEventDispatcher():addEventListenerWithSceneGraphPriority(listener, self.resourceNode_)
end





--�رոý���
function OtherDialogLayer:onClose(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent({name = BaseViewComponent.ON_CLOSE})
    end
end


--���output
function OtherDialogLayer:onOutput(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent({name = OtherDialogMediator:GetMsg('MAINSCENE_OTHER_PRINT_OUTPUT')})
    end
end




function OtherDialogLayer:onSlider(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent(
            {
                name = 'MAINSCENE_OTHER_SLIDER',
                data = {
                    percent = sender:getPercent(),    --����ǰslider�İٷֱ�
                    bar = self.resourceNode_:getChildByName("barBg"):getChildByName("bar")   --��Ҫ�޸İٷֱȵĽ�����
                }
            }
        )
    end
end


function OtherDialogLayer:onCheckbox(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent(
            {
                name = 'MAINSCENE_OTHER_CHECKBOX',
                data = {
                    isTrue = sender:isSelected()  --���Ƿ�ѡ�е�boolֵ
                }
            }
        )
    end
end


function OtherDialogLayer:onListview(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent({name = OtherDialogMediator:GetMsg('MAINSCENE_OTHER_LISTVIEW')})
    end
end




return OtherDialogLayer