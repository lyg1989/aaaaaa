
local GMMediator = class('GMMediator', Mediator)


function GMMediator:listNotificationInterests()
    return {
        GAME.GM_OPCODE,     
    }
end



function GMMediator:handleNotification(note)
    local name = note:getName()
    local data = note:getBody()
    local type = note:getType()    

    local  str = data.str

    if str =="" or str == "Input" then
        return    
    end
    local attr= string.split(str," ")

    if attr[2] == "hero" then
        local  heroinfo = getCSVField("heros")
        local HerosProxy=getProxy("HerosProxy")
        local id = tonumber(attr[3])
        if heroinfo[id]== nil then
            return
        end
        
        if attr[1] == "give" then
            data = {id = id}
            HerosProxy:updateHero(data)           
        elseif attr[1] == "del" then   
            for k,v in pairs(HerosProxy.heros) do
                if v:get("id")==id then
                    HerosProxy:deleteHero(v)
                end
            end        
        end  
    end
    
    if attr[2] == "item" then
        local itemConfig = getCSVField("item")
        local ItemProxy=getProxy("ItemProxy")
        local id = tonumber(attr[3])
        local count = tonumber(attr[4])
        if itemConfig[id]== nil then
            print("no id = %d item", id)
            return
        end
        
        if attr[1] == "give" then
            ItemProxy:onAddItem(id, count)
        elseif attr[1] == "del" then   
            ItemProxy:onDelItem(id, count)       
        end  
    end    
    
    game:sendNotification(GAME.SAVE_USER_DATA, {})     
    
end

return GMMediator