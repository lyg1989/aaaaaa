local TipUI = class('TipUI', Mediator)

require("init.Help")


function TipUI:listNotificationInterests()
    self.msgs = List.new()

    self.msglayers = coroutine.create(function()
        -- restore context tree
        while true do
            if List.getSize(self.msgs)<= 0 then
                coroutine.yield()
            else

                local msg = List.popfirst(self.msgs)                
                self:showMsg(msg)                               
            end
        end

    end)    

    return {
        GAME.SHOW_TIP
    }
end

function TipUI:handleNotification(note)
    print("TipUI:handleNotification")
    local name = note:getName()
    local data = note:getBody()
    local type = note:getType()
    local msg = {content = data.msg}
    dump(msg)
    List.pushlast(self.msgs, msg)
    coroutine.resume(self.msglayers)    
end

function TipUI:showMsg(msg)
    print("TipUI:showMsg.................")   
    if not msg or not msg.content then
        return
    end
    
   -- local ttfconfig = {outlineSize=7,fontSize=50,fontFilePath="fonts/britanic bold.ttf"}
    local blood = cc.Label:createWithSystemFont(msg.content, "arial", 24)
    blood:enableOutline(cc.c4b(0,0,0,255))
    --blood:setScale(0.1)
   blood:setGlobalZOrder(1000)
   blood:setPosition(display.cx, display.cy)
   

    local targetScale = 0.6
    local tm = 1
    local pointZ = 50

    local function getAction()
        local sequence = cc.Sequence:create(
            cc.FadeOut:create(tm/2),
            cc.RemoveSelf:create())
        local spawn = cc.Spawn:create(sequence,
            cc.MoveBy:create(tm,{x=0,y=50})
            --cc.RotateBy:create(tm,math.random(-40,40))
            )
        return spawn
    end

    blood:runAction(getAction())
    print("TipUI:showMsg.................1")      
    local contextProxy = game:retrieveProxy("ContextProxy")
    local currentContext = contextProxy:getCurrentContext()
   -- currentContext.viewComponent:addChild(blood, 10000)
   
    local parentMediator = game:retrieveMediator(currentContext.mediatorClass.__cname)  
    parentMediator.viewComponent:addChild(blood, 10000)     
    print("TipUI:showMsg.................2")   
end

return TipUI