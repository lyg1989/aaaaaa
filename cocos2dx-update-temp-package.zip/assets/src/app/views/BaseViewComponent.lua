BaseViewComponent = class("BaseViewComponent", cc.Node)

-- 用于场景切换的事件
BaseViewComponent.LOADED = "BaseViewComponent:LOADED"
BaseViewComponent.DID_ENTER = "BaseViewComponent:DID_ENTER"
BaseViewComponent.DID_EXIT = "BaseViewComponent:DID_EXIT"

-- 返回事件
BaseViewComponent.ON_BACK = "BaseViewComponent:ON_BACK"

-- 层关闭事件
BaseViewComponent.ON_CLOSE = "BaseViewComponent:ON_CLOSE"


function BaseViewComponent:ctor()
    self:bindEventInit()
end

-- 获取 UI 名称，由子类实现
function BaseViewComponent:getUIName(szName)
    return nil
end



function BaseViewComponent:createResoueceNode(resourceFilename)
    if self.resourceNode_ then
        self.resourceNode_:removeSelf()
        self.resourceNode_ = nil
    end
       
    self.resourceNode_ = cc.CSLoader:createNode(resourceFilename)
    assert(self.resourceNode_, string.format("ViewBase:createResoueceNode() - load resouce node from file \"%s\" failed", resourceFilename))
    self.resourceNode_:setAnchorPoint(cc.p(0.5, 0.5))
    self.resourceNode_:setPosition(cc.p(display.cx, display.cy))
    self:addChild(self.resourceNode_)
end

function BaseViewComponent:createResoueceBinding(binding)
    assert(self.resourceNode_, "ViewBase:createResoueceBinding() - not load resource node")
    --    for nodeName, nodeBinding in pairs(binding) do
    --        local node = self.resourceNode_:getChildByName(nodeName)
    --        if nodeBinding.varname then
    --            self[nodeBinding.varname] = node
    --        end
    --        for _, event in ipairs(nodeBinding.events or {}) do
    --            if event.event == "touch" then
    --                node:onTouch(handler(self, self[event.method]))
    --            end
    --        end
    --    end

    for nodeName, nodeBinding in pairs(binding) do
        if self.controls[nodeName] then
            if nodeBinding[1] == "addTouchEventListener" then
                self.controls[nodeName]:addTouchEventListener(handler(self, self[nodeBinding[2]]))
            end            
        end
    end
end

function BaseViewComponent:seekResByName(szName)
    if not self.resourceNode_ then
        return
    end
    self:seekByName(self.resourceNode_, szName)
end
function BaseViewComponent:seekByName(root, szName)
--    print('BaseViewComponent:seekByName', root, szName)
    if root == nil then
        return
    end
    if root:getName() == szName then
        return root
    end
    local children = root:getChildren()
    for k, v in pairs(children) do
        local control = self:seekByName(v, szName)
        if control then
            return control
        end
    end
end

function BaseViewComponent:seekNodeByName(root, names, controls)
	if root == nil then
	   return	
	end
	
	for k, v in pairs(names) do	
--        print("widget name", root:getName())
	   if root:getName() == k then
           
	       controls[k] = root
	       break
	   end	
	end
	
	local children = root:getChildren()
	
	for k, v in pairs(children) do
	   if v then	   
            self:seekNodeByName(v, names, controls)
	   end
	
	end
	
end

function BaseViewComponent:bindEventInit()
    cc.bind(self, "event")
end

function BaseViewComponent:loadInit()
    self._isLoaded = false -- 是否加载完成
    self.controls = {}
end

-- 开始加载
function BaseViewComponent:load()
    if not self._isLoaded or not self.controls then
        self:loadInit()
    end
    -- 获取 UI 名称
    self.controls = {}
--    local res = rawget(self.class, "RESOURCE_FILENAME")
    local res = self.RESOURCE_FILENAME
    if res then
        self:createResoueceNode(res)
    end
    
--    local binding = rawget(self.class, "RESOURCE_BINDING")
    local binding = self.RESOURCE_BINDING
    if res and binding then
        self:seekNodeByName(self.resourceNode_,binding,self.controls)
        self:createResoueceBinding(binding)
    end


    self:OnUILoaded()
    self:addjustPos()
end

function BaseViewComponent:addjustPos()
    local winSzie = cc.Director:getInstance():getWinSize()
    local Panel_Top = self:seekByName(self.resourceNode_, 'Panel_Top')
    local Panel_Bottom = self:seekByName(self.resourceNode_, 'Panel_Bottom')
    local Panel_Left = self:seekByName(self.resourceNode_, 'Panel_Left')
    local Panel_Right = self:seekByName(self.resourceNode_, 'Panel_Right')
    if Panel_Top then
        Panel_Top:setScale(display.scaleX / display.scaleY)
    end
    if Panel_Bottom then
        Panel_Bottom:setScale(display.scaleX / display.scaleY)
    end
    if Panel_Left then
        Panel_Left:setScale(display.scaleX / display.scaleY)
        Panel_Left:setPositionX(Panel_Left:getPositionX() + winSzie.width / 2 * (1 - display.scaleX / display.scaleY))
        Panel_Left:setPositionY(Panel_Left:getPositionY() + winSzie.height / 2 * (1 - display.scaleX / display.scaleY))
    end
    if Panel_Right then
        Panel_Right:setScale(display.scaleX / display.scaleY)
        Panel_Right:setPositionX(Panel_Right:getPositionX() - winSzie.width / 2 * (1 - display.scaleX / display.scaleY))
        Panel_Right:setPositionY(Panel_Right:getPositionY() + winSzie.height / 2 * (1 - display.scaleX / display.scaleY))
    end
end

-- 是否加载完成
function BaseViewComponent:isLoaded()
    return self._isLoaded
end

-- UI 加载完成后被调用
-- @param go 来自 Unity3d 的 Game Object
function BaseViewComponent:OnUILoaded()

    -- 加载完成
    self._isLoaded = true

    -- 执行一些初始化工作
    self:init()

    -- 通知加载完成
    --self.event:emit(BaseViewComponent.LOADED)
    
    self:dispatchEvent({name = BaseViewComponent.LOADED})
end

-- 由子类实现的一些初始工作
function BaseViewComponent:init() end

-- 加载完成后进入场景
function BaseViewComponent:enter()

    -- 子类可以覆盖该方法，播放一段动画
    -- 然后通知完成入场
    --self.event:emit(BaseViewComponent.DID_ENTER)
    self:dispatchEvent({name = BaseViewComponent.DID_ENTER})

    -- 通知后会执行 mediator 的 onRegister

    -- 入场后执行的一些操作
    self:onEnter()
end

-- 由子类实现的入场后操作
function BaseViewComponent:onEnter() end

-- 由子类实现的出场前操作
function BaseViewComponent:onExit() end

-- 退出场景
function BaseViewComponent:exit()

    -- 执行一些退场前操作
    self:onExit()

    -- 子类可以覆盖该方法，播放一段动画
    -- 然后通知退场完成
    --self.event:emit(BaseViewComponent.DID_EXIT)
    self:dispatchEvent({name = BaseViewComponent.DID_EXIT})

    self:detach()
    
    self:removeSelf()

end

-- 添加到父结点
function BaseViewComponent:attach(parent)

    parent:addChild(self)

end

-- 从父结点删除
function BaseViewComponent:detach(parent)

    self._isLoaded = false

    -- 清空事件队列
    self:removeAllEventListeners()

end

function BaseViewComponent:getLoaderUI(szName)
    return self.controls[szName]
end

return BaseViewComponent