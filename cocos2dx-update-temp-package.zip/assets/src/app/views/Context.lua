Context = class("Context")

Context.TRANS_TYPE =
{
    ONE_BY_ONE = "ONE_BY_ONE",
    TRANSCROSS = "TRANSCROSS",
}

Context.path = {
    viewsRoot = { "app.views", "app.mapEdit" },
    modelsRoot = { "app.models", "app.mapEdit" },
}

function Context:ctor(data)

    if data and data.mediatorClass then
        self.mediatorClass = data.mediatorClass
    end

    if data and data.viewComponentClass then
        self.viewComponentClass = data.viewComponentClass
    end

    self.data = { }
    self.parent = nil
    self.children = { }
end

function Context:getContextByMediator(mediator)

    if self.mediatorClass and self.mediatorClass == mediator then
        return self
    end

    for k, v in pairs(self.children) do
        local value = v:getContextByMediator(mediator)
        if value then
            return value
        end
    end

    return nil
end


function Context:getContextByMediatorName(name)

    if self.mediatorClass and self.mediatorClass.__cname == name then
        return self
    end

    for k, v in pairs(self.children) do
        local value = v:getContextByMediatorName(name)
        if value then
            return value
        end
    end

    return nil
end

function Context:extendData(data)
    -- table.dup(self, data)
end

function Context:clearChildren()
    self.children = { }
end


function Context:pushContext(context)
    context.parent = self
    table.insert(self.children, context)
end

function Context:popContext()
    local context = self.children[#self.children]
    if context then
        context.parent = nil
        table.remove(self.children, #self.children)
    end

    return context
end

function Context:addChild(context)
    -- assert(isa(context, Context), "should be an instance of Context")
    -- assert(context.parent == nil, "context already has parent")
    --    print(" Context:addChild............", context)
    context.parent = self
    table.insert(self.children, context)
end

function Context:removeChild(context)
    -- assert(isa(context, Context), "should be an instance of Context")
    --    print(" Context:delete............", context)
    for i, v in ipairs(self.children) do
        if v == context then
            context.parent = nil
            return table.remove(self.children, i)
        end
    end

    return nil
end


function Context:createComponentClass(name)
    return self:createView(name, Context.path.viewsRoot)
end

function Context:createMediatorClass(name)
    return self:createView(name, Context.path.viewsRoot)
end

function Context:createView(name, root)
    for _, root in pairs(root) do
        local packageName = string.format("%s.%s", root, name)
        local status, view = xpcall( function()
            return require(packageName)
        end , function(msg)
            if not string.find(msg, string.format("'%s' not found:", packageName)) then
                print("load view error: ", msg)
            end
        end )
        local t = type(view)
        if status and(t == "table" or t == "userdata") then
            return view
        end
    end
    error(string.format("GameMediator:createView() - not found view \"%s\" in search paths \"%s\"",
        name, table.concat(root, ",")), 0)
end



function Context:buildContext(data, type)

    local context = Context:create()

    -- load context data
    for k, v in pairs(data) do
        context.data[k] = v
    end

    context.mediatorClass = Context:createMediatorClass(type.m)
    context.viewComponentClass = Context:createComponentClass(type.s)

    return context
end






