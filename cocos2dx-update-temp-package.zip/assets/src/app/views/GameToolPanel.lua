local GameToolPanel = class('GameToolPanel', BaseViewComponent)
local GameToolMediator = require("app.views.GameToolMediator")

GameToolPanel.RESOURCE_FILENAME  ='res/csb/layer_MainSceneUI.csb'

GameToolPanel.RESOURCE_BINDING = 
    {
        btnBack2Town = { "addTouchEventListener", "onBack2Town" },
        btnWJ = { "addTouchEventListener", "onWJ" },
        btnNZ = { "addTouchEventListener", "onNZ" },
        btnGT = { "addTouchEventListener", "onGT" },
        btnFL = { "addTouchEventListener", "onFL" },
        btnJJ = { "addTouchEventListener", "onJJ" },
        btnKJ = { "addTouchEventListener", "onKJ" },
        labPos = {}
    }


function GameToolPanel:onEnter()
     local  mapscene = game:retrieveMediator("GameMapMediator")
      mapscene:dispatchCenterPos() 
end


function GameToolPanel:SetLabPos(pos)
    local szPos = 'x='..pos.x..' ,y='..pos.y
    self.controls.labPos:setString(szPos)
end

function GameToolPanel:onBack2Town(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnBack2Town:setScale(1.05)
        self:dispatchEvent({name = GameToolMediator:GetMsg('GMS_BTN_BACK2TOWN')})
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnBack2Town:setScale(1)
    end
end
function GameToolPanel:onWJ(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnWJ:setScale(1.05)
        self:dispatchEvent({name = GameToolMediator:GetMsg('GMS_BTN_WJ')})
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnWJ:setScale(1)
    end
end
function GameToolPanel:onNZ(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnNZ:setScale(1.05)
        self:dispatchEvent({name = GameToolMediator:GetMsg('GMS_BTN_NZ')})
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnNZ:setScale(1)
    end
end
function GameToolPanel:onGT(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnGT:setScale(1.05)
        self:dispatchEvent({name = GameToolMediator:GetMsg('GMS_BTN_GT')})
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnGT:setScale(1)
    end
end
function GameToolPanel:onFL(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnFL:setScale(1.05)
        self:dispatchEvent({name = GameToolMediator:GetMsg('GMS_BTN_FL')})
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnFL:setScale(1)
    end
end
function GameToolPanel:onJJ(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnJJ:setScale(1.05)
        self:dispatchEvent({name = GameToolMediator:GetMsg('GMS_BTN_JJ')})
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnJJ:setScale(1)
    end
end
function GameToolPanel:onKJ(sender, eventType)
    if eventType == cc.EventCode.BEGAN then
        self.controls.btnKJ:setScale(1.05)
        self:dispatchEvent({name = GameToolMediator:GetMsg('GMS_BTN_KJ')})
    elseif eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self.controls.btnKJ:setScale(1)
    end
end



return GameToolPanel