local MainSceneDialogLayer = class('MainSceneDialogLayer', BaseViewComponent)

local MainSceneDialogMediator = require("app.views.MainSceneDialogMediator")
MainSceneDialogLayer.RESOURCE_FILENAME  ='res/csb/Layer_DialogCH.csb'
MainSceneDialogLayer.RESOURCE_BINDING =
{
    btnCH = { "addTouchEventListener", "onRetract"},
    btnSD = { "addTouchEventListener", "onBurning"},
    btnAttack = { "addTouchEventListener", "onAttack"},
    btnAttackCamp = { "addTouchEventListener", "onAttackCamp"},
    btnJS = { "addTouchEventListener", "onJS"},
    btnHC = { "addTouchEventListener", "onHC"},

    btnSD = { "addTouchEventListener", "onBurning"},
    btnTH = { "addTouchEventListener", "onTH"},
    btnZY = { "addTouchEventListener", "onZY"},

    rect = {}
}

function MainSceneDialogLayer:GetRect()
    local sprRect = self.controls['rect']
    if sprRect then
        local rect = sprRect:getBoundingBox()
        return sprRect , rect
    end
end


DIALOG_TYPE = {
    CH = 'CH',
    GJ = 'GJ',
    GJC = 'GJC',
    SD = 'SD',
    TH = 'TH',
    ZY = 'ZY',
    JS = 'JS'
}
function MainSceneDialogLayer:onLoadCSB(mtype)
    if mtype == DIALOG_TYPE.CH then
        self.RESOURCE_FILENAME  ='res/csb/Layer_DialogCH.csb'
    elseif mtype == DIALOG_TYPE.GJ then
        self.RESOURCE_FILENAME  ='res/csb/Layer_DialogGJ.csb'
    elseif mtype == DIALOG_TYPE.GJC then
        self.RESOURCE_FILENAME  ='res/csb/Layer_DialogGJCamp.csb'
    elseif mtype == DIALOG_TYPE.SD then
        self.RESOURCE_FILENAME  ='res/csb/Layer_DialogSD.csb'
    elseif mtype == DIALOG_TYPE.TH then
        self.RESOURCE_FILENAME  ='res/csb/Layer_DialogTH.csb'
    elseif mtype == DIALOG_TYPE.ZY then
        self.RESOURCE_FILENAME  ='res/csb/Layer_DialogZY.csb'
    elseif mtype == DIALOG_TYPE.JS then
        self.RESOURCE_FILENAME  ='res/csb/Layer_DialogJS.csb'
    end

    self.controls = {}

    local res = self.RESOURCE_FILENAME
    if res then
        self:createResoueceNode(res)
    end

    --    local binding = rawget(self.class, "RESOURCE_BINDING")
    local binding = self.RESOURCE_BINDING
    if res and binding then
        self:seekNodeByName(self.resourceNode_,binding,self.controls)
        self:createResoueceBinding(binding)
    end

    self.sprRect, self.rect = self:GetRect()
end

function MainSceneDialogLayer:ChangeImg(mtype)
    self:onLoadCSB(mtype)
end

function MainSceneDialogLayer:initTouch()
    if not self.sprRect or not self.rect then
        return
    end
    local function ontouched(event)
        local posLocal = self.sprRect:convertToNodeSpace(cc.p(event.x, event.y))
        if not cc.rectContainsPoint(self.rect, posLocal) then
            self:closeDialog()
        end
    end
    local touchLayer = cc.Layer:create()
    touchLayer:onTouch(ontouched)
    self:addChild(touchLayer, -1)
end

function MainSceneDialogLayer:closeDialog()
    self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_REMOVE')})
    self:dispatchEvent({name = BaseViewComponent.ON_CLOSE})
end

function MainSceneDialogLayer:GetRect()
    local sprRect = self:getLoaderUI('rect')
    local rect = sprRect:getBoundingBox()
    rect.x = 0
    rect.y = 0
    return sprRect, rect
end

function MainSceneDialogLayer:onDataInit(data)
    self:onLoadCSB(data.data.szType)
    self:initTouch()
end

function MainSceneDialogLayer:onEnter()

end

function MainSceneDialogLayer:onRetract(sender, eventType)--����
    if eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_CH')})
        self:closeDialog()
    end
end

function MainSceneDialogLayer:onBurning(sender, eventType)--�յ�
    if eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_SD')})
        self:closeDialog()
    end
end

function MainSceneDialogLayer:onJS(sender, eventType)
    if eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_JS')})
        self:closeDialog()
    end
end

function MainSceneDialogLayer:onAttack(sender, eventType)
    if eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_ATTACK')})
        self:closeDialog()
    end
end

function MainSceneDialogLayer:onAttack_Camp(sender, eventType)
    if eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_ATTACK_CAMP')})
        self:closeDialog()
    end
end

function MainSceneDialogLayer:onHC(sender, eventType)
    if eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_HC')})
        self:closeDialog()
    end
end

function MainSceneDialogLayer:onTH(sender, eventType)
    if eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_TH')})
        self:closeDialog()
    end
end

function MainSceneDialogLayer:onZY(sender, eventType)
    if eventType == cc.EventCode.ENDED or eventType == cc.EventCode.CANCELLED then
        self:dispatchEvent({name = MainSceneDialogMediator:GetMsg('GMS_DIALOG_ZY')})
        self:closeDialog()
    end
end

return MainSceneDialogLayer