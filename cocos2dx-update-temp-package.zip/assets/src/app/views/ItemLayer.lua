local ItemLayer = class("ItemLayer", BaseViewComponent)

local imageListBox = require("init.ImageListBox")
ItemLayer.RESOURCE_FILENAME = "ItemUI.csb"
ItemLayer.RESOURCE_BINDING = 
{
    itemList = {},
    left_1 = {},
    btnUse = {"addTouchEventListener", "onUse"},
    btnRet = {"addTouchEventListener", "onClose"},
    desc = {},                        
}
ItemLayer.ADDITEM="ItemLayer:addItem"
ItemLayer.DROP="ItemLayer:onDrop"
ItemLayer.CHARACTER="ItemLayer:onCharacter"

function ItemLayer:LoadUI()
    self:OnUILoaded()
end

function ItemLayer:onEnter()
    self:loadItem()
    self:NormalLoad()
    --cc.ScrollView:setTouchEnabled(enabled)    


end

function ItemLayer:NormalLoad()
    local size = self.controls["left_1"]:getContentSize()
    self.scroll = imageListBox:create(size)
    --self.scroll:setPosition(size.width/2, size.height/2)
    self.controls["left_1"]:addChild(self.scroll)
    self.scroll:setScrollX(true)

    
    for i = 1, 60 do
        local   text = ccui.Text:create("aaa"..i,"Arial", 15)     
        --self.controls["itemList"]:addChild(text)        
        self.scroll:addItem(text)      
    end   
    
    self.scroll:resetItem()    
    
    local function callback(event)
        print("scroll...", event.name)
    end

    self.scroll:addEventListener(function(sender, eventType)
        local event = {}
        if eventType == 0 then
            event.name = "SCROLL_TO_TOP"
        elseif eventType == 1 then
            event.name = "SCROLL_TO_BOTTOM"
        elseif eventType == 2 then
            event.name = "SCROLL_TO_LEFT"
        elseif eventType == 3 then
            event.name = "SCROLL_TO_RIGHT"
        elseif eventType == 4 then
            event.name = "SCROLLING"
        elseif eventType == 5 then
            event.name = "BOUNCE_TOP"
        elseif eventType == 6 then
            event.name = "BOUNCE_BOTTOM"
        elseif eventType == 7 then
            event.name = "BOUNCE_LEFT"
        elseif eventType == 8 then
            event.name = "BOUNCE_RIGHT"
        end
        event.target = sender
        callback(event)
    end)    
    
    
end

function ItemLayer:loadItem()
    local function srocllevent()
    	
    end
    local itemproxy = getProxy("ItemProxy")
    local items = getCSVField("item")
    dump(itemproxy.itemList)
    --self.controls["itemList"]:setContentSize(cc.size(50, 50))
     self.controls["itemList"]:setVisible(false)
    local i = 1
    for k, v in pairs(itemproxy.itemList) do
        local   text = ccui.Text:create("aaa","Arial", 15)     
        self.controls["itemList"]:addChild(text)
        text:setPosition(10,10+i*30)
--        local button = ccui.Button:create()
--       
--        button:setTouchEnabled(true)
--        button:setScale(0.2)
--        
--        button:loadTextures(itemproxy:getIconPath(10001),"","") 
--        self.controls["itemList"]:addChild(button)      
        local entryId = v:getEntryId()
        print("add item ", entryId)
        local bg = ccui.ImageView:create(itemproxy:getIconPath(entryId))
        bg:setScale(0.7)
        local num = v:getCount()
        local lbl = cc.Label:createWithSystemFont(num, "Arial", 15)   
        local strname = itemproxy:getItemName(entryId)  
        local size = bg:getContentSize()
        local lblsize = lbl:getContentSize()
        lbl:setAnchorPoint(cc.p(1, 0))
        lbl:setPosition(size.width-10,10)
        bg:addChild(lbl)
        local name = cc.Label:createWithSystemFont(strname, "Arial", 25)   
        bg:addChild(name)
        name:setPosition(size.width/2, size.height/2)
        
        self.controls["itemList"]:addChild(bg)
--        bg:setPosition(100,100+i*50)
--        i = i +1
        --cc.ScrollView:getInnerContainerSize()
        --local size = self.controls["itemList"]:getInnerContainerSize()
        
        --print("scrollview sie", size.width, size.height)
    end
    

    local function callback(event)
        print("itemList...", event.name)
    end
    
    self.controls["itemList"]:addEventListener(function(sender, eventType)
        local event = {}
        if eventType == 0 then
            event.name = "SCROLL_TO_TOP"
        elseif eventType == 1 then
            event.name = "SCROLL_TO_BOTTOM"
        elseif eventType == 2 then
            event.name = "SCROLL_TO_LEFT"
        elseif eventType == 3 then
            event.name = "SCROLL_TO_RIGHT"
        elseif eventType == 4 then
            event.name = "SCROLLING"
        elseif eventType == 5 then
            event.name = "BOUNCE_TOP"
        elseif eventType == 6 then
            event.name = "BOUNCE_BOTTOM"
        elseif eventType == 7 then
            event.name = "BOUNCE_LEFT"
        elseif eventType == 8 then
            event.name = "BOUNCE_RIGHT"
        end
        event.target = sender
        callback(event)
    end)
end


function ItemLayer:add(sender,eventType)
    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent({name = ItemLayer.ADDITEM}) 
    end   
end

function ItemLayer:onClose(sender, eventType)

    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent({name = BaseViewComponent.ON_CLOSE})  
    end   

end

function ItemLayer:onUse(sender,eventType)

end



return ItemLayer