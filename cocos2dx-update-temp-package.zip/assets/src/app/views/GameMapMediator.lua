local GameMapMediator = class("GameMapMediator", BaseMediator)

--GameMapMediator.ON_CHANGEMAP = "GameMapMediator.ON_CHANGEMAP"
--GameMapMediator.TAB_POSCHANGE = "GameMapMediator.TAB_POSCHANGE"
--GameMapMediator.OPEN_DLG = 'GameMapMediator.OPEN_DLG'

function GameMapMediator:didRegister()
    self.viewComponent:initMap(self.contextData.center)

    GameMapMediator.tbBindList = {
        ON_CHANGEMAP = {
            szMsg = 'ON_CHANGEMAP',
            func = GameMapMediator.onChangeMap
        },
        TAB_POSCHANGE = {
            szMsg = 'TAB_POSCHANGE',
            func = GameMapMediator.dispatchCenterPos
        },
        OPEN_DLG = {
            szMsg = 'OPEN_DLG',
            func = GameMapMediator.openMainSceneDlgLayer
        },
        OPEN_PANEL = {
            szMsg = 'OPEN_PANEL',
            func = GameMapMediator.openMainScenePanel
        },
    }
--
    for key, value in pairs(GameMapMediator.tbBindList) do
        self:bind(value.szMsg, function(e)
            value.func(self, e)
        end)
    end

    --self:openMainScenePanel()
end

function GameMapMediator:onChangeMap(e)
    local context = Context:buildContext({transType = Context.TRANS_TYPE.TRANSCROSS, mtype= e.mtype, id = e.id, scale = e.scale}, SCENE.MAIN)
    game:sendNotification(GAME.GO_TO_SCENE, context)
end

function GameMapMediator:openMainSceneDlgLayer(e)
    local data = e.data
    local sublayer = self:retrieveSubLayer(SCENE.MIANDLGLAYER.m)
    if not sublayer then
        local subcontext = Context:buildContext({data = data}, SCENE.MIANDLGLAYER)
        self:addSubLayers(subcontext)
    else
        game:sendNotification(GAME.MAINSCENE_DLG_LAYER_CHANGES, {info = data})
    end
end

function GameMapMediator:openMainScenePanel()
    local uiPanel = Context:buildContext({}, SCENE.TOOLPANEL)
    self:addSubLayers(uiPanel)
end

function GameMapMediator:dispatchCenterPos()    
    self:sendNotification(GAME.GET_LAB_POS, {
        pos = self.viewComponent.posCenter
    })  
end

function GameMapMediator:dispatchGoToScene()
    local context = Context:buildContext({transType = Context.TRANS_TYPE.TRANSCROSS, mtype= e.mtype, id = e.id, scale = e.scale}, SCENE.MAIN)
    game:sendNotification(GAME.GO_TO_SCENE, context)
end

function GameMapMediator:listNotificationInterests()
    return {
        GAME.GMS_BTN_BACK2TOWN,
        GAME.GMS_BTN_WJ,
        GAME.GMS_BTN_NZ,
        GAME.GMS_BTN_GT,
        GAME.GMS_BTN_FL,
        GAME.GMS_BTN_JJ,
        GAME.GMS_BTN_KJ,
        GAME.GMS_DIALOG_TH,
        GAME.GMS_DIALOG_ATTACK,
        GAME.GMS_DIALOG_ZY,
        GAME.GMS_DIALOG_CH,
        GAME.GMS_DIALOG_SD,
        GAME.GMS_DIALOG_JS,
        GAME.GMS_DIALOG_HC,
        GAME.MAP_CHANGE_GRID,
        GAME.MAP_OBJECT_MOVE,
        GAME.MAP_GRID_BURNING,
        GAME.MAINSCENE_DLG_LAYER_REMOVE,
        GAME.MAP_ARMY_MOVE,
        GAME.MAP_ROLE_REACH_DEST,
        GAME.MAP_ROLE_DEAD,
        GAME.MAP_OCCUPY,
        GAME.MAP_ENCAMP_FINISH,
    }
end

function GameMapMediator:handleNotification(note)

    local name = note:getName()
    local body = note:getBody()

    if name == GAME.GMS_BTN_BACK2TOWN then
        self.viewComponent:onBack2Town()
    elseif name == GAME.GMS_BTN_WJ then
        --self.viewComponent:onWJ()
        local sublayer = self:retrieveSubLayer(SCENE.OTHERLAYER.m)
        if not sublayer then
            local data = {
                szType = 'Other',
            }
            local subcontext = Context:buildContext({data = data}, SCENE.OTHERLAYER)
            self:addSubLayers(subcontext)
        else
            print("already open!!!!!")
        end

    elseif name == GAME.GMS_BTN_NZ then
        self.viewComponent:onNZ()
    elseif name == GAME.GMS_BTN_GT then
        self.viewComponent:onGT()
    elseif name == GAME.GMS_BTN_FL then
        self.viewComponent:onFL()
    elseif name == GAME.GMS_BTN_JJ then
        self.viewComponent:onJJ()
    elseif name == GAME.GMS_BTN_KJ then
        self.viewComponent:onKJ()
    elseif name == GAME.GMS_DIALOG_TH then
        self.viewComponent:onTH()
    elseif name == GAME.GMS_DIALOG_ATTACK then
        self.viewComponent:onAttack()
    elseif name == GAME.GMS_DIALOG_ZY then
        self.viewComponent:onZY()
    elseif name == GAME.GMS_DIALOG_CH then
        self.viewComponent:onRetract()
    elseif name == GAME.GMS_DIALOG_SD then
        self.viewComponent:onBurning()
    elseif name == GAME.GMS_DIALOG_JS then
        self.viewComponent:onJS()
    elseif name == GAME.GMS_DIALOG_HC then
        self.viewComponent:onHC()
    elseif name == GAME.MAP_CHANGE_GRID then
        self.viewComponent:drawCityLine()
    elseif name == GAME.MAP_OBJECT_MOVE then
        self.viewComponent:onRetract()
    elseif name == GAME.MAP_GRID_BURNING then
        self.viewComponent:onBurning()
    elseif name == GAME.MAINSCENE_DLG_LAYER_REMOVE then
        self.viewComponent:onMainSceneDlgRemove()
    elseif name == GAME.MAP_ARMY_MOVE then
        self.viewComponent:onMainArmyMove()
    elseif name == GAME.MAP_ROLE_REACH_DEST then
        self.viewComponent:onRoleReachDest(body.tbDest)
    elseif name == GAME.MAP_ROLE_DEAD then
        self.viewComponent:onRoleDead(body.nRoleId)
    elseif name == GAME.MAP_OCCUPY then
        self.viewComponent:onOccupy(body.tbDest)
    elseif name == GAME.MAP_ENCAMP_FINISH then
        self.viewComponent:onEncampFinish(body.tbPos)

    end
end

function GameMapMediator:GetMsg(szMsg)
    return GameMapMediator.tbBindList[szMsg].szMsg
end

return GameMapMediator