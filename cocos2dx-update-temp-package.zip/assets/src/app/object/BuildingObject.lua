local BaseObject = require('app.object.BaseObject')

local BuildingObject = class("BuildingObject", BaseObject)

local BuildingProxy = getProxy('BuildingProxy')
local MapProxy = getProxy("MapProxy")

function BuildingObject:onCreate(...)
    local tbParam = {...}

    self._roleNode = cc.Node:create()
    self:addChild(self._roleNode, 1)

    self._buildingNode = cc.Node:create()
    self:addChild(self._buildingNode, 31)

    self:setImage(self.nType)

    self:initModeUpdate()
end

function BuildingObject:initModeUpdate()
    self:idleMode()
    local function update(dt)
        self:baseUpdate(dt)
        self:stateMachineUpdate(dt)
        self:movementUpdate(dt)
    end
    self:scheduleUpdateWithPriorityLua(update, 0)
end

function BuildingObject:setImage(nType)
    local tbBuildingConfig = BuildingProxy:GetBuildingConfig()
    self.szImage = tbBuildingConfig[nType].szImg

    self.tbSprImage = display.newSprite('res/build/'..self.szImage)
    self:addChild(self.tbSprImage)
--    self:LoadSpriteFrames()
end

function BuildingObject:LoadSpriteFrames()
    self.szImageName = string.split(self.szImage, ".")[1]
    self._frameName = {}
    self._frameName['idle'] = self.szImageName..'1'
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res/plist/" .. self._frameName['idle'] .. ".plist")
end

function BuildingObject:playObjAnimation(name, loop) end

--之后改成帧动画，状态机模式
function BuildingObject:TmpPlayBuildAni(tbPos)
    self.tbSprImage:setOpacity(0)

    local sequence = cc.Sequence:create(cc.FadeIn:create(1),
        cc.CallFunc:create(function()
            game:sendNotification(GAME.MAP_ENCAMP_FINISH, {tbPos = tbPos})
        end))

    self.tbSprImage:runAction(sequence)
end

--之后改成帧动画，状态机模式
function BuildingObject:TmpPlayRebuildAni(tbPos)
    local pos = MapProxy:getCellPos(tbPos.x, tbPos.y)
    local sequence = cc.Sequence:create(cc.FadeOut:create(1),
        cc.CallFunc:create(function()
            self:setPosition(pos)
            self:TmpPlayBuildAni(tbPos)
        end))
    self.tbSprImage:runAction(sequence)
end

--之后改成帧动画，状态机模式
function BuildingObject:Destroy()
    self:removeFromParent()
end
return BuildingObject