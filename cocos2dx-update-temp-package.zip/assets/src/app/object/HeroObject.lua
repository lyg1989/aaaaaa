local HeroObject = class("HeroObject")

require("app.object.ObjectConfig")

function HeroObject:ctor(k, data)	
    self.entryId = k
    table.merge(self, data)	
end

function HeroObject:getId()
	return self.entryId
end

function HeroObject:Save(pNode)
	local node = {}
    node.isBoss = self.isBoss
	pNode[self.entryId] = node
	return true
end

function HeroObject:getName()
    local info = getCSVField("heros")   
    
    if info[self.entryId] then  
        return info[self.entryId].name    
    end
end

function HeroObject:getBattleAttr(name)   
    local heroInfo = getCSVField("heroInfo")
    local info = heroInfo[self.id][self.level]
    
    if info and info[name] then
        return info[name]
    end	
    
    return nil
end

function HeroObject:getBaseAttr(name)   
    local heroInfo = getCSVField("heros")
    local info = heroInfo[self.id]
    
    if info and info[name] then
        return info[name]
    end 
    
    return nil
end


function HeroObject:getAttrValue(name)
	if self[name] then
        return self[name]	
	end
	
	local value = self:getBaseAttr(name) 
	if value then
	   return value
	end   
    
    return self:getBattleAttr(name)
end



function HeroObject:setBoss(status)
    self.isBoss = status
end

function HeroObject:getBoss()
    return self.isBoss
end

return HeroObject