
local BaseObject = class("BaseObject", cc.Node)


function BaseObject:ctor(...)
    local tbParam = {...}
    self.nId = tbParam[1]
    self.nType = tbParam[2]

    self:onCreate(...)
end

--由子类实现
function BaseObject.onCreate(...)end

--由子类实现
function BaseObject:setImage(nType)end


--由子类实现
function BaseObject:LoadSpriteFrames()end

--由子类实现
function BaseObject:stopAllActions() end

--由子类实现
function BaseObject:runObjAction(ani) end

--由子类实现
function BaseObject:funMoveFinish() end

--由子类实现
function BaseObject:playObjAnimation(name, loop) end

--======State Machine switching functions
function BaseObject:getStateType()
    return self._statetype
end

function BaseObject:SetStateType(type)
    self._statetype = type
end

function BaseObject:GetContentSize()
    return self.contentSize and self.contentSize or cc.size(0, 0)
end

function BaseObject:stateMachineUpdate(dt)
    local state = self:getStateType()
    if state == EnumStateType.WALKING  then
        self:walkUpdate(dt)
    elseif state == EnumStateType.IDLE then
        self:idleUpdate(dt)
    elseif state == EnumStateType.ATTACKING then
        --I am attacking someone, I probably has a target
        self:attackUpdate(dt)
    elseif state == EnumStateType.DYING then
        --I am dying.. there is not much i can do right?
    end
end

function BaseObject:idleUpdate(dt)
    self:idleMode()
end

function BaseObject:walkUpdate(dt)
    self:walkMode()
end


function BaseObject:attackUpdate(dt)
    self:attackMode()
end

function BaseObject:idleMode()
    self:SetStateType(EnumStateType.IDLE)
    self:playObjAnimation("idle", true)
end
function BaseObject:walkMode()
    self:SetStateType(EnumStateType.WALKING)
    self:playObjAnimation("walk", true)
end
function BaseObject:attackMode()
    self:SetStateType(EnumStateType.ATTACKING)
    self:playObjAnimation("attack", true)
end

function BaseObject:baseUpdate(dt)

end

function BaseObject:movementUpdate(dt)

end

function BaseObject:SetVisible(bVisible)
    self:setVisible(bVisible)
end

return BaseObject