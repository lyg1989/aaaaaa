
local BaseObject = class("BaseObject", cc.Node)

local PlayerProxy = getProxy('PlayerProxy')

ACTION_TYPE = {
    stay = 1,
    move = 2,
    fight = 3,
}

OBJECT_DIR = {
    [1] = {nBeganFrame = 14, bFlipX = false},--右上
    [2] = {nBeganFrame = 7, bFlipX = false},--右
    [3] = {nBeganFrame = 0, bFlipX = false},--右下
    [-3] = {nBeganFrame = 0, bFlipX = true},--左下
    [-2] = {nBeganFrame = 7, bFlipX = true},--左
    [-1] = {nBeganFrame = 14, bFlipX = true},--左上
}

function BaseObject:ctor(parent, nId, nType)
    self.parent = parent
    self.nId = nId
    self.nActionType = 0
    self.nDirect = 1
    self:setImage(nType)
end

function BaseObject:SetDirect(nDirect)
    self.nDirect = nDirect
end

function BaseObject:setImage(nType)
    local tbPlayerConfig = PlayerProxy:GetPlayerConfig()
--    dump(tbPlayerConfig, 'tbPlayerConfig')
    self.szImage = tbPlayerConfig[nType].szImg

    self.tbSprImages = {}
    local POS_ARMY = {
        [1] = cc.p(-20, 20),
        [2] = cc.p(20, 20),
        [3] = cc.p(-20, -20),
        [4] = cc.p(20, -20),
    }
    for i = 1, 4 do
        self.tbSprImages[i] = display.newSprite('res/role/'..self.szImage)
        self.tbSprImages[i]:setPosition(POS_ARMY[i])
        self.tbSprImages[i]:setScale(0.5)
        self:addChild(self.tbSprImages[i])
    end
    local contentSize = self.tbSprImages[1]:getContentSize()
    if self.nId == 1 then
        local sprTag = display.newSprite('res/ui/icon/icon_myArmyTag.png')
        sprTag:setPosition(cc.p(0, 70))
        self:addChild(sprTag, 2)
    end
    self:LoadSpriteFrames()
end

function BaseObject:GetContentSize()
    if not self.tbSprImages[1] then
        return cc.size(0, 0)
    else
        return self.tbSprImages[1]:getContentSize()
    end
end

function BaseObject:LoadSpriteFrames()
    self.szImageName = string.split(self.szImage, ".")[1]
    self.szImageName_stay = self.szImageName..'1'
    self.szImageName_move = self.szImageName..'2'
    self.szImageName_fight = self.szImageName..'3'
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res/plist/" .. self.szImageName_stay .. ".plist")
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res/plist/" .. self.szImageName_move .. ".plist")
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res/plist/" .. self.szImageName_fight .. ".plist")
end

function BaseObject:Action_stay()
    self.nActionType = ACTION_TYPE.stay

    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:stopAllActions()
    end
    local nBeganFrame = OBJECT_DIR[self.nDirect].nBeganFrame
    local bFlipX = OBJECT_DIR[self.nDirect].bFlipX
    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:setFlippedX(bFlipX)
    end
    local frames = display.newFrames(self.szImageName_stay..'%04d.png', nBeganFrame, 7)
    local ani = display.newAnimation(frames, '0.1')
    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:playAnimationForever(ani)
    end
end

function BaseObject:Action_move()
    self.nActionType = ACTION_TYPE.move
    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:stopAllActions()
    end
    local nBeganFrame = OBJECT_DIR[self.nDirect].nBeganFrame
    local bFlipX = OBJECT_DIR[self.nDirect].bFlipX
    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:setFlippedX(bFlipX)
    end
    local frames = display.newFrames(self.szImageName_move..'%04d.png', nBeganFrame, 7)
    local ani = display.newAnimation(frames, '0.1')
    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:playAnimationForever(ani)
    end
end

function BaseObject:playAction_fight()
    self.nActionType = ACTION_TYPE.fight
    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:stopAllActions()
    end
    local nBeganFrame = OBJECT_DIR[self.nDirect].nBeganFrame
    local bFlipX = OBJECT_DIR[self.nDirect].bFlipX
    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:setFlippedX(bFlipX)
    end
    local frames = display.newFrames(self.szImageName_fight..'%04d.png', nBeganFrame, 7)
    local ani = display.newAnimation(frames, '0.1')
    for _, sprImage in ipairs(self.tbSprImages) do
        sprImage:playAnimationForever(ani)
    end
end

function BaseObject:Action_beFight(nFromDirect)
    self.nDirect = -nFromDirect
    self:playAction_fight()
    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(self.nFightTime),
        cc.CallFunc:create(function()
            self:StopFight()
            self.parent:NpcDead(self.nId)
        end)))
end

function BaseObject:Action_fight(funCallback)
    self:playAction_fight()
    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(self.nFightTime),
        cc.CallFunc:create(function()
            self:StopFight()
            if funCallback then
                funCallback()
            end
        end)))
end

function BaseObject:SetFightTime(nFightTime)
    self.nFightTime = nFightTime
end

function BaseObject:StopFight()
    self.nFightTime = 0
    self:Action_stay()
end
return BaseObject