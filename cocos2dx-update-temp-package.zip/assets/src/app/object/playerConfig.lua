--资源路径,名字,测试,测试n
--szImg_s,$szName_s,tb_t,number
playerConfig =
{
{szImg = "1.png",szName = "士兵1",tb = {[1] = 1},1},
{szImg = "1.png",szName = "士兵1",tb = {[1] = 1},2},
{szImg = "1.png",szName = "士兵2",tb = {aa = 4},3},

}