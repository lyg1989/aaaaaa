local BaseObject = require('app.object.BaseObject')
local RoleObject = class("RoleObject", BaseObject)

local PlayerProxy = getProxy('PlayerProxy')
local MapProxy = getProxy("MapProxy")

OBJECT_DIR = {
    [1] = {nBeganFrame = 14, bFlipX = false},--右上
    [2] = {nBeganFrame = 7, bFlipX = false},--右
    [3] = {nBeganFrame = 0, bFlipX = false},--右下
    [-3] = {nBeganFrame = 0, bFlipX = true},--左下
    [-2] = {nBeganFrame = 7, bFlipX = true},--左
    [-1] = {nBeganFrame = 14, bFlipX = true},--左上
}

function RoleObject:onCreate(...)
    local tbParam = {... }
    self.nDirect = tbParam[3]
    self.nActionType = 0

    self._roleNode = cc.Node:create()
    self:addChild(self._roleNode, 1)

    self._tagNode = cc.Node:create()
    self:addChild(self._tagNode, 11)

    self._effectNode = cc.Node:create()
    self:addChild(self._effectNode, 31)

    self:setImage(self.nType)

    self:initModeUpdate()
end

function RoleObject:initModeUpdate()
    self:idleMode()
    local function update(dt)
        self:baseUpdate(dt)
        self:stateMachineUpdate(dt)
        self:movementUpdate(dt)
    end
    self:scheduleUpdateWithPriorityLua(update, 0)
end

function RoleObject:setImage(nType)
    local tbPlayerConfig = PlayerProxy:GetPlayerConfig()
    self.szImage = tbPlayerConfig[nType].szImg

    local POS_ARMY = {
        [1] = cc.p(-20, 20),
        [2] = cc.p(20, 20),
        [3] = cc.p(-20, -20),
        [4] = cc.p(20, -20),
    }

    self.tbSprImages = {}
    for i = 1, 4 do
        self.tbSprImages[i] = display.newSprite('res/role/'..self.szImage)
        self.tbSprImages[i]:setPosition(POS_ARMY[i])
        self.tbSprImages[i]:setScale(0.5)
        self:addChild(self.tbSprImages[i])
    end
    self.contentSize = self.tbSprImages[1]:getContentSize()

    self:LoadSpriteFrames()
end

function RoleObject:LoadSpriteFrames()
    self.szImageName = string.split(self.szImage, ".")[1]
    self._frameName = {}
    self._frameName['idle'] = self.szImageName..'1'
    self._frameName['walk'] = self.szImageName..'2'
    self._frameName['attack'] = self.szImageName..'3'
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res/plist/" .. self._frameName['idle'] .. ".plist")
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res/plist/" .. self._frameName['walk'] .. ".plist")
    cc.SpriteFrameCache:getInstance():addSpriteFrames("res/plist/" .. self._frameName['attack'] .. ".plist")
end

function RoleObject:addTag()
    local sprTag = display.newSprite('res/ui/icon/icon_myArmyTag.png')
    sprTag:setPosition(cc.p(0, 70))
    self._tagNode:addChild(sprTag)
end

function RoleObject:stopAllActions()
    for _, sprImage in pairs(self.tbSprImages) do
        sprImage:stopAllActions()
    end
end

function RoleObject:runObjAction(ani, loop)
    for key, sprImage in pairs(self.tbSprImages) do
        if loop then
            sprImage:playAnimationForever(ani)
        else
            sprImage:playAnimationOnce(ani)
        end
    end
end

function RoleObject:playObjAnimation(name, loop)
    if self._curAnimation ~= name then
        self:stopAllActions()

        local szPreFrameName = self._frameName[name]

        local bFlipX = OBJECT_DIR[self.nDirect].bFlipX
        local nBeganFrame = OBJECT_DIR[self.nDirect].nBeganFrame
        local frames = display.newFrames(szPreFrameName..'%04d.png', nBeganFrame, 7)
        local newFrames = display.newAnimation(frames, 0.1)

        self._curAnimation = name
        self._curAnimationRunning = newFrames

        self:setFlippedX(bFlipX)
        self:runObjAction(self._curAnimationRunning, loop)
    end
end

function RoleObject:setFlippedX(bFlipX)
    for _, sprImage in pairs(self.tbSprImages) do
        sprImage:setFlippedX(bFlipX)
    end
end

--虚函数 物体移动完调用
function RoleObject:funMoveFinish()
    game:sendNotification(GAME.MAP_ARMY_MOVE, {})
    if not self.tbMoveDest then
        return
    end
    game:sendNotification(GAME.MAP_ROLE_REACH_DEST, {
        tbDest = self.tbMoveDest
    })
end

function RoleObject:Action_BeFight(nFromDirect, tbDest)
    self.nDirect = -nFromDirect
    self:attackMode()
    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(3),
        cc.CallFunc:create(function()
            self:idleMode()
            --以后该消息由服务器判断死亡，并发送
            game:sendNotification(GAME.MAP_ROLE_DEAD, {
                nRoleId = self.nId,
            })
        end)))
end

function RoleObject:Action_Fight(tbDest)
    self:attackMode()
    self:runAction(cc.Sequence:create(
        cc.DelayTime:create(3),
        cc.CallFunc:create(function()
            self:idleMode()
            game:sendNotification(GAME.MAP_OCCUPY, {
                tbDest = tbDest,
            })
        end)))
end

function RoleObject:SetDirect(nDirect)
    self.nDirect = nDirect
end

function RoleObject:Move2Dest(tbList, nReach, tbNpcPos, tbDest)
    if tbDest then
        self.tbMoveDest = tbDest
    end
    if nReach > #tbList then
        self:idleMode()
        self:funMoveFinish(tbNpcPos)
        return
    end

    self:walkMode()

    local tbNextInfo = tbList[nReach]
    local nDestNpcId = tbNpcPos[tbNextInfo.nColumn * 1000 .. tbNextInfo.nHeight]
    local posDest = MapProxy:getCellPos(tbNextInfo.nColumn, tbNextInfo.nHeight)

    local actionMove
    if nReach == #tbList and nDestNpcId then
        local posSrc = cc.p(self:getPosition())
        local posMoveBy = cc.p((posDest.x - posSrc.x) / 2,(posDest.y - posSrc.y) / 2)
        actionMove = cc.MoveBy:create(1, posMoveBy)
    else
        actionMove = cc.MoveTo:create(1, posDest)
    end
    local sequence = cc.Sequence:create(actionMove,
        cc.CallFunc:create(function()
            self:Move2Dest(tbList, nReach + 1, tbNpcPos)
        end))
    self:runAction(sequence)
    if tbNextInfo.posPre then
        self:SetDirect(tbNextInfo.posPre.nDirect)
    end
end

function RoleObject:Dead()
    self:removeFromParent()
end

return RoleObject