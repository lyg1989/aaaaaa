--
-- Created by IntelliJ IDEA.
-- User: Administrator
-- Date: 2016/9/23
-- Time: 10:42
-- To change this template use File | Settings | File Templates.
--
function Astar(posSrc, posDest, tbPrototype, tbEmptyPrototype)
    if posSrc.nColumn == posDest.nColumn and posSrc.nHeight == posDest.nHeight then
        return nil, {}
    end

    local tbOpenList = clone(tbEmptyPrototype)
    local tbCloseList = clone(tbEmptyPrototype)
    local tbUseList = clone(tbEmptyPrototype)
    local bFindDest = false

    --1.把起始点放入closelist
    local nSrcG = 0
    local nSrcH = ManhattanDistance(posDest.nColumn, posDest.nHeight, posSrc.nColumn, posSrc.nHeight)
    tbCloseList[posSrc.nColumn][posSrc.nHeight] = {
        g = nSrcG,
        h = nSrcH,
        f = nSrcG + nSrcH,
        nColumn = posSrc.nColumn,
        nHeight = posSrc.nHeight,
        posPre = nil
    }

    --2.循环，直到找到终点
    while(not bFindDest) do
        --2.1 从closelist中取F值最小的节点
        local tbMinF = Astar_FindMinF(tbCloseList, clone(tbUseList))
        if tbMinF == 'BlindAlley' then
                        print('死路！！！！')
            return false
        end

        --2.2 遍历tbMinF的周围，找出可行且不在closelist中的节点
        for _, parentNodeInfo in ipairs(tbMinF) do
            tbUseList[parentNodeInfo.nColumn][parentNodeInfo.nHeight]= true
            local nPreColumn = parentNodeInfo.nColumn
            local nPreHeight = parentNodeInfo.nHeight
            local tbPreAround = {
                {nColumn = nPreColumn + 1, nHeight = nPreHeight, nDirect = 2},--正右
                {nColumn = nPreColumn - 1, nHeight = nPreHeight, nDirect = -2},--正左
                nPreHeight %2 == 0 and {nColumn = nPreColumn - 1, nHeight = nPreHeight + 1, nDirect = -1} or {nColumn = nPreColumn, nHeight = nPreHeight - 1, nDirect = -1},--左上
                nPreHeight %2 == 0 and {nColumn = nPreColumn - 1, nHeight = nPreHeight - 1, nDirect = -3} or {nColumn = nPreColumn, nHeight = nPreHeight + 1, nDirect = -3},--左下
                nPreHeight %2 == 0 and {nColumn = nPreColumn, nHeight = nPreHeight + 1, nDirect = 1} or {nColumn = nPreColumn + 1, nHeight = nPreHeight - 1, nDirect = 1},--右上
                nPreHeight %2 == 0 and {nColumn = nPreColumn + 1, nHeight = nPreHeight - 1, nDirect = 3} or {nColumn = nPreColumn, nHeight = nPreHeight + 1, nDirect = 3},--右下
            }

            local tbReachableNode = {}
            for _, pos in ipairs(tbPreAround) do

                if tbPrototype[pos.nColumn] and tbPrototype[pos.nColumn][pos.nHeight] and
                        not tbCloseList[pos.nColumn][pos.nHeight] then
                    table.insert(tbReachableNode, {
                        nColumn = pos.nColumn,
                        nHeight = pos.nHeight,
                        g = parentNodeInfo.g + 1,
                        nDirect = pos.nDirect
                    })
                end
            end
--            dump(tbReachableNode, 'tbReachableNode')

            --2.3 依次放入openlist，若已存在，则取最小的
            for _, reachableNodeInfo in ipairs(tbReachableNode) do
                local tbOpenNode = tbOpenList[reachableNodeInfo.nColumn][reachableNodeInfo.nHeight]

                if tbOpenNode then
                    if reachableNodeInfo.g < tbOpenNode.g then
                        tbOpenNode.g = reachableNodeInfo.g
                        tbOpenNode.posPre = {
                            nColumn = parentNodeInfo.nColumn,
                            nHeight = parentNodeInfo.nHeight,
                            nDirect = reachableNodeInfo.nDirect
                        }
                    end
                else
                    tbOpenList[reachableNodeInfo.nColumn][reachableNodeInfo.nHeight] = {
                        g = parentNodeInfo.g + 1,
                        nColumn = reachableNodeInfo.nColumn,
                        nHeight = reachableNodeInfo.nHeight,
                        posPre = {
                            nColumn = parentNodeInfo.nColumn,
                            nHeight = parentNodeInfo.nHeight,
                            nDirect = reachableNodeInfo.nDirect
                        },
                    }
                end
            end
        end

        --2.4 把openlist中的节点导入closelist，并计算出h值和f值
--        dump(tbOpenList, 'tbOpenList')
        for nColumn, tbAA in pairs(tbOpenList) do
            for nHeight, openNodeInfo in pairs(tbAA) do
                --                print('到达', openNodeInfo.nColumn, openNodeInfo.nHeight)
                local nOpenH = ManhattanDistance(posDest.nColumn, posDest.nHeight, nColumn, nHeight)
                tbCloseList[nColumn][nHeight] = {
                    g = openNodeInfo.g,
                    h = nOpenH,
                    f = openNodeInfo.g + nOpenH,
                    nColumn = openNodeInfo.nColumn,
                    nHeight = openNodeInfo.nHeight,
                    posPre = clone(openNodeInfo.posPre),
                }
                if nOpenH == 0 then
                    bFindDest = true
                    --                    print('找到了！！！')
                    break
                end
            end
            if bFindDest then
                break
            end
        end

        --2.5 如果还没找到终点，置空openlist开始下一轮
        tbOpenList = clone(tbEmptyPrototype)

        if bFindDest then
            break
        end
    end

    --回溯线路
    local bBack2Src = false
    local nStep = 0
    local tbCheckNode = clone(tbCloseList[posDest.nColumn][posDest.nHeight])
    local tbList = {}
    while(not bBack2Src) do
        --        print('到达节点',tbCheckNode.nColumn, tbCheckNode.nHeight)

        if tbCheckNode.nColumn == posSrc.nColumn and tbCheckNode.nHeight == posSrc.nHeight then
            --            print('已回溯！！')
            bBack2Src = true
        else
            nStep = nStep + 1
            local tbNewCheckNode = clone(tbCloseList[tbCheckNode.posPre.nColumn][tbCheckNode.posPre.nHeight])
            tbCheckNode = clone(tbNewCheckNode)
            table.insert(tbList, 1, tbNewCheckNode)
        end
    end
    table.insert(tbList, posDest)
    table.remove(tbList, 1)
--    dump(tbList, 'tbList')

    return nStep, tbList
end

function ManhattanDistance(x1, y1, x2, y2)
    return math.abs(x1 - x2) + math.abs(y1 - y2)
end

function GetDis(posSrc, posDest)
    return math.sqrt(math.pow(math.abs(posDest.x - posSrc.x), 2) + math.pow(math.abs(posDest.y - posSrc.y), 2))
end

function Astar_FindMinF(tbCloseList, tbUseList)
    local tbMinF = {}
    local nMinF = 1000000

    for nColumn, tbAA in pairs(tbCloseList) do
        for nHeight, nodeInfo in pairs(tbAA) do
            if not tbUseList[nColumn][nHeight] and nodeInfo.f < nMinF then
                tbMinF = {}
                table.insert(tbMinF, nodeInfo)
                nMinF = nodeInfo.f
            elseif nodeInfo.f == nMinF then
                table.insert(tbMinF, nodeInfo)
            end
        end
    end

    return TbLong(tbMinF) == 0 and 'BlindAlley' or tbMinF
end

function TbLong(tb)
    local nLong = 0
    for _, _ in pairs(tb) do
        nLong = nLong + 1
    end
    return nLong
end

function GetWordRotation(posSrc, posDest)
    local nRotation = math.deg(math.atan((posDest.y - posSrc.y) / (posDest.x - posSrc.x)))
    return nRotation
end

function CreateEnumTable(tbl, index)
    local enumTable = {}
    local enumIndex = index or -1
    for i, v in ipairs(tbl) do
        print('v, enumIndex + i', v, enumIndex + i)
        enumTable[v] = enumIndex + i
    end
    return enumTable
end