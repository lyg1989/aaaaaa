local LoadMapData = class('LoadMapData', SimpleCommand)

require("src.init.tablesave")

function LoadMapData:execute(note)
    local data = note:getBody()

    --jia zai youxi  shuju
    
    
    -- local   str = cc.UserDefault:getInstance():getStringForKey("user")
    -- print(str)
    -- local info = {}
    
    -- if str == "" or string.len(str) == 0 then
    --     info = {}
    -- else
    --     info = table.load(str)
    -- end

    
    -- local proxy = HeroProxy:create(HeroProxy.__cname, info.HeroProxy or {})       
    -- game:registerProxy(proxy)
    -- proxy = PlayerProxy:create(PlayerProxy.__cname, info.PlayerProxy or {})       
    -- game:registerProxy(proxy)    
    -- proxy = ItemProxy:create(ItemProxy.__cname, info.ItemProxy or {})       
    -- game:registerProxy(proxy)       
  
     local context = Context:buildContext({transType = Context.TRANS_TYPE.ONE_BY_ONE}, SCENE.MAPEDIT)


    
  
    game:sendNotification(GAME.GO_TO_SCENE, context)         
end

return LoadMapData