local thirdMap = class("thirdMap", cc.Layer)
local selSprite = require("app.mapEdit.selSprite")

function thirdMap:ctor()

 local pColorLayer = cc.LayerColor:create(cc.c4b(255, 255, 255, 255 * .75), 800, 800)
        pColorLayer:setPosition(cc.p(100, 100))
        self:addChild(pColorLayer)
        

--local pColorLayer1 = cc.LayerColor:create(cc.c4b(255, 255, 255, 200), 800, 800)
local pColorLayer1 = cc.Layer:create()
        pColorLayer1:setPosition(cc.p(100, 100))
        self:addChild(pColorLayer1)

--        local bg = cc.Sprite:create("res/map/logo.png")
--        pColorLayer1:addChild(bg)
--        bg:setPosition(0, 0)

        local map = ccexp.TMXTiledMap:create("res/map/a.tmx")
        pColorLayer1:addChild(map)
        map:setPosition(0, 0)
        local map1 = ccexp.TMXTiledMap:create("res/map/a.tmx")
        pColorLayer1:addChild(map1)
        map1:setPosition(300, 0)


        pColorLayer1:ignoreAnchorPointForPosition(false)
         pColorLayer1:setAnchorPoint(cc.p(0, 0))
        pColorLayer1:setScale(0.5)

       -- print("layer content size.................", pColorLayer1:getContentSize().width, pColorLayer1:getContentSize().height)
                print("layer content size.................", pColorLayer1:getAnchorPoint().x, pColorLayer1:getAnchorPoint().y)
        
--       cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/map" .. 1 .. ".plist")

--        local effectSprite = EffectSprite:createWithFile("res/map/logo_normal.png")
--        effectSprite:setPosition(cc.p(display.cx-300, display.cy))
--        self:addChild(effectSprite)

end



function thirdMap:enableTouch()

end


return thirdMap
