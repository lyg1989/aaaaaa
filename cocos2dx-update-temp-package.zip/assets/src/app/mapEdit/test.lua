local thirdMap = class("thirdMap", cc.Layer)
local selSprite = require("app.mapEdit.selSprite")

function thirdMap:ctor()

        self.map = ccexp.TMXTiledMap:create("res/map/2.tmx")
        self:addChild(self.map, 1, 101)
        --self.map:setScale(0.3)

       -- self.map = ccexp.TMXTiledMap:create("Art/hexa-test.tmx")
       -- self:addChild(self.map, 1, 101)

        --self.map:setScale(0.2)

        local s = self.map:getContentSize()
--        print("ContentSize: %f, %f", s.width, s.height)
        -- self.map:setAnchorPoint(cc.p(300, 300))

        self.map:setPosition(0, 0)
        self:enableTouch()

        local map1 = ccexp.TMXTiledMap:create("res/map/2.tmx")
        print(s.width.."......................")

        --cell.width/2/sqrt(3)*(geshu*3/2+ (ruguo shi jishuge  +2 fouze +1)  -1)
        map1:setPosition((75*6)*math.sqrt(3),0)
        self:addChild(map1)


        local map1 = ccexp.TMXTiledMap:create("res/map/2.tmx")
        print(s.width.."......................")

        --cell.width/2/sqrt(3)*(geshu*3/2+ (ruguo shi jishuge  +2 fouze +1)  -1)
        map1:setPosition(0,150*5)
        self:addChild(map1)

        self:setScale(0.5)
       

--    self:enableTouch()


--        local  layer0 = self.map:getLayer("Layer 0")
--        local s = layer0:getLayerSize()
--        print("tile map size", s.width, s.height)
--        local  sprite = layer0:getTileAt(cc.p(s.width-1,0))
--        layer0:removeChild(sprite, true)
--        local  sprite2 = layer0:getTileAt(cc.p(s.width-1, s.height - 1))
--        local  sprite3 = layer0:getTileAt(cc.p(2, s.height - 1))
--        layer0:removeChild(sprite3, true)
--        layer0:removeChild(sprite2, true)


--    local  layer0 = self.map:getLayer("Layer 0")
--    local s = layer0:getLayerSize()
--    print("tile map size", s.width, s.height)
--    local  sprite = layer0:getTileAt(cc.p(s.width-1,0))

--    local draw = cc.DrawNode:create()
--    layer0:addChild(draw, 10000)
--    draw:drawCircle(cc.p(sprite:getPositionX()+86, sprite:getPositionY()+75), 75, math.pi/2, 30, false, cc.c4f(math.random(0.5,1), math.random(0.7,1), math.random(0.8,1), 1))

--    local size = cc.size(960, 640)

--    draw:drawQuadBezier(cc.p(size.width - 150, size.height - 150), cc.p(size.width - 70, size.height - 10), cc.p(size.width - 10, size.height - 10), 10, cc.c4f(math.random(0,1), math.random(0,1), math.random(0,1), 0.5))

--    local array = {
--            cc.p(0, 0),
--            cc.p(size.width / 2 - 30, 0),
--            cc.p(size.width / 2 - 30, size.height - 80),
--            cc.p(0, size.height - 80),
--            cc.p(0, 0) }
--    draw:drawCardinalSpline(array, 0.5, 50, cc.c4f(math.random(0,1), math.random(0,1), math.random(0,1), 0.5))
end



function thirdMap:enableTouch()

    local function onTouchBegan(touch, event)
        local BeginPos = touch:getLocation()


        return true
    end

    local function onTouchEnded(touch, event)
        local location = touch:getLocation()

        if self.spt:hitTest(location) then
            print(".............................touched")

                local c = EffectStroke:create()
                 c:setInfo(cc.c3b(120, 100, 100), 5)
                 self.spt:setEffect(c)
        else
            local e = EffectNormal:create()
           -- c:setInfo(cc.c3b(120, 100, 100), 5)
            self.spt:setEffect(e)            
        end

    end

    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
end


return thirdMap
