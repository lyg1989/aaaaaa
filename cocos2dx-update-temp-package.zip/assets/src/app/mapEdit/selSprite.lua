local selSprite = class("selSprite", cc.Node)

function selSprite:ctor()
     self.target = nil
     local function onNodeEvent(event)
        if event == "exit" then
            self.target:release()
            cc.Director:getInstance():getTextureCache():removeUnusedTextures()
        end
    end

    self:registerScriptHandler(onNodeEvent)

    -- create a render texture, this is what we are going to draw into
    self.target = cc.RenderTexture:create(display.width, display.height, cc.TEXTURE2_D_PIXEL_FORMAT_RGB_A8888)
    self.target:retain()

end

function selSprite:onSelect1(a, b)
    local params = {a, b}
    local size   = #params
    if size >= 1 then
        self.target:beginWithClear(1, 0, 0, 1)
        self.target:begin()
        for i = 1, size do
            params[i]:visit()
        end
        self.target:endToLua()
    end

   -- local sprite = cc.Sprite:createWithTexture(self.target:getSprite():getTexture())
   --self:addChild(sprite)


end



return selSprite

