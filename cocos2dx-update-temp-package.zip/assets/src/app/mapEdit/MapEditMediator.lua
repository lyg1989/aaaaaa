local  MapEditMediator = class("MapEditMediator", BaseMediator)
local MainScene = require("app.views.MainScene")

function MapEditMediator:didRegister()

--    self:bind(MainScene.ITEAM, handler(self, self.onIteam))
--    self:bind(MainScene.MAP , handler(self,self.onMap))
--    self:bind(MainScene.CHARACHTER, handler(self, self.CHARACHTER))
--    self:bind(MainScene.ONADD, handler(self, self.onAdd))
--    self:bind(MainScene.PLAYER, handler(self, self.onPlayers))
end

--function MapEditMediator:onAdd()
--    local str=self.viewComponent.controls["text_Instruction"]:getString()
--    game:sendNotification(GAME.GM_OPCODE, {str = str})

--end



--function MapEditMediator:onBattle()

--end

--function MapEditMediator:CHARACHTER()
--    print("MapEditMediator:CHARACHTER") 
--    local context = Context:buildContext({}, SCENE.BUTTON)
--    local subcontext = Context:buildContext({},SCENE.HEROLIST)
--    context:pushContext(subcontext)
--    local context1 = Context:buildContext({}, SCENE.CHARACTER)
--    subcontext:pushContext(context1)

--    self:addSubLayers(context)
--end

--function MapEditMediator:onIteam()

--    local context = Context:buildContext({}, SCENE.BUTTON)
--    local subcontext = Context:buildContext({},SCENE.ITEM)
--    context:pushContext(subcontext)
--    self:addSubLayers(context)
--end

--function MapEditMediator:onPlayers()

--    local context = Context:buildContext({}, SCENE.PLAYER)
--    self:addSubLayers(context)
--end

--function MapEditMediator:onMap(parameters)
--    local context = Context:buildContext({transType = Context.TRANS_TYPE.ONE_BY_ONE}, SCENE.LEVELSCENE)
--    local subcontext = Context:buildContext({},SCENE.PLAYER)
--    context:pushContext(subcontext)
--    game:sendNotification(GAME.GO_TO_SCENE,context)
--end

function MapEditMediator:listNotificationInterests()
    return {
        GAME.PLAYER_UPGRADE
    }
end

function MapEditMediator:handleNotification(note)
    local name = note:getName()
    local data = note:getBody()

    if name == GAME.PLAYER_UPGRADE then
        self.viewComponent:updateLevel(data.level)
    end  
end

--function MapEditMediator:onAdd()
--    local flag=false
--    local str=self.viewComponent.controls["text_Instruction"]:getString()    
--    --dump(arr)
--    print(".............enter string",str)    
--    game:sendNotification(GAME.GM_OPCODE, {str = str})
--end

return MapEditMediator