local MapEditScene = class("MapEditScene", BaseViewComponent)

MapEditScene.RESOURCE_FILENAME = "res/csb/Scene.csb"

local thirdMap = require("app.mapEdit.thirdMap")
local firstMap = require("app.mapEdit.firstMap")
local thirdMap = require("app.mapEdit.thirdMap")
local secondMap = require("app.mapEdit.secondMap")

local map =1

MapEditScene.RESOURCE_BINDING =
{
    --        hero_btn = {"addTouchEventListener", "onHero"},
    --        item_btn = {"addTouchEventListener", "onItem"},
    --        add_btn = {"addTouchEventListener", "onAdd"},
    --        store_btn = {"addTouchEventListener", "onStore"},
    --        map_btn = {"addTouchEventListener", "onMap"},
    --        player_btn = {"addTouchEventListener", "onPlayer"},
    --        skill_btn = {"addTouchEventListener", "onSkill"},
    --        battle_btn = {"addTouchEventListener", "onBattle"},
    --        text_Instruction = {},

    imgView = { },
    xPos = { },
    yPos = { },
    idName = { },
    proAttr = { },
    shuru = { },
    bigBtn = { "addTouchEventListener", "onBig" },
    smallBtn = { "addTouchEventListener", "onSmall" },
    delBtn = { "addTouchEventListener", "onDel" },
    saveBtn = { "addTouchEventListener", "onSave" },
    editBtn = { "addTouchEventListener", "onEdit" },
    btn_DrawPoint = {"addTouchEventListener", "onDrawPoint" },
    btn_DrawPointClear = {"addTouchEventListener", "onDrawPointClear" },
    btn_Neighbor = {"addTouchEventListener", "onNeighbor" },
    btn_NeighborClear = {"addTouchEventListener", "onNeighborClear" },
    background = {},
}

-- MapEditScene.CHARACHTER="MapEditScene:CHARACHTER"
-- MapEditScene.ITEAM = "MapEditScene:onIteam"
-- MapEditScene.ONADD = "MapEditScene:onAdd"
-- MapEditScene.PLAYER = "MapEditScene:onPlayer"
-- MapEditScene.MAP = "MapEditScene:onMap"

function MapEditScene:onDel(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self.map.map:del()
    end
end

function MapEditScene:onSave(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self.map.map:save()
    end
end

function MapEditScene:onEdit(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self.map.map:hecheng()
    end
end

function MapEditScene:onDrawPoint(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self.map.map:SwitchDrawDot()
    end
end

function MapEditScene:onDrawPointClear(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self.map.map:ClearDrawDot()
    end
end

function MapEditScene:onNeighbor(sender, eventType)
    if eventType == cc.EventCode.ENDED then

    end
end

function MapEditScene:onNeighborClear(sender, eventType)
    if eventType == cc.EventCode.ENDED then

    end
end

function MapEditScene:onAdd(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        self:dispatchEvent( { name = MapEditScene.ONADD })
    end
end

function MapEditScene:onBig(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        if self.scale < 10 then
            self.scale = self.scale + 1
            -- self.controls["innerMap"]:    setScale(self.scale)
            self.map.map:touchScaleEnd(self.scale)

        end
    end
end


function MapEditScene:onSmall(sender, eventType)
    if eventType == cc.EventCode.ENDED then
        --if self.scale >= 2 then
            --self.scale = self.scale - 1

            -- self.controls["innerMap"]:setScale(self.scale)
            --self.controls["mapView"]:setZoomScaleInDuration(self.scale, 0.5)

            --if self.scale < 5 then
                self.map.map:touchScaleEnd(0.5)
            --end
        --end
    end
end




function MapEditScene:init()
--    print('MapEditScene:init--------------------')
    local scene = cc.Scene:create()
    local winSzie = cc.Director:getInstance():getWinSize()
    scene:addChild(self, 0)
    display.runScene(scene)

    if map == 1 then
        -- self:CreateMapScroll()
        self.controls["shuru"]:setPosition(0, display.height-30)
        self.map = firstMap:create(self.controls, self, MapType.FirstLayer)
        self.scale = 1

    elseif map == 3 then
        self.map = thirdMap:create(self.controls)
        -- self.map = secondMap:create()
        self:addChild(self.map)
    else
        self.map = require("app.mapEdit.test"):create()
        self:addChild(self.map)
    end

    local test = display.newSprite('res/ui/icon/icon_head01.png')
    test:setPosition(cc.p(500, 500))
    self:addChild(test, 200)
end

function MapEditScene:enableTouch()

end


function MapEditScene:updateLevel()

end



function MapEditScene:onEnter()

end

function MapEditScene:onExit()

end



return MapEditScene
