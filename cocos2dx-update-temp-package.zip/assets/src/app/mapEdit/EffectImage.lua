local EffectImage = class("EffectImage", function(res, pos, par)
    local effectSprite = EffectSprite:create(res)
    effectSprite:setPosition(pos)
    -- effectSprite:setScale(0.2)
    return effectSprite
end )

function EffectImage:ctor(res, pos, par, info, id)
    --print('EffectImage:ctor' )

    self.res = res
    self.id = id
    self.par = par
    self.info = info
    if CC_EDIT_MAP then
       -- self:enableEffectTouch()
    end

    local c = EffectStroke:create()
    c:setInfo(cc.c3b(120, 100, 100), 2)
    self:addEffect(c, 10)
    self.c = c

    --是否在描点

    self.bDrawingDot = false
    self.tbNamePoint = {}--描5个点
    self.tbNamePoint_real = {}--实际名字所在点
    self.tbName = {'拜', '占', '庭', '帝', '国'}

    if info.tbNamePoint then
        self.tbNamePoint = info.tbNamePoint
    end

    self:initDrawNode()
    self.drawNode:setVisible(false)
    --
    self:initDrawNameInfo()
end

function EffectImage:SwitchDrawDot()
    self.bDrawingDot = not self.bDrawingDot
    self.drawNode:setVisible(self.bDrawingDot)
end

function EffectImage:initDrawNode()
    self.drawNode = cc.DrawNode:create()
    self:addChild(self.drawNode, 5)
end

function EffectImage:initDrawNameInfo()
    self:initDrawNamePoint()
    self:calculateDrawNamePointReal()
    self:drawName()
end

function EffectImage:initDrawNamePoint()
    for _, pos in ipairs(self.tbNamePoint) do
        self.drawNode:drawDot(pos, 10, cc.c4f(1.0, 0, 0, 1.0));
    end
end

function EffectImage:calculateDrawNamePointReal()
    if #self.tbNamePoint ~= 5 then
        return
    end
    if #self.tbName == 1 then
        self.tbNamePoint_real[1] = self.tbNamePoint[3]
    elseif #self.tbName == 2 then
        self.tbNamePoint_real[1] = self.tbNamePoint[2]
        self.tbNamePoint_real[2] = self.tbNamePoint[4]
    elseif #self.tbName == 3 then
        self.tbNamePoint_real[1] = self.tbNamePoint[1]
        self.tbNamePoint_real[2] = self.tbNamePoint[3]
        self.tbNamePoint_real[3] = self.tbNamePoint[5]
    elseif #self.tbName == 4 then
        for i = 1, 4 do
            self.tbNamePoint_real[i] = cc.p((self.tbNamePoint[i].x + self.tbNamePoint[i + 1].x) / 2,
                (self.tbNamePoint[i].y + self.tbNamePoint[i + 1].y) / 2)
        end
    elseif #self.tbName == 5 then
        for i = 1, 5 do
            self.tbNamePoint_real[i] = self.tbNamePoint[i]
        end
    end
end

function EffectImage:drawName()
    self.layerName = display.newLayer()
    self:addChild(self.layerName, 10)

--    dump(self.tbNamePoint_real, 'self.tbNamePoint_real')
    local nRotation = 0
    for nIndex, pos in ipairs(self.tbNamePoint_real) do
        local szWord = self.tbName[nIndex]
        local labWord = cc.Label:createWithSystemFont(szWord, "Arial", 50)
        labWord:setColor(cc.c3b(150, 150, 150))
        labWord:setPosition(pos)


        local posNext = self.tbNamePoint_real[nIndex + 1]
        if posNext then
            nRotation = GetWordRotation(pos, posNext)
            nRotation = -nRotation
        end
        labWord:setRotation(nRotation)
        self.layerName:addChild(labWord)
    end
end

function EffectImage:ClearDrawDot()
    self.drawNode:removeFromParent()
    self.drawNode = nil
    self.tbNamePoint = {}
    self.tbNamePoint_real = {}
end

function EffectImage:onTouched(touch)
    local location = touch:getLocation()
    local endPos = self:convertToNodeSpace(touch:getLocation())
    -- print("effectimage touch x, y", endPos.x, endPos.y, self:getPositionX(), self:getPositionY(), location.x, location.y)
    if self:hitTest(location) then
        self.par:setSelectImg(self.id)
        print('self.id',self.id)
        if self.bDrawingDot and #self.tbNamePoint < 5 then
            self.tbNamePoint[#self.tbNamePoint + 1] = endPos
            if not self.drawNode then
                self:initDrawNode()
            end
            self.drawNode:drawDot(endPos, 10, cc.c4f(1.0, 0, 0, 1.0));
        end
    end
end

function EffectImage:enableEffectTouch()
    -- handling touch events
    local function onTouchBegan(touch, event)
        local BeginPos = touch:getLocation()
        local endPos = event:getCurrentTarget():convertToNodeSpace(touch:getLocation())


        if self.par.par.selId then
            return false
        end
        return true
    end

    local function onTouchEnded(touch, event)
        local location = touch:getLocation()
        local endPos = event:getCurrentTarget():convertToNodeSpace(touch:getLocation())
        print("effectimage touch x, y", endPos.x, endPos.y, self:getPositionX(), self:getPositionY(), location.x, location.y)
        if self:hitTest(location) then
            self.par:setSelectImg(self.id)
        end
    end

    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self.par:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
end

function EffectImage:setNomalRender()
    local e = EffectNormal:create()
    -- c:setInfo(cc.c3b(120, 100, 100), 5)
    self:setEffect(e)       
    if self.b then
        self:delEffect(self.b)
    end

    if self.c then
        self:delEffect(self.c)
    end
end


function EffectImage:setSelectStatus(status)
    if status then

--        local c = EffectStroke:create()
--        c:setInfo(cc.c3b(120, 100, 100), 6)
--        self:setEffect(c)
        self.c:setInfo(cc.c3b(10, 10, 100), 2)
        local blur = EffectHue:create()
        blur:setHSL(200, 0, 0)
        self:addEffect(blur, 100)
        self.b = blur
        --self:setLocalZorder(1000)
    else

        local e = EffectNormal:create()
        -- c:setInfo(cc.c3b(120, 100, 100), 5)
        self:setEffect(e)
        
        self:delEffect(self.b)
        self.c:setInfo(cc.c3b(120, 100, 100), 2)
    end


end

function EffectImage:onKeyPress(keyCode)


    if keyCode == cc.KeyCode.KEY_UP_ARROW then
        self:setPositionY(self:getPositionY() + 1)
    elseif keyCode == cc.KeyCode.KEY_DOWN_ARROW then
        self:setPositionY(self:getPositionY() -1)
    elseif keyCode == cc.KeyCode.KEY_LEFT_ARROW then
        self:setPositionX(self:getPositionX() -1)
    elseif keyCode == cc.KeyCode.KEY_RIGHT_ARROW then
        self:setPositionX(self:getPositionX() + 1)
    end

    self.par.par:updateShowInfo(self)
end

--装载该图块的保存信息
function EffectImage:save(parNode)

    node = { }
    node.id = self.id
    node.pos = cc.p(self:getPositionX(), self:getPositionY())
    node.tbNamePoint = self.tbNamePoint

    parNode[node.id] = node

end

function EffectImage:onBig()
    local a = string.split(self.res, ".")
    local name = a[1] .. "-2." .. a[2]
    -- self:setSpriteFrame(name)
    local d = EffectMultiTexture:create()
    --     --local sprite = cc.Sprite:createWithSpriteFrameName("2.png")
    d:setTexture(cc.SpriteFrameCache:getInstance():getSpriteFrame(name):getTexture())
    --    --d:setTexture(cc.SpriteFrameCache:getInstance():getSpriteFrame("7.png"):getTexture())
    --    --d:setTexture(cc.Director:getInstance():getTextureCache():addImage("res/map/6.png"))
    d:setPer(100)
    self:setEffect(d)

    --    effectSprite.multi = d
end


function EffectImage:onSmall()

    local d = EffectMultiTexture:create()
    --     --local sprite = cc.Sprite:createWithSpriteFrameName("2.png")
    d:setTexture(cc.SpriteFrameCache:getInstance():getSpriteFrame(self.res):getTexture())
    --    --d:setTexture(cc.SpriteFrameCache:getInstance():getSpriteFrame("7.png"):getTexture())
    --    --d:setTexture(cc.Director:getInstance():getTextureCache():addImage("res/map/6.png"))
    d:setPer(100)
    self:setEffect(d)

end



return EffectImage
