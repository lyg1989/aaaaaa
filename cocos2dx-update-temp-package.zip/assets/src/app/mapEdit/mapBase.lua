local mapBase = class("mapBase", cc.Layer)
local MapProxy = require("app.models.MapProxy")
require("src.init.tablesave")

local EffectImage = require("app.mapEdit.EffectImage")

function mapBase:ctor(par, mtype, size, id, scale)
--    print('mapBase:ctor')

    self.curImg = nil
    self.controls = par.controls
    self.mapView = self.controls["background"]

    self.factor = 3
    self.startPos = cc.p(10, 10)


    self.par = par
    self.mtype = mtype

    -- self.initPos = pos
    self.info = { }
    self.imgList = { }
    -- self:CreateMapScroll(size)
    self:initScale()
    self:loadFrame()
    MapProxy:Tmp_InitForceBlock()
    self:loadEditInfo()

     if scale then
        --self:setZoomScale(scale)
        self.layerView:setScale(scale)
    end

    if id then
        self:turnToImg(id)
    end



    self:enableTouch()
    self:enableKeyPress()
end

function mapBase:drawForceName()
    for nForce, info in pairs(MapProxy.tbForce2Block) do
        --        dump(info.posLongest, 'info.posLongest')

        local nSegmentX = (info.posLongest.posDest.x - info.posLongest.posSrc.x) / 3
        local nSegmentY = (info.posLongest.posDest.y - info.posLongest.posSrc.y) / 3
        --        print('nSegmentX, nSegmentY', nSegmentX, nSegmentY)


        local pos1 = cc.p((info.posLongest.posDest.x + info.posLongest.posSrc.x) / 2 - nSegmentX * 0.4,
            (info.posLongest.posDest.y + info.posLongest.posSrc.y) / 2 - nSegmentY * 0.4)
        local pos2 = cc.p((info.posLongest.posDest.x + info.posLongest.posSrc.x) / 2,
            (info.posLongest.posDest.y + info.posLongest.posSrc.y) / 2)
        local pos3 = cc.p((info.posLongest.posDest.x + info.posLongest.posSrc.x) / 2 + nSegmentX * 0.4,
            (info.posLongest.posDest.y + info.posLongest.posSrc.y) / 2 + nSegmentY * 0.4)
        --        local pos = cc.p((info.nLeft + info.nRight) / 2, (info.nBottom + info.nTop) / 2)

        local nRotation = GetWordRotation(info.posLongest.posSrc, info.posLongest.posDest)
        math.deg(math.atan((info.posLongest.posDest.y - info.posLongest.posSrc.y) / (info.posLongest.posDest.x - info.posLongest.posSrc.x)))
        --        print('nRotation', nRotation)
        nRotation = -nRotation

        local nFontSize = info.posLongest.nLong / 12
        local labName2 = cc.Label:createWithSystemFont('匈   牙   利', "Arial", nFontSize)
        labName2:setColor(cc.c3b(0, 0, 0))
        labName2:setPosition(pos2)
        labName2:setRotation(nRotation)
        self.layerView:addChild(labName2, 2)

        --        break
    end
end

function mapBase:loadFrame()
    for i = 1, 4 do
        cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/block/map" .. i .. ".plist")
    end

    for i = 1, 14 do
        cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/block/map22" .. i .. ".plist")
    end
end

function mapBase:getType()
    return self.mtype
end

function mapBase:initScale()


    self.minScale = 0.5
    self.maxScale = 3
end

-- function mapBase:CreateMapScroll(size)

--    if size == nil then
--        size = cc.size(display.width - 350, display.height - 150)
--    end
--    local pos = cc.p(0, 0)


--    -- layer:setContentSize(2000, 2000)
--    -- local bg = cc.Sprite:create("res/map/u.jpg")
--    --    local layerColor = cc.LayerColor:create(cc.c4b(128, 64, 0, 255))
--    --    --self:addChild(layerColor)
--    --    layerColor:setPosition(pos)
--    --    layerColor:setContentSize(size)
--    -- local layer = cc.Layer:create()

--    local scrollView1 = cc.ScrollView:create()
--    local screenSize = cc.Director:getInstance():getWinSize()

--    -- local layer = mapBase:create(scrollView1, self, MapType.FirstLayer)
--    if nil ~= scrollView1 then

--        scrollView1:setViewSize(size)
--        scrollView1:setPosition(cc.p(0, 0))

--        scrollView1:setScale(1.0)
--        scrollView1:ignoreAnchorPointForPosition(true)

--        -- scrollView1:setContainer(layer)
--        scrollView1:updateInset()


--        scrollView1:setDirection(cc.SCROLLVIEW_DIRECTION_BOTH)
--        scrollView1:setClippingToBounds(true)
--        scrollView1:setBounceable(true)
--        scrollView1:setDelegate()
--        -- scrollView1:registerScriptHandler(handler(self, self.scrollView1DidScroll), cc.SCROLLVIEW_SCRIPT_SCROLL)
--        scrollView1:registerScriptHandler(handler(self, self.scrollView1DidZoom), cc.SCROLLVIEW_SCRIPT_ZOOM)
--        scrollView1:registerScriptHandler(handler(self, self.scrollView1DidTouched), cc.SCROLLVIEW_SCRIPT_TOUCHED)

--        scrollView1:registerScriptHandler(handler(self, self.scrollView1DidScale), cc.SCROLLVIEW_SCRIPT_SCALED)
--        -- layerColor:addChild(scrollView1)

--        scrollView1:setMinScale(0.95)
--        scrollView1:setMaxScale(3.02)
--        -- self.controls["mapP"]:addChild(scrollView1)


----        if CC_EDIT_MAP then
----        scrollView1:setMinScale(0.95)
----        scrollView1:setMaxScale(10)
----        end

--        self:addChild(scrollView1)

--    end

--    -- self.layerView = layer

--    self.mapView = scrollView1

--    -- self.mapView:getTouchMovePosition
-- end


-- function mapBase:enableTouch()
--    -- handling touch events
--    local function onTouchBegan(touch, event)
--        local BeginPos = touch:getLocation()
--        local endPos = self.mapView:convertToNodeSpace(touch:getLocation())
--        print("mapBase touch x, y", endPos.x, endPos.y)
--        -- CCTOUCHBEGAN event must return true
--        local size = self.mapView:getViewSize()
--        local rect = cc.rect(0, 0, size.width, size.height)
--        if cc.rectContainsPoint(rect, BeginPos) then
--            if self.par.selId then
--                local id = self:resToId(self.par.selId.res)
--                if self:setSelectImg(id) == false then
--                    local endPos = event:getCurrentTarget():convertToNodeSpace(touch:getLocation())
--                    self:createBlock(self.par.selId.res, endPos, { })
--                end

--                return true
--            end
--        end
--        return false
--    end

--    local function onTouchEnded(touch, event)
--        local location = touch:getLocation()
--        local endPos = self.layerView:convertToNodeSpace(touch:getLocation())

--        self.curImg:setPosition(endPos)
--        -- self.curImg:setSelectStatus(true)
--    end

--    local listener = cc.EventListenerTouchOneByOne:create()
--    listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
--    listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
--    local eventDispatcher = self:getEventDispatcher()
--    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
-- end

function mapBase:setType(mtype)
    if self.mtype == mtype then
        return
    end
    self.mtype = mtype

    if self.curImg then
        self.preImage = self.curImg.id
        self.curImg = nil
    end
    self:loadEditInfo()
end


--function mapBase:hecheng()
--   -- local rend = cc.RenderTexture:create(self.layerView:getContentSize().width, self.layerView:getContentSize().height)
--   local rend = cc.RenderTexture:create(display.width, display.height)
--    -- 设置精灵的坐标为cocos坐标
--    rend:setKeepMatrix(true)
--    rend:begin();
--    self.imgList["1"]:visit();
--    self.imgList["2"]:visit();
--    self.imgList["3"]:visit();
--    rend:endToLua();

--    -- self.layerView:addChild(rend)

--    -- rend:setPosition(10, 10)

--    local spt = EffectSprite:createWithFrame(rend:getSprite():getSpriteFrame())
--    -- spt:setSpriteFrame(rend:getSprite():getSpriteFrame())
--    spt:setAnchorPoint(cc.p(0, 0))
--    -- spt:setOpacity(100)
--    self.layerView:addChild(spt, 10000)
--    self.spt = spt
--    -- spt:setPosition(cc.Director:getInstance():convertToGL(cc.p(spt:getPosition())))

--    -- spt:setPosition(200, 200)
--    self.spt:setFlippedY(true)
--    local c = EffectStroke:create()
--    c:setInfo(cc.c3b(120, 100, 100), 5)
--    self.spt:setEffect(c)
--end


function mapBase:hecheng()
   --local rend = cc.RenderTexture:create(display.width, display.height)
   local rend = cc.RenderTexture:create(self.layerView:getContentSize().width, self.layerView:getContentSize().height)
   local pos =  cc.p(self.layerView:getPosition())
  -- self.layerView:setPosition(0, 0)
    -- 设置精灵的坐标为cocos坐标
    --rend:setKeepMatrix(true)

    --self.imgList["1"]:setNomalRender()
    rend:begin()
    --self.imgList["1"]:visit()
    --self.imgList["2"]:visit()
   -- self.imgList["3"]:visit()
    self.layerView:visit()
    --self.controls["background"]:visit()
    rend:endToLua()

    -- self.layerView:addChild(rend)
      -- self.layerView:setPosition(pos)
     --rend:setPosition(pos)

    local spt = EffectSprite:createWithFrame(rend:getSprite():getSpriteFrame())
    -- spt:setSpriteFrame(rend:getSprite():getSpriteFrame())
    spt:setAnchorPoint(cc.p(0, 0))
    -- spt:setOpacity(100)
    self.layerView:addChild(spt, 10000)
    self.spt = spt
    -- spt:setPosition(cc.Director:getInstance():convertToGL(cc.p(spt:getPosition())))
    -- spt:setPosition(200, 200)
    self.spt:setFlippedY(true)
    local c = EffectStroke:create()
    c:setInfo(cc.c3b(120, 100, 100), 5)
   --self.spt:setEffect(c)
end

function mapBase:resToId(res)
    local name = string.split(res, ".")
    if self.mtype == MapType.FirstLayer then
        return name[1]
    else
        name = string.split(name[1], "-")
        return name[1]
    end
end

function mapBase:idToRes(id)
    if self.mtype == MapType.FirstLayer then
        return id .. ".png"
    else
        return id .. "-2.png"
    end

end

function mapBase:getFrameSize()
    return self.mapView:getContentSize()
end

function mapBase:turnToImg(id)
    if self.imgList[id] then
        -- local offset = display.sub(self.imgList[id]:getPosition())
        local center = self:getFrameSize()       
        local pos = cc.p(self.imgList[id]:getPosition())

        local pos1 = self.layerView:convertToWorldSpace(pos)

        local offset = cc.p(center.width/2 - pos1.x, center.height/2 - pos1.y)
        -- self:setContentOffset(offset, false)
        --self:moveOffset(cc.p(self.layerView:getPositionX()+offset.x, self.layerView:getPositionY()+offset.y))

        self:moveOffset(cc.p(-pos1.x+center.width/2, -pos1.y+center.height/2))
        self:setSelectImg(id)
    end

    return false
end


function mapBase:setSelectImg(id)
    if self.imgList[id] then

        if self.curImg then
            self.curImg:setSelectStatus(false)
        end

        self.curImg = self.imgList[id]
        self.curImg:setSelectStatus(true)
        if CC_EDIT_MAP then
            self.par:updateShowInfo(self.curImg)
        end

        --local pos1 = self.layerView:convertToWorldSpace(cc.p(self.curImg:getPosition()))

        --print("img pos...........................", pos1.x, pos1.y, self.curImg:getPositionX(), self.curImg:getPositionY())
        return true
    end

    return false
end

function mapBase:ClearDrawDot()
    if self.curImg then
        self.curImg:ClearDrawDot()
    end
end

function mapBase:SwitchDrawDot()
    if self.curImg then
        self.curImg:SwitchDrawDot()
    end
end

function mapBase:createBlock(res, endPos, info)
    --dump(res, 'res')
    local id = self:resToId(res)
    local effect = EffectImage:create(res, endPos, self, info, id)
    self.imgList[effect.id] = effect

    if CC_EDIT_MAP then
        self:setSelectImg(effect.id)
    end
    return effect
end




function mapBase:save()

    local par = { }

    for k, v in pairs(self.imgList) do
        v:save(par)
    end
    table.save(par, "res/map/block/map" .. self.mtype .. ".edit")
    self.info[self.mtype] = par

end


function mapBase:convertSecondPos(pos)
    local factor = self.factor
    local offset = cc.pSub(pos, self.startPos)
    offset = cc.pMul(offset, factor)
    return cc.pAdd(self.startPos, offset)

end

function mapBase:convertFirstPos(pos)
    local factor = self.factor
    local offset = cc.pSub(pos, self.startPos)
    offset = cc.pMul(offset, 1.0 / factor)
    return cc.pAdd(self.startPos, offset)

end


-- function mapBase:loadSecondMap(info)
----    self.layerView = cc.Layer:create()
----    self.mapView:setContainer(self.layerView)

--    if self.startPos == nil then
--        for k, v in pairs(info) do
--            if k == "1" then
--                self.startPos = v.pos
--            end
--        end
--    end
--    local w = 0
--    local h = 0
--    for k, v in pairs(info) do
--        local name = self:idToRes(k)
--        local pos = v.pos
--        if k ~= "1" then
--            pos = self:convertSecondPos(v.pos)
--        end
--        local effect = self:createBlock(name, pos, v)
--        self.layerView:addChild(effect)
--        local size = effect:getContentSize()
--        if v.pos.x + size.width > w then
--            w = v.pos.x + size.width
--        end

--        if v.pos.y + size.height > h then
--            h = v.pos.y + size.height
--        end
--    end

--    self.layerView:setContentSize(cc.size(5760, 5280))
-- end

function mapBase:loadFirstMap(info)

    --     self.layerView = cc.Layer:create()
    --    self.mapView:setContainer(self.layerView)

    -- self.layerView:setContentSize(cc.size(2048, 2048))
    local w = 0
    local h = 0


    for k, v in pairs(info) do
        local name = self:idToRes(k)
        local effect = self:createBlock(name, v.pos, v)
        self.layerView:addChild(effect)

        local size = effect:getContentSize()
        if v.pos.x + size.width > w then
            w = v.pos.x + size.width
        end

        if v.pos.y + size.height > h then
            h = v.pos.y + size.height
        end
    end
    self.layerView:setContentSize(cc.size(w, h))
end

function mapBase:loadMap(info)
--    dump(info, 'info')
    local tbForce2Block = MapProxy.tbForce2Block
    local tbBlock2Force = MapProxy.tbBlock2Force
    --     self.layerView = cc.Layer:create()
    --    self.mapView:setContainer(self.layerView)

    -- self.layerView:setContentSize(cc.size(2048, 2048))
    local w = 0
    local h = 0

--    dump(tbForce2Block, 'tbForce2Block')
--    dump(tbBlock2Force, 'tbBlock2Force')
    for k, v in pairs(info) do
        local name = self:idToRes(k)
        local newpos = cc.pAdd(v.pos, self.startPos)
        local effect = self:createBlock(name, newpos, v)
        self.layerView:addChild(effect)

        local size = effect:getContentSize()
        if v.pos.x + size.width > w then
            w = v.pos.x + size.width
        end

        if v.pos.y + size.height > h then
            h = v.pos.y + size.height
        end

        local nBlock = tonumber(k)
        local nForce = tbBlock2Force[nBlock]
        local nBottom = v.pos.y - size.height / 2
        local nTop = v.pos.y + size.height / 2
        local nLeft = v.pos.x - size.width / 2
        local nRight = v.pos.x + size.width / 2
        tbForce2Block[nForce].tbBlockList[nBlock].nCenterY = (nBottom + nTop) / 2
        tbForce2Block[nForce].tbBlockList[nBlock].nLeft = nLeft
        tbForce2Block[nForce].tbBlockList[nBlock].nRight = nRight

--        tbForce2Block[nForce].nBottom = tbForce2Block[nForce].nBottom or nBottom
        if tbForce2Block[nForce].nBottom > nBottom then
            tbForce2Block[nForce].nBottom = nBottom
            tbForce2Block[nForce].posBottomLeft = cc.p(nLeft, nBottom)
            tbForce2Block[nForce].posBottomRight = cc.p(nRight, nBottom)
        end
--        tbForce2Block[nForce].nTop = tbForce2Block[nForce].nTop or nTop
        if tbForce2Block[nForce].nTop < nTop then
            tbForce2Block[nForce].nTop = nTop
            tbForce2Block[nForce].posTopLeft = cc.p(nLeft, nTop)
            tbForce2Block[nForce].posTopRight = cc.p(nRight, nTop)
        end
--        tbForce2Block[nForce].nLeft = tbForce2Block[nForce].nLeft or nLeft
        if tbForce2Block[nForce].nLeft > nLeft then
            tbForce2Block[nForce].nLeft = nLeft
            tbForce2Block[nForce].posLeftTop = cc.p(nLeft, nTop)
            tbForce2Block[nForce].posLeftBottom = cc.p(nLeft, nBottom)
        end
--        tbForce2Block[nForce].nRight = tbForce2Block[nForce].nRight or nRight
        if tbForce2Block[nForce].nRight < nRight then
            tbForce2Block[nForce].nRight = nRight
            tbForce2Block[nForce].posRightTop = cc.p(nRight, nTop)
            tbForce2Block[nForce].posRightBottom = cc.p(nRight, nBottom)
        end

        tbForce2Block[nForce].posLongest = MapProxy:GetLongestLine({
            posBottomLeft = tbForce2Block[nForce].posBottomLeft,
            posBottomRight = tbForce2Block[nForce].posBottomRight,
            posTopLeft = tbForce2Block[nForce].posTopLeft,
            posTopRight = tbForce2Block[nForce].posTopRight,
            posLeftTop = tbForce2Block[nForce].posLeftTop,
            posLeftBottom = tbForce2Block[nForce].posLeftBottom,
            posRightTop = tbForce2Block[nForce].posRightTop,
            posRightBottom = tbForce2Block[nForce].posRightBottom,
        })
    end
    self.layerView:setContentSize(cc.size(w, h))
--    dump(tbForce2Block, 'tbForce2Block')
--    print("mapbase .............contentsize..........", w, h)
end

function mapBase:loadBlockByImgs()
    local info = self.info[self.mtype]

    if self.mtype == MapType.FirstLayer then
        self:loadFirstMap(info)
        -- self.mapView:setStatus(1.9)
    else
        self:loadSecondMap(info)
        -- self.mapView:setStatus(1)
    end

    if self.preImage then
        self:setSelectImg(self.preImage)
        self.preImage = nil
    end

end

function mapBase:loadBlock()
    local info = self.info[self.mtype]

    if self.layerView == nil then
        self.layerView = cc.Layer:create()
        self:addChild(self.layerView)

        self.layerView:ignoreAnchorPointForPosition(false)
        self.layerView:setAnchorPoint(cc.p(0, 0))
    end


    self.layerView:removeAllChildren()
    self.layerView:setScale(1)

    --    if self.mtype == MapType.FirstLayer then
    --        self:loadFirstMap(info[self.mtype])
    --        -- self.mapView:setStatus(1.9)
    --    else
    --        self:loadSecondMap(info[self.mtype])
    --        -- self.mapView:setStatus(1)
    --    end
    self:loadMap(self.info[self.mtype])


    if self.preImage then
--        print("preselect.........", self.preImage)
        self:setSelectImg(self.preImage)
        self.preImage = nil
    end

end


function mapBase:loadEditInfo()
--    print('loadEditInfo-----------------------', self.mtype)

    if self.info[self.mtype] == nil then
        local info, errorinfo = table.loadEx("res/map/block/map" .. self.mtype .. ".edit")
        -- info = { }
        if errorinfo then
            return
        end

        self.info[self.mtype] = info
    end

    self:loadBlock()
end


function mapBase:del()

    if self.curImg then
        self.imgList[self.curImg.id] = nil
        self.layerView:removeChild(self.curImg)
        self.curImg = nil
    end
end


function mapBase:edit()



end


function mapBase:enableKeyPress()

    local function onKeyReleased(keyCode, event)
        if self.curImg then
            self.curImg:onKeyPress(keyCode)
        end
    end

    local listener = cc.EventListenerKeyboard:create()
    listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED)

    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)

end

function mapBase:onTouchBegan(touch, event)
--    print("mapBase:onTouchBegan", touch)
    if table.nums(self._touches) > 2 or self._touchMoved == true then
        return false
    end

    local target = self.mapView

    local locationInNode = target:convertToNodeSpace(touch:getLocation())
    local s = target:getContentSize()
    local rect = cc.rect(0, 0, s.width, s.height)

    if not cc.rectContainsPoint(rect, locationInNode) then
        return
    end

    local needadd = true
    for k, v in pairs(self._touches) do
        if v == touch then
            needadd = false
        end
    end
    if needadd then
        table.insert(self._touches, touch)
--        print("mapBase:onTouchBegan   add", touch)
    end

    if table.nums(self._touches) == 1 then
        self._touchPoint = self.mapView:convertTouchToNodeSpace(touch)
        self._touchMoved = false
        self._dragging = true
        self._touchLength = 0.0
--        print("touch began  .....", self._touchPoint.x, self._touchPoint.y)
    elseif table.nums(self._touches) == 2 then
        local pos1 = self.layerView:convertTouchToNodeSpace(self._touches[1])
        local pos2 = self.layerView:convertTouchToNodeSpace(self._touches[2])

        local pos3 = self.mapView:convertTouchToNodeSpace(self._touches[1])
        local pos4 = self.mapView:convertTouchToNodeSpace(self._touches[2])
        self._touchPoint = cc.pMidpoint(pos3, pos4)
        self._touchLength = cc.pGetDistance(pos1, pos2)
        self._dragging = false
--        print("multi touch began  .....", self._touchPoint.x, self._touchPoint.y)
    end

    return true
end



function mapBase:onTouchMoved(touch, event)
    if table.nums(self._touches) == 1 then
        local newPoint = self:convertTouchToNodeSpace(touch)
        local moveDistance = cc.pSub(newPoint, self._touchPoint)
        local dis = cc.pGetLength(moveDistance)

--        print("touch moved .....", touch:getLocation().x, touch:getLocation().y, newPoint.x, newPoint.y, moveDistance.x, moveDistance.y)
        self._touchPoint = newPoint

        if cc.pGetLength(moveDistance) < 1 then
            return
        end

        self._touchMoved = true

        if self._dragging then


            local newx = self.layerView:getPositionX() + moveDistance.x
            local newy = self.layerView:getPositionY() + moveDistance.y

--            print("touch moved1 .....", self.layerView:getPositionX(), self.layerView:getPositionY(), moveDistance.x, moveDistance.y, newx, newy)
            self._scrollDistance = moveDistance
            self:moveOffset(cc.p(newx, newy))

        end
    elseif table.nums(self._touches) == 2 and self._dragging == false then
        --        local pos1 = self.layerView:convertTouchToNodeSpace(self._touches[1])
        --        local pos2 = self.layerView:convertTouchToNodeSpace(self._touches[2])

        --        local len = cc.pGetDistance(pos1, pos2)
        --        --self:setZoomScale(self.layerView:getScale() * len / self._touchLength)
        --        self:setZotouchScaleMoveomScale(self.layerView:getScale() * len / self._touchLength)
        --        print("multi touch moved  .....", len)
    end

end

---这里的S > 1 代表放大,反之代表缩小
function mapBase:touchScaleEnd(s)


    if math.min(self.layerView:getScale(), self.maxScale) == self.maxScale and  s > 1 then
        --self:changeMap(MapType.SecondLayer)
        local context = Context:buildContext({transType = Context.TRANS_TYPE.ONE_BY_ONE, center=cc.p(200, 200)}, SCENE.LAYERMAP)   
        game:sendNotification(GAME.GO_TO_SCENE, context)
        return
    end

    if math.max(self.layerView:getScale(), self.minScale) == self.minScale and s < 1 then
        self:changeMap(MapType.FirstLayer)
        return
    end

    local scale = self.layerView:getScale()

    local factor = math.floor(scale/0.5)
    local scale = 0.5*factor

    if s > 1 then
        scale = scale + 0.5
    else
        scale = scale - 0.5
    end
    
--    print("touch scale..............", s, scale)


    scale = math.min(self.maxScale, math.max(self.minScale, scale))
    self:zoomScaleInDuration(scale, 0.5)
end

function mapBase:zoomScaleInDuration(s, dt)
    local scheduler = cc.Director:getInstance():getScheduler()
    local function removeZoomScale()
        self:unscheduleUpdate()
    end

    local center = cc.p(display.cx, display.cy)
    local oldcenter = self.layerView:convertToNodeSpace(center)

    local function updataZoomScale()
        local newcenter = self.layerView:convertToWorldSpace(oldcenter)
--        print("mapBase:setZoomScale", s, self.layerView:getScale(), newcenter.x, newcenter.y, self.layerView:getContentSize().width)
        local offset = cc.pSub(center, newcenter)
        -- self:setContentOffset(cc.p(self.layerView:getPositionX() + offset.x, self.layerView:getPositionY() + offset.y))
        self:moveOffset(cc.p(self.layerView:getPositionX() + offset.x, self.layerView:getPositionY() + offset.y), true)
        oldcenter = self.layerView:convertToNodeSpace(center)
    end


    local scale = cc.ScaleTo:create(dt, s)
    self.layerView:stopAllActions()
    self.layerView:runAction(cc.Sequence:create(scale, cc.DelayTime:create(0.2), cc.CallFunc:create(removeZoomScale)))
    -- self.zoomSchedule = scheduler:scheduleScriptFunc(handler(self, self.setZoomScale), 0.15, false)
    self:scheduleUpdateWithPriorityLua(updataZoomScale, 0)
end


function mapBase:onTouchEnded(touch, event)
    if table.nums(self._touches) == 1 and self._touchMoved == false then
        self:scrollViewDidTouched()
    elseif table.nums(self._touches) == 2 then
        local pos1 = self.layerView:convertTouchToNodeSpace(self._touches[1])
        local pos2 = self.layerView:convertTouchToNodeSpace(self._touches[2])

        local len = cc.pGetDistance(pos1, pos2)
        -- self:setZoomScale(len / self._touchLength)

        self:touchScaleEnd(len / self._touchLength)
--        print("multi touch moved  .....", len)
    end

    table.removebyvalue(self._touches, touch, true)

    if table.nums(self._touches) == 0 then
        self._dragging = false
        self._touchMoved = false

    end

end


function mapBase:disableTouch()
    if self._listener then
        local eventDispatcher = self:getEventDispatcher()
        eventDispatcher:removeEventListener(self._listener)
        self._dragging = false
        self._touchMoved = false
        self._touches = { }
        self._listener = nil
    end
end

function mapBase:enableTouch()
    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(handler(self, self.onTouchBegan), cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(handler(self, self.onTouchEnded), cc.Handler.EVENT_TOUCH_ENDED)
    listener:registerScriptHandler(handler(self, self.onTouchMoved), cc.Handler.EVENT_TOUCH_MOVED)
    local eventDispatcher = self:getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self)
    self._listener = listener
    self._dragging = false
    self._touchMoved = false
    self._touches = { }
end


function mapBase:scrollViewDidTouched()
    local touch1 = self._touches[1]

    if self.par.selId then
        local id = self:resToId(self.par.selId.res)
        local endPos = self.layerView:convertToNodeSpace(touch1:getLocation())
        if self:setSelectImg(id) == false then

            local effect = self:createBlock(self.par.selId.res, endPos, { })
            self.layerView:addChild(effect)
        end
        self.curImg:setPosition(endPos)
        return
    end



    if touch1 then
        for k, v in pairs(self.imgList) do
            if v:onTouched(touch1) then
                return
            end
        end
    end
end

function mapBase:changeMap(mtype)

    if mtype ~= self.mtype then
        self.layerView:stopAllActions()
        self:setOffset()
        self:disableTouch()
        self:setType(mtype)
        if mtype == MapType.FirstLayer then
            self.layerView:setScale(3)

        else
            self.layerView:setScale(1)
        end
        self:getOffset()
        self:enableTouch()
--        print("map scale1....", self.layerView:getScale())
    end

end


function mapBase:setOffset()
    local size = self:getFrameSize()
    local center = cc.p(size.width/2, size.height/2)
    self.offset = cc.p(self.layerView:convertToNodeSpace(center))

end

function mapBase:getOffset()
    if self.offset == nil then
        return
    end
    local pos = self.offset


    if self:getType() == MapType.FirstLayer then
        pos = self:convertFirstPos(pos)
    else
        pos = self:convertSecondPos(pos)
    end

--    print("mapBase:setOffset..............", self.offset.x, self.offset.y, pos.x, pos.y)
--    local pos1 = self.layerView:convertToNodeSpace(self.touchCenter)

--    local pos2 = cc.pSub(pos, pos1)
--    local offset = cc.pSub(cc.p(self.layerView:getPosition()), pos2)

    local size = self:getFrameSize()
    local center = cc.p(size.width/2, size.height/2)
    local scale = self.layerView:getScale()

    pos = cc.p(-pos.x*scale+center.x, -pos.y*scale+center.y)

    self:moveOffset(pos)
end


--function mapBase:getOffset()
--    if self.offset == nil then
--        return
--    end
--    --
--    local pos = self.offset

--    if self:getType() == MapType.FirstLayer then
--        pos = self:convertFirstPos(self.offset)
--    else
--        pos = self:convertSecondPos(self.offset)
--    end

--    local pos1 = self.layerView:convertToNodeSpace(self.touchCenter)

--    local pos2 = cc.pSub(pos, pos1)
--    local offset = cc.pSub(cc.p(self.layerView:getPosition()), pos2)
--    self.layerView:moveOffset(offset)
--end

function mapBase:scrollView1DidZoom()
--    print("scrollView1DidZoom.............")

end

function mapBase:moveOffset(offset, animation)

    local size = self.layerView:getContentSize()
    size.width = size.width * self.layerView:getScale()
    size.height = size.height * self.layerView:getScale()
    local pos = offset
    local viewSize = self.mapView:getContentSize()

    if offset.x > 0 then
        offset.x = 0
    end

    if offset.y > 0 then
        offset.y = 0
    end

    if offset.x < - size.width + viewSize.width then
        offset.x = - size.width + viewSize.width
    end

    if offset.y < - size.height + viewSize.height then
        offset.y = - size.height + viewSize.height
    end
--    print("mapBase:moveOffset", pos.x, pos.y, offset.x, offset.y)
    self.layerView:setPosition(offset)
   -- self.offset = offset

end

function mapBase:getMapScale()
    return self.layerView:getScale()
end

function mapBase:setZoomScale(s)

    local center = cc.p(display.cx, display.cy)

    local size = self:getFrameSize()
    local center = cc.p(size.width/2, size.height/2)
--    if self._touchLength and self._touchLength == 0 then
--        center = cc.p(display.cx, display.cy)
--        center = self:convertToWorldSpace(center)
--    elseif self._touchPoint then
--        center = self._touchPoint
--    end

    local oldcenter = self.layerView:convertToNodeSpace(center)
    self.layerView:setScale(s)

    local newcenter = self.layerView:convertToWorldSpace(oldcenter)

--    print("mapBase:setZoomScale", s, self.layerView:getScale(), newcenter.x, newcenter.y, self.layerView:getContentSize().width)
    local offset = cc.pSub(center, newcenter)
    -- self:setContentOffset(cc.p(self.layerView:getPositionX() + offset.x, self.layerView:getPositionY() + offset.y))
    self:moveOffset(cc.p(self.layerView:getPositionX() + offset.x, self.layerView:getPositionY() + offset.y), true)
end

return mapBase

