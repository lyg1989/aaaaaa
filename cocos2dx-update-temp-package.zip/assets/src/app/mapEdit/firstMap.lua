local firstMap = class("firstMap")
require("src.init.tablesave")

local EffectImage = require("app.mapEdit.EffectImage")
local mapBase = require("app.mapEdit.mapBase")
local MapProxy = require("app.models.MapProxy")

local MAP_INDEX = 100

function firstMap:ctor(controls, par, mtype)
    print('firstMap:ctor--mtype',mtype)

    self.controls = controls
    self.selId = nil
    self.imgView = controls["imgView"]

   self.mtype = mtype
    self.imgIdToRes = {}
    self.startId = 1
    self.endId = 1
    --self:CreateMapScroll()
    self:loadInfo()
    self.par = par
   --self.map = mapBase:create( self, MapType.FirstLayer)
   --self.par:addChild(self.map, MAP_INDEX)

    local background = self.controls["background"]
    --background:setScale(1)
    background:setContentSize(cc.size(display.width, display.height))
    self.map = mapBase:create( self, mtype) 
    --self.map = mapBase:create(self, mtype, cc.size(display.width, display.height), pos)   
   self.controls["background"]:addChild(self.map, 100)
   --self.controls["background"]:setScale(1/display.scaleY)

    self.map:drawForceName()
end

function firstMap:onScale(scale)

    self.map:setZoomScale(scale)
    return

end

function firstMap:onSmall(args)

end



function firstMap:updateShowInfo(img)
    if img == nil then
        return
    end

    self.controls["idName"]:setString(img.id)
    self.controls["xPos"]:setString(img:getPositionX())
    self.controls["yPos"]:setString(img:getPositionY())

end


function firstMap:loadInfo()
    self.h = 0
    self.w = 0
    local nPreHeight = 0
    if self.mtype == MapType.FirstLayer then
        for i = 1, 4 do
            cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/block/map" .. i .. ".plist")
            -- laod second map
            -- cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/map2"..i..".plist")
            nPreHeight = nPreHeight + self:addImgs("res/map/block/map" .. i .. ".plist")
        end
        self.imgView:setInnerContainerSize(cc.size(self.w,(nPreHeight + self.h)))
        self:createImgs()
    else
        for i = 1, 14 do
            -- cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/map" .. i .. ".plist")
            -- laod second map
            cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/block/map22" .. i .. ".plist")
             nPreHeight = nPreHeight + self:addImgs("res/map/block/map22" .. i .. ".plist")
        end
        self.imgView:setInnerContainerSize(cc.size(self.w,(nPreHeight + self.h)))
        self:createImgs()
    end

        self.imgView:setPosition(display.width-200, 0)
end

function firstMap:addImgs(info)
    local info = cc.FileUtils:getInstance():getValueMapFromFile(info)
--    dump(info)
    self.imgView:setTouchEnabled(true)

    -- ccui.ScrollView.getInnerContainerSize
    local w = self.imgView:getInnerContainerSize().width
    local h1 = 0
    for k, v in pairs(info.frames) do
        -- local img = cc.Sprite:createWithSpriteFrameName(k)
        --  self.imgView:addChild(img)
        --        dump(k)
        --        dump(v.sourceSize)
        local v2 = string.split(k, ".")

        if self.mtype == MapType.SecondLayer then

             local  v3 = string.split(v2[1], "-")
             v2[1] = v3[1]
        end
        local v1 = loadstring("return " .. v.sourceSize)()
        if v1[1] > w then
            w = v1[1] + 10
        end


        h1 = h1 +(v1[2] + 10)

        self.imgIdToRes[tonumber(v2[1])] = v


        if tonumber(v2[1]) < self.startId then
            self.startId = tonumber(v2[1])
        elseif tonumber(v2[1]) > self.endId then
            self.endId = tonumber(v2[1])
        end

    end
    self.w = w
    return h1
--    self.imgView:setInnerContainerSize(cc.size(w,(h1 + self.h)))
--    self:createImgs()
end

function firstMap:createImgs()
--    print('firstMap:createImgs-------------')
    local function onImageViewClicked(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            local w = sender
            if w == self.selId then
                w:setFocusEnabled(true)
                w:setColor(cc.c3b(255, 255, 255))
                self.selId = nil
                return
            end

            if self.selId then
                self.selId:setFocusEnabled(true)
                self.selId:setColor(cc.c3b(255, 255, 255))
                self.selId = nil
            end


            w:setFocusEnabled(false)
            w:setColor(cc.c3b(255, 255, 0))
            self.selId = w
            local id = self.map:resToId(self.selId.res)
            self.map:turnToImg(id)

        end
    end

    local nTotalHeight = self.imgView:getInnerContainerSize().height
    w = 5
    h = self.h + 5
    local v = nil
--    for i = 1, 10 do
    for i = self.startId, self.endId do
--        print('i', i, w, h)
   -- for k, v in pairs(info.frames) do
        -- local img = cc.Sprite:createWithSpriteFrameName(k)
         v =  self.imgIdToRes[i]
         local name = i..".png"
         if self.mtype == MapType.SecondLayer then
            name = i.."-2.png"
         end
        -- print("effct name..........", name)
        local img = ccui.ImageView:create(name, ccui.TextureResType.plistType)
        self.imgView:addChild(img)
        img:setPosition(w, nTotalHeight - h)
        img:setAnchorPoint(cc.p(0, 1))
        img:setTouchEnabled(true)
        img:addTouchEventListener(onImageViewClicked)
        img.res = name
        local v1 = loadstring("return " .. v.sourceSize)()
        -- print("...........img info", k, v1[2][2], v.frame)
        h = h + v1[2] + 10
    end

    self.h = h
end



return firstMap

