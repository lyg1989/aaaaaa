local secondMap = class("secondMap")
require("src.init.tablesave")

local EffectImage = require("app.mapEdit.EffectImage")

function secondMap:ctor(controls)
    self.mapView = controls["mapView"]
    self.imgView = controls["imgView"]
    self.layerView = controls["innerMap"]
    self.controls = controls

    self.layerView:removeAllChildren(true);

    self.selItem = nil
    self.selId = nil
    self.curImg = nil

    self.imgList = { }
    self:loadInfo()
    self:loadEditInfo()
    self:enableTouch()

    self:enableKeyPress()

end

-- function secondMap:TurnTexture(scale)

--    local texture = {
--        "77777.png",
--        "2.png"
--    }
--    for k, v in pairs(self.imgList) do


--        if scale < 4 then


--        elseif scale >= 4 and scale < 8 then



--        else


--        end
--    end

-- end
function secondMap:resToId(res)
    local name = string.split(res, ".")
    return name[1]
end

function secondMap:idToRes(id)
    local name = id .. "-2.png"
    return name
end

function secondMap:turnToImg(id)


    if self.imgList[id] then
        -- local offset = display.sub(self.imgList[id]:getPosition())

        local offset = cc.p(display.cx - self.imgList[id]:getPositionX(), display.cy - self.imgList[id]:getPositionY())
        self.mapView:setContentOffset(offset, false)
    end

    return false
end

function secondMap:hecheng()
    local rend = cc.RenderTexture:create(display.width, display.height)

    -- 设置精灵的坐标为cocos坐标
    rend:setKeepMatrix(true)
    rend:begin();
    self.imgList["1"]:visit();
    self.imgList["2"]:visit();
    self.imgList["3"]:visit();
    rend:endToLua();

    -- self.layerView:addChild(rend)

    -- rend:setPosition(10, 10)

    local spt = EffectSprite:createWithFrame(rend:getSprite():getSpriteFrame())
    -- spt:setSpriteFrame(rend:getSprite():getSpriteFrame())
    spt:setAnchorPoint(cc.p(0, 0))
    -- spt:setOpacity(100)
    self.layerView:addChild(spt)
    self.spt = spt
    -- spt:setPosition(cc.Director:getInstance():convertToGL(cc.p(spt:getPosition())))


    -- spt:setPosition(200, 200)
    self.spt:setFlippedY(true)
    local c = EffectStroke:create()
    c:setInfo(cc.c3b(120, 100, 100), 5)
    self.spt:setEffect(c)
end

function secondMap:onBig()
    for k, v in pairs(self.imgList) do

        v:onBig()
    end
end

function secondMap:onSmall()
    for k, v in pairs(self.imgList) do

        v:onSmall()
    end
end

function secondMap:setSelectImg(id)
    if self.imgList[id] then
        --        if self.curImg and self.imgList[id] == self.curImg then
        --            return
        --        end

        if self.curImg then
            self.curImg:setSelectStatus(false)
        end

        self.curImg = self.imgList[id]
        self.curImg:setSelectStatus(true)
        self:updateShowInfo()
        return true
    end

    return false
end

function secondMap:updateShowInfo()
    if self.curImg == nil then
        return
    end

    self.controls["idName"]:setString(self.curImg.id)
    self.controls["xPos"]:setString(self.curImg:getPositionX())
    self.controls["yPos"]:setString(self.curImg:getPositionY())

end


function secondMap:loadInfo()
    self.h = 0
    self.w = 0

    for i = 1, 2 do
        -- cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/map" .. i .. ".plist")
        -- laod second map
        cc.SpriteFrameCache:getInstance():addSpriteFrames("res/map/map22" .. i .. ".plist")
        self:addImgs("res/map/map22" .. i .. ".plist")

    end
end

function secondMap:addImgs(info)
    local info = cc.FileUtils:getInstance():getValueMapFromFile(info)
    dump(info)
    self.imgView:setTouchEnabled(true)

    -- ccui.ScrollView.getInnerContainerSize
    local w = self.imgView:getInnerContainerSize().width
    local h1 = 0
    for k, v in pairs(info.frames) do
        -- local img = cc.Sprite:createWithSpriteFrameName(k)
        --  self.imgView:addChild(img)
        --        dump(k)
        --        dump(v.sourceSize)
        -- local v1 = loadstring("return " .. v.frame)()
        local v1 = loadstring("return " .. v.sourceSize)()
        if v1[1] > w then
            w = v1[1] + 10
        end


        h1 = h1 +(v1[2] + 10)

    end
    self.w = w
    self.imgView:setInnerContainerSize(cc.size(w,(h1 + self.h)))


    local function onImageViewClicked(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            local w = sender
            if w == self.selId then
                w:setFocusEnabled(true)
                w:setColor(cc.c3b(255, 255, 255))
                self.selId = nil
                return
            end

            if self.selId then
                self.selId:setFocusEnabled(true)
                self.selId:setColor(cc.c3b(255, 255, 255))
                self.selId = nil
            end


            w:setFocusEnabled(false)
            w:setColor(cc.c3b(255, 255, 0))
            self.selId = w
            local name = self:resToId(self.selId.res)
            self:turnToImg(name)

        end
    end

    w = 5
    h = self.h + 5
    for k, v in pairs(info.frames) do
        -- local img = cc.Sprite:createWithSpriteFrameName(k)
        local img = ccui.ImageView:create(k, ccui.TextureResType.plistType)
        self.imgView:addChild(img)
        img:setPosition(w, h)
        img:setAnchorPoint(cc.p(0, 0))
        img:setTouchEnabled(true)
        img:addTouchEventListener(onImageViewClicked)
        img.res = k
        local v1 = loadstring("return " .. v.sourceSize)()
        -- print("...........img info", k, v1[2][2], v.frame)
        h = h + v1[2] + 10
    end

    self.h = h

end


function secondMap:enableTouch()
    -- handling touch events
    local function onTouchBegan(touch, event)
        local BeginPos = touch:getLocation()
        local endPos = event:getCurrentTarget():convertToNodeSpace(touch:getLocation())
        print("secondMap touch x, y", endPos.x, endPos.y)
        -- CCTOUCHBEGAN event must return true
        local size = self.mapView:getViewSize()
        local rect = cc.rect(0, 0, size.width, size.height)


        if cc.rectContainsPoint(rect, BeginPos) then


            if self.selId then
                local name = self:resToId(self.selId.res)
                if self:setSelectImg(name) == false then
                    local endPos = event:getCurrentTarget():convertToNodeSpace(touch:getLocation())
                    self:createBlock(self.selId.res, endPos, { })
                end

                return true
            end



        end
        return false
    end

    local function onTouchEnded(touch, event)
        local location = touch:getLocation()
        local endPos = event:getCurrentTarget():convertToNodeSpace(touch:getLocation())

        self.curImg:setPosition(endPos)
        -- self.curImg:setSelectStatus(true)

    end

    local listener = cc.EventListenerTouchOneByOne:create()
    listener:registerScriptHandler(onTouchBegan, cc.Handler.EVENT_TOUCH_BEGAN)
    listener:registerScriptHandler(onTouchEnded, cc.Handler.EVENT_TOUCH_ENDED)
    local eventDispatcher = self.imgView:getParent():getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.layerView)
end

function secondMap:createBlock(res, endPos, info)
    local id = self:resToId(res)
    local effect = EffectImage:create(res, endPos, self, info, id)
    self.layerView:addChild(effect)
    -- self.curImg = effect
    self.imgList[effect.id] = effect
    self:setSelectImg(res)
end




function secondMap:save()

    local par = { }
    for k, v in pairs(self.imgList) do
        v:save(par)
    end
    table.save(par, "res/map/map.edit")

end

function secondMap:convertMapPos(pos)

    local factor = 3.209


    local offset = cc.pSub(pos, self.startPos)
    offset = cc.pMul(offset, factor)
    return cc.pAdd(self.startPos, offset)

end

function secondMap:loadEditInfo()
    local info, errorinfo = table.load("res/map/map.edit")

    -- info = { }
    if errorinfo then
        return
    end

    for k, v in pairs(info) do
        if k == "1" then
            self.startPos = v.pos
        end
    end

    for k, v in pairs(info) do
        local name = self:idToRes(k)
        local pos = v.pos
        if k ~= "1" then
            pos = self:convertMapPos(v.pos)
        end
        self:createBlock(name, pos, v)

    end
end


function secondMap:del()

    if self.curImg then


        self.imgList[self.curImg.id] = nil

        self.layerView:removeChild(self.curImg)
        self.curImg = nil
    end


end


function secondMap:edit()



end


function secondMap:enableKeyPress()

    local function onKeyReleased(keyCode, event)
        --        local label = event:getCurrentTarget()
        --        if keyCode == cc.KeyCode.KEY_UP then
        --            label:setString("BACK clicked!")
        --        elseif keyCode == cc.KeyCode.KEY_MENU then
        --            label:setString("MENU clicked!")
        --        end

        if self.curImg then

            self.curImg:onKeyPress(keyCode)
        end
    end

    local listener = cc.EventListenerKeyboard:create()
    listener:registerScriptHandler(onKeyReleased, cc.Handler.EVENT_KEYBOARD_RELEASED)

    local eventDispatcher = self.imgView:getParent():getEventDispatcher()
    eventDispatcher:addEventListenerWithSceneGraphPriority(listener, self.layerView)

end

return secondMap

