--物产id,名字
--id_kn,name_s
local mapProduct =
{
[1] = {name = "粮草"},
[2] = {name = "铁锭"},
[3] = {name = "皮革"},
[4] = {name = "木材"},
[5] = {name = "马匹"},
[6] = {name = "石头"},

}
return mapProduct