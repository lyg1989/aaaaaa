--地形Id,名字
--id_kn,name_s
local terrain =
{
[1] = {name = "沙漠"},
[2] = {name = "湖泊"},
[3] = {name = "森林"},
[4] = {name = "草原"},
[5] = {name = "雪地"},
[6] = {name = "农田"},
[7] = {name = "丛林"},
[8] = {name = "河流"},
[9] = {name = "山丘"},

}
return terrain