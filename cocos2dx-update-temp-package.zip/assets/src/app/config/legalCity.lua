--城市id,父节点,名字
--id_kn,pid,name_s
local legalCity =
{
[1] = {pid = 0,name = "长安"},
[2] = {pid = 0,name = "山东"},
[3] = {pid = 0,name = "济南"},
[4] = {pid = 1,name = "越秀"},
[5] = {pid = 1,name = "峨嵋"},
[6] = {pid = 1,name = "少林"},
[7] = {pid = 1,name = "武当"},

}
return legalCity