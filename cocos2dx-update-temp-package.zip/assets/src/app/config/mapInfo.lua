--id,行号,列号,资源路径,名字,属性,层
--Id_k,row,col,res_s,name_s,proper_t,layer1_s
local mapInfo =
{
{Id = 1,row = 0,col = 0,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 2,row = 0,col = 1,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 3,row = 0,col = 2,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 4,row = 1,col = 0,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 5,row = 1,col = 1,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 6,row = 1,col = 2,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 7,row = 2,col = 0,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 8,row = 2,col = 1,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 9,row = 2,col = 2,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 10,row = 3,col = 0,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 11,row = 3,col = 1,res = "res/map/area_11_18.tmx",name = "ddd",proper = {a=1},layer1 = "layer1"},
{Id = 12,row = 3,col = 2,res = "res/map/area_11_18.tmx",name = "ddd",proper = {b=1},layer1 = "layer1"},

}
return mapInfo