--UID,类型,地图索引x,地图索引y,格子索引x,格子索引y,所在阵营
--nNpcId_k,nType,nMapPosX,nMapPosY,nGridPosX,nGridPosY,nCamp
local npcBornInfo =
{
{nNpcId = 1,nType = 2,nMapPosX = 0,nMapPosY = 0,nGridPosX = 4,nGridPosY = 12,nCamp = 0},
{nNpcId = 2,nType = 2,nMapPosX = 0,nMapPosY = 0,nGridPosX = 10,nGridPosY = 15,nCamp = 1},
{nNpcId = 3,nType = 2,nMapPosX = 0,nMapPosY = 0,nGridPosX = 10,nGridPosY = 9,nCamp = 2},

}
return npcBornInfo