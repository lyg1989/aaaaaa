--形象Id,资源路径,名字
--nImgId_k,szImg_s,szName_s
local buildingConfig =
{
{nImgId = 1,szImg = "build_1.png",szName = "县城"},
{nImgId = 2,szImg = "build_2.png",szName = "军营"},

}
return buildingConfig