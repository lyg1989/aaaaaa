--UID,类型,地图索引x,地图索引y,格子索引x,格子索引y,所在阵营,初始耐久度,名字
--nBuildingId_k,nType,nMapPosX,nMapPosY,nGridPosX,nGridPosY,nCamp,nDefaultDur,szName_s
local buildingBornInfo =
{
{nBuildingId = 1,nType = 1,nMapPosX = 0,nMapPosY = 0,nGridPosX = 4,nGridPosY = 12,nCamp = 0,nDefaultDur = 10,szName = "我的县城"},
{nBuildingId = 2,nType = 1,nMapPosX = 0,nMapPosY = 0,nGridPosX = 16,nGridPosY = 9,nCamp = 1,nDefaultDur = 10,szName = "势力1的县城"},
{nBuildingId = 3,nType = 1,nMapPosX = 0,nMapPosY = 0,nGridPosX = 14,nGridPosY = 15,nCamp = 2,nDefaultDur = 10,szName = "势力2的县城"},
{nBuildingId = 4,nType = 2,nMapPosX = 0,nMapPosY = 0,nGridPosX = 10,nGridPosY = 9,nCamp = 1,nDefaultDur = 5,szName = "势力1的军营"},
{nBuildingId = 5,nType = 2,nMapPosX = 0,nMapPosY = 0,nGridPosX = 10,nGridPosY = 15,nCamp = 2,nDefaultDur = 5,szName = "势力2的军营"},

}
return buildingBornInfo