--形象Id,资源路径,名字
--nImgId_kn,szImg_s,$szName_s
local playerConfig =
{
[1] = {szImg = "1.png",szName = "士兵1"},
[2] = {szImg = "1.png",szName = "士兵1"},
[3] = {szImg = "1.png",szName = "士兵2"},

}
return playerConfig