--外交Id,名字,描述
--nDiplo_k,szName_s,szDesc_s
local diplomaticConfig =
{
{nDiplo = 1,szName = "无耻败类",szDesc = "无耻的败类"},

}
return diplomaticConfig