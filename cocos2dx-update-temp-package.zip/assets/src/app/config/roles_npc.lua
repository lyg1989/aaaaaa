--id,名称_cn,资源id,iconid,bodyimage,行走速度,类型,地图索引x,地图索引y,格子索引x,格子索引y,所在阵营
--id_kn,name_s,bodyid,iconid,bodyimage,speed,typeStr_s,nMapPosX,nMapPosY,nGridPosX,nGridPosY,nCamp
local roles_npc =
{
[10000] = {name = "藤蔓",bodyid = 10057,iconid = 100005,bodyimage = 15001,speed = 200,typeStr = "npc",nMapPosX = 0,nMapPosY = 0,nGridPosX = 4,nGridPosY = 12,nCamp = 0},
[10001] = {name = "船长普郎克",bodyid = 15001,iconid = 100005,bodyimage = 15001,speed = 200,typeStr = "npc",nMapPosX = 0,nMapPosY = 0,nGridPosX = 10,nGridPosY = 15,nCamp = 1},

}
return roles_npc