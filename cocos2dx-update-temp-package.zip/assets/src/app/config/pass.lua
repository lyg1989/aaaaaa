--通行Id,名字
--id_kn,name_s
local pass =
{
[1] = {name = "水域"},
[2] = {name = "陆定"},

}
return pass