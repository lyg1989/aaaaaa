--机器人Id,名字
--id_kn,name_s
local mapNpc =
{
[1] = {name = "刘备"},
[2] = {name = "孙权"},
[3] = {name = "关羽"},
[4] = {name = "张飞"},
[5] = {name = "赵子龙"},

}
return mapNpc