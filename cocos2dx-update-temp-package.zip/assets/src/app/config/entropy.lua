--繁荣等级,名字,人口基数
--id_kn,name_s,people
local entropy =
{
[1] = {name = "繁荣",people = 1000},
[2] = {name = "荒芜",people = 10},

}
return entropy