--建筑Id,名字
--id_kn,name_s
local build =
{
[1] = {name = "县级城池"},
[2] = {name = "郡城市"},

}
return build