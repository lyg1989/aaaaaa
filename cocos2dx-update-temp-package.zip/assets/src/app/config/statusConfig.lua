--地位Id,名字,描述
--nStatus_k,szName_s,szDesc_s
local statusConfig =
{
{nStatus = 1,szName = "荆州刺史",szDesc = "高大上的荆州刺史"},

}
return statusConfig