--------------------------------------------------------------------------------
-- ���غ�csv��Ļص�����
--------------------------------------------------------------------------------

function initFightPoint()
  --[[
	local data = getCSVField("map")
	csv["fightPointEx"] = {}
	for k, v in pairs(data) do
		--debug_log("initFightPoint", k, v.pointid)
		if not csv["fightPointEx"][v.id] then
			csv["fightPointEx"][v.mapid] = {}
			csv["fightPointEx"][v.mapid].count = 0
		end
		table.insert(csv["fightPointEx"][v.mapid], v)
		csv["fightPointEx"][v.mapid].count  = csv["fightPointEx"][v.mapid].count + 1
	end
	--]]
end

function initDialogData(val)
	--debug_log("initDialogData", val)
	DialogueMgr.load(val)
end

function initGodnesInfo()
  local data = getCSVField("godneslvl")
  csv["godneslvlEx"] = {}
  
  for k, v in pairs(data) do
    if not csv["godneslvlEx"][v.godId] then
      csv["godneslvlEx"][v.godId] = {}
    end
	csv["godneslvlEx"][v.godId][v.level] = v
    --table.insert(csv["godneslvlEx"][v.godId], v)
  end
  

end

