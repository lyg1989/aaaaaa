
require("init/csv.lua")
-- 锟斤拷锟斤拷锟斤拷息锟斤拷锟街段讹拷锟斤拷
local fieldLoadInfo = 
{
	filepath		= 1,	-- csv锟侥硷拷路锟斤拷锟斤拷
	field			= 2,	-- csv锟斤拷锟叫碉拷锟街讹拷锟斤拷
	func			= 3,	-- 锟斤拷锟截猴拷幕氐锟斤拷锟斤拷锟?
}




local csvLoadInfo=
{
	--["server"]={"server.csv", "server"},

	["playerConfig"] = {"playerConfig.csv", "playerConfig"},
	["buildingConfig"] = {"buildingConfig.csv", "buildingConfig"},
	["diplomaticConfig"] = {"diplomaticConfig.csv", "diplomaticConfig"},
	['statusConfig'] = {"diplomaticConfig.csv", "statusConfig"},

	["mapInfo"] = {"mapInfo.csv", "mapInfo"},
	["roles_npc"] = {"roles_npc.csv", "roles_npc"},
	["buildingBornInfo"] = {"buildingBornInfo.csv", "buildingBornInfo"},

	["area"] = {"area_11_18.csv", "area"},
}



local defaultPath = "res/config/"

--------------------------------------------------------------------
-- 锟斤拷锟斤拷CSV锟侥硷拷锟叫憋拷-锟斤拷锟斤拷锟斤拷锟?
--------------------------------------------------------------------
function loadCSVFiles()
	rawset(_G, "csv", {})
end


--------------------------------------------------------------------
-- 锟斤拷锟斤拷CSV锟侥硷拷锟叫憋拷-锟斤拷锟斤拷锟斤拷锟斤拷锟?
--------------------------------------------------------------------
function loadCSVFileList(loadList)
	local csvFilepath = nil
	local csvField = nil
	local csvFunc = nil
	for k, v in pairs(loadList) do
		csvFilepath = v[fieldLoadInfo.filepath]
		csvField = v[fieldLoadInfo.field]
		csvFunc = v[fieldLoadInfo.func]
		--debug_log('loading configuration file: '..defaultPath .. csvFilepath)
		local val = readCSV3(csvFilepath)--local val = readCSV2(defaultPath .. csvFilepath)
		--debug_log('loading configuration file: '..defaultPath .. csvFilepath)
		csv[csvField] = val
		if csvFunc then csvFunc() end
	end
end


function loadCSV(curCsvField)
	print("loadCSV start",curCsvField, os.clock())
	local csvFilepath = nil
	local csvField = nil
	local csvFunc = nil
	local v = csvLoadInfo[curCsvField]
	if v then 
		csvFilepath = v[fieldLoadInfo.filepath]
		csvField = v[fieldLoadInfo.field]
		csvFunc = v[fieldLoadInfo.func]
		
--		debug_log('loading configuration file: '..defaultPath .. csvFilepath)
		local val = readCSV3(csvFilepath)--local val = readCSV2(defaultPath .. csvFilepath)
		--debug_log('loading configuration file: '..defaultPath .. csvFilepath)
		csv[csvField] = val
		if csvFunc then csvFunc() end
		
	end
    print("loadCSV end",curCsvField, os.clock())
end

function loadCSVFromBuff(curCsvField,buff,csvFunc)
    print("loadCSV start",curCsvField, os.clock())
	
	local val = readCSV2FromBuff(buff)
	if Common.IsEmptyTable(val) then
		return false
	end
	csv[curCsvField] = val
	if csvFunc then csvFunc() end
	
    print("loadCSV end",curCsvField, os.clock())
	return true
end
--------------------------------------------------------------------
-- 锟斤拷锟铰硷拷锟斤拷某锟斤拷CSV锟侥硷拷
--------------------------------------------------------------------
function reloadCSVFile(csvFilepath, csvField, csvFunc)
	local val = readCSV3(csvFilepath)--local val = readCSV2(defaultPath .. csvFilepath)
	csv[csvField] = val
	if csvFunc then csvFunc() end
end

--------------------------------------------------------------------
-- 锟斤拷锟截凤拷页CSV锟侥硷拷锟叫憋拷-锟斤拷锟斤拷锟斤拷锟斤拷锟?
--------------------------------------------------------------------
function loadPageCSVFileList(loadList, fieldName)
	local csvFilepath = nil
	local csvField = nil
	local csvFunc = nil
	local count = 1
	local key = nil
	for k, v in pairs(loadList) do 
		csvFilepath = v[fieldLoadInfo.filepath]
		csvField = fieldName
		csvFunc = v[fieldLoadInfo.func]
		--debug_log('loading configuration file: '..defaultPath .. csvFilepath)
		--debug_log("csvField", csvField)
		local val = readCSV3(csvFilepath)--local val = readCSV2(defaultPath .. csvFilepath)
		if (count==1) then
			csv[csvField] = val
		else
			for m, n in pairs(val) do
				--debug_log("KEY:", m)
				csv[csvField][m] = n
			end
		end
		if csvFunc then csvFunc(val) end
		count = count + 1
	end
end

function getCSVField(field)
--	if not csv[field] then
--		loadCSV(field)
--	end
	return csv[field]
end

--从lua文件中加载
function loadCsvClient()
	csv = csv or {}
	local csvlist = require('app.config.csvlist')


	for _, szTableName in pairs(csvlist) do
		csv[szTableName] = require('app.config.'..szTableName)
	end
end

