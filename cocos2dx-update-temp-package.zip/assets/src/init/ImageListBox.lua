
local imageListBox = class("imageListBox", ccui.ScrollView)

function imageListBox:ctor(size)

    if not size then
        size = {}
    end
    self:setScrollX(false)
    self:setEnabled(true)  
    self.size = cc.size(size.width or 50,size.height or 100)    
    self:setContentSize(self.size)             
    self:setInnerContainerSize(self.size)
    self.curSel = -1
    self.items  = {}
    self.itemWidth = 80
    self.itemHeight = 80
    self.itemSpaceX = 1
    self.itemSpaceY = 1
    self.itemBgImgId = 0
    self.selImageId = 0
    self.selImage = nil
    self.selImageOffsetInfo = {x=0,y=0,w=0,h=0}

    --local   text = ccui.Text:create("aaa","Arial", 15)     
    --self:addChild(text)
end

function imageListBox:setEnabled(flag)
    self.isEnabled  = flag
    self:setVisible(flag) 
end

function imageListBox:setScrollX(flag)
    self.isScrollX = flag
    
    if self.isScrollX then
        self:setDirection(ccui.ScrollViewDir.horizontal)    
    else
        self:setDirection(ccui.ScrollViewDir.vertical)  
    end
    
    
end

function imageListBox:InitInfo(itemWidth,itemHeight,itemSpaceX,itemSpaceY,itemBgImgId,isScrollX)
    self.itemWidth = itemWidth
    self.itemHeight = itemHeight
    self.itemSpaceX = itemSpaceX
    self.itemSpaceY = itemSpaceY
    self.itemBgImgId = itemBgImgId or 0
    isScrollX = isScrollX or false
    self:setScrollX(isScrollX)
end

function imageListBox:SetSelImgId(imgId)
    self.selImageId = imgId 
end

function imageListBox:SetSelImgOffsetInfo(selImageOffsetInfo)
    if selImageOffsetInfo then
        self.selImageOffsetInfo = selImageOffsetInfo
    end     
end

function imageListBox:GetCurSel()
    for i, item in ipairs(self.items) do
        if item.id == self.curSel then
            return item
            
        end
    end	
    
    return nil
end

function imageListBox:SetCurSelById(id)
    self.curSel = id
    self:updateSelShow()
end

function imageListBox:updateSelShow()
    if self.selImageId == 0 then
        return
    end

    if not self.selImage then
        local path = recManager.getSprite(self.selImageId)
        self.selImage = cc.Sprite:create(path)
        self.selImage:setContentSize(cc.size(self.itemWidth + self.selImageOffsetInfo.w,
            self.itemHeight + self.selImageOffsetInfo.h))

        self.selImage:setAnchorPoint(cc.p(0.0, 1.0))
        self:addChild(self.selImage,10000)
    end


    local selItem = self:GetCurSel()
    if selItem then
        local x,y = selItem:getPosition()
    
        self.selImage:setPosition(self.selImageOffsetInfo.x + x, self.selImageOffsetInfo.y + y)
        self.selImage:setVisible(true)
    else
        self.selImage:setVisible(false)
    end
end



function imageListBox:setSumHeight()
    -- 计算列表的总高度，并依次排列所有条目
    local rowX = math.floor(self.size.width/(self.itemWidth+self.itemSpaceX))    
    self.sumHeight = math.floor(#self.items/rowX)*(self.itemHeight + self.itemSpaceY)
    if #self.items%rowX ~= 0 then
        self.sumHeight = self.sumHeight + self.itemHeight + self.itemSpaceY
    end
    
    if self.size.height < self.sumHeight then
        self:setInnerContainerSize(cc.size(self.size.width, self.sumHeight))    
    else
      self.sumHeight = self.size.height  
    end
    local x = 0
    local y = self.sumHeight
    for i, item in ipairs(self.items) do

        local curRowX = (i-1)%rowX
        if curRowX == 0 then
            y = y - self.itemHeight - self.itemSpaceY
        end

        local x = curRowX*(self.itemWidth+self.itemSpaceX)
        
        item:setPositionX(x)
        item:setPositionY(y)
        print("item id", i, x, y)
    end

    --self.sumHeight = self.sumHeight + self.itemHeight + self.itemSpaceY


end

function imageListBox:setSumWidth()
    -- 计算列表的总宽度，并依次排列所有条目
    self.sumWidth = 0
    local rowY = math.floor(self.size.height/(self.itemHeight + self.itemSpaceY))    
    for i, item in ipairs(self.items) do

        local curRowY = (i-1)%rowY
        if curRowY == 0 and i ~= 1 then
            self.sumWidth = self.sumWidth + self.itemWidth + self.itemSpaceX
        end


        local x = self.sumWidth
        local y = self.size.height-(curRowY+1)*(self.itemHeight+self.itemSpaceY)
        item:setPositionX(x)
        item:setPositionY(y)

    end

    -- 计算条目层的 x 值有效范围
    self.sumWidth = self.sumWidth + self.itemWidth + self.itemSpaceX
    if self.sumWidth > self.size.width then
        self:setInnerContainerSize(cc.size(self.sumWidth,self.size.height))
    end
end



function imageListBox:init()
    if imageListBox.isScrollX then
        self:setSumWidth()
    else
        self:setSumHeight()
    end
end

function imageListBox:Remove(id)
    for i, item in ipairs(self.items) do
        if item.id == id then
            self:removeItem(i)
            break
        end
    end
end

function imageListBox:Clear()
    for i, item in ipairs(self.items) do
        item:removeSelf()
    end
    self.items = {}
    self.curSel = -1

end

function imageListBox:addItem(item,zOrder)
    
    self.items[#self.items + 1] = item
    item.itemIndex = #self.items
    item:setAnchorPoint(cc.p(0.0, 0.0))
    if self.itemBgImgId > 0 then
        local path = recManager.getSprite(self.itemBgImgId)
        local itembg = cc.Sprite:create(path)
        itembg:setPosition(0, 0)
        itembg:setContentSize(cc.size(self.itemWidth,self.itemHeight))
        itembg:setAnchorPoint(cc.p(0.0, 1.0))
        item:addChild(itembg,0) 
        item:setContentSize(cc.size(self.itemWidth,self.itemHeight))
    end
    self:addChild(item,zOrder or 0)

    return item.itemIndex
end

function imageListBox:resetItem()
    if self.isScrollX then
        self:setSumWidth()
    else
        self:setSumHeight()
    end	
end

function imageListBox:removeItem(itemIndex)
    local i = itemIndex
    if self.items[i] then
        local item = self.items[i]
        item:removeSelf()
        table.remove(self.items, i)

        for j = i, #self.items do
            self.items[j].itemIndex = j
        end


        return true
    end

    return false
end

function imageListBox:getItem(itemIndex)
    if itemIndex >= 1 and itemIndex <= #self.items then
        return self.items[itemIndex]
    end
    return nil
end

function imageListBox:getItemsCount()
    return #self.items
end

return imageListBox
