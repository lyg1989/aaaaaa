--- init net package
-- @author zrong(zengrong.net)
-- Creation 2014-01-02
local net = {}

net.SocketTCP = import(".SocketTCP")

return net
